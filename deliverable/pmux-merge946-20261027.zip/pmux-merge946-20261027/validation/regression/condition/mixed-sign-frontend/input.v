module top(input signed [1:0] d, input [1:0] a, output [1:0] y); assign y=(d==4'b0011)?d:a; endmodule
