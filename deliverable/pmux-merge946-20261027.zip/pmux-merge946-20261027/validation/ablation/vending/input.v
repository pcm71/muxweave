`timescale 1ns / 1ps

// 数码管显示格式化模块。
// 将交易数据组合成8个4位字符编码，不负责具体的段码和位扫描。
// 编码规则：0~9为数字，A=10，P=11，C=12，d=13，E=14，空白=15。
module display_formatter (
    input  wire [2:0] state,               // 当前交易状态
    input  wire [1:0] cart_count,          // 购物车项数
    input  wire [3:0] sw,                  // 商品或零钱选择编码
    input  wire [3:0] current_qty,         // 当前商品数量
    input  wire [7:0] total_price,         // 购物车总价
    input  wire [7:0] paid_money,          // 已投入金额
    input  wire [7:0] change_money,        // 找零或退款总额
    input  wire [7:0] change_count_10,      // 10元找零数量
    input  wire [7:0] change_count_5,       // 5元找零数量
    input  wire [7:0] change_count_1,       // 1元找零数量
    input  wire       admin_page,           // 管理员子页面选择
    input  wire [7:0] selected_stock,       // 当前商品库存
    input  wire [7:0] selected_coin_value,  // 当前零钱面额
    input  wire [7:0] selected_coin_stock,  // 当前零钱库存
    output reg  [31:0] display_data         // 8个4位字符，从左到右拼接
);

    localparam [2:0] ST_SELECT = 3'd0;
    localparam [2:0] ST_PAY    = 3'd1;
    localparam [2:0] ST_VEND   = 3'd2;
    localparam [2:0] ST_CHANGE = 3'd3;
    localparam [2:0] ST_ADMIN  = 3'd4;
    localparam [2:0] ST_REFUND = 3'd5;

    // 将0~255的二进制数转换成三位十进制BCD：百位、十位、个位。
    function [11:0] bcd3;
        input [7:0] value;
        integer v;
        begin
            v = value;
            bcd3[11:8] = v / 100;
            bcd3[7:4]  = (v / 10) % 10;
            bcd3[3:0]  = v % 10;
        end
    endfunction

    wire [11:0] total_bcd  = bcd3(total_price);
    wire [11:0] paid_bcd   = bcd3(paid_money);
    wire [11:0] change_bcd = bcd3(change_money);
    wire [11:0] stock_bcd  = bcd3(selected_stock);
    wire [11:0] coin_value_bcd = bcd3(selected_coin_value);
    wire [11:0] coin_stock_bcd = bcd3(selected_coin_stock);
    // 商品编码的高两位决定行、低两位决定列，并从0~3转换为1~4。
    wire [3:0] product_row = {2'b00, sw[3:2]} + 1'b1;
    wire [3:0] product_col = {2'b00, sw[1:0]} + 1'b1;
    // 退货换购后购物车为空但金额仍被保留，此时末三位显示暂存金额；
    // 普通选货时仍显示购物车总价。
    wire [11:0] select_amount_bcd = ((cart_count == 2'd0) && (paid_money != 8'd0)) ?
                                     paid_bcd : total_bcd;

    always @(*) begin
        case (state)
            ST_SELECT:
                // 选货显示：A、购物车项数、商品行列、数量、三位金额。
                // 示例A0111000：购物车0项，选择A11，数量1，总价000。
                // 换购时购物车为空，末三位改为显示保留金额，例如A0121005。
                display_data = {4'hA, {2'b00, cart_count}, product_row,
                                product_col, current_qty, select_amount_bcd};
            ST_PAY:
                // 付款显示：P + 三位总价 + A + 三位已付金额。
                display_data = {4'hB, total_bcd, 4'hA, paid_bcd};
            ST_VEND:
                // 出货状态显示字符d，其余位熄灭。
                display_data = {4'hD, 4'hF, 4'hF, 4'hF,
                                4'hF, 4'hF, 4'hF, 4'hF};
            ST_CHANGE:
                // 逐枚找零：C + 三位剩余金额 + P + 三位当前面额。
                // C006P005表示还需找6元，当前选择每按一次KEY1找一枚5元。
                if (sw <= 4'h2)
                    display_data = {4'hC, change_bcd, 4'hB, coin_value_bcd};
                else
                    display_data = {4'hC, change_bcd, 4'hB, 4'hE, 4'hE, 4'hE};
            ST_REFUND:
                // 取消付款后的退款提示：C + 三位退款金额 + 四位空白。
                display_data = {4'hC, change_bcd, 16'hFFFF};
            ST_ADMIN:
                if (!admin_page)
                    // 商品库存页：Axy + 两位空白 + 三位库存。
                    // 示例A44__005表示A44库存为5。
                    display_data = {4'hA, product_row, product_col,
                                    4'hF, 4'hF, stock_bcd};
                else
                    // 零钱库存页：C + 三位面额 + 空白 + 三位库存。
                    // 示例C001_008表示1元零钱库存为8。
                    display_data = {4'hC, coin_value_bcd, 4'hF, coin_stock_bcd};
            default:
                // 非法状态显示E，便于定位状态机异常。
                display_data = 32'hEFFFFFFF;
        endcase
    end

endmodule

`timescale 1ns / 1ps

// 低电平有效按键消抖模块。
// 按键稳定按下达到DEBOUNCE_MS后，pressed仅输出一个时钟周期的高脉冲。
module key_debounce #(
    parameter integer CLK_FREQ_HZ = 50_000_000, // 输入时钟频率
    parameter integer DEBOUNCE_MS = 20          // 消抖稳定时间
) (
    input  wire clk,       // 系统时钟
    input  wire reset_n,   // 异步低有效复位
    input  wire key_n,     // 原始机械按键信号，按下为0
    output reg  pressed    // 完成消抖后的单周期按下事件
);

    // 需要保持稳定的时钟周期数：50 MHz、20 ms时为1,000,000。
    localparam integer COUNT_MAX = (CLK_FREQ_HZ / 1000) * DEBOUNCE_MS;

    reg [1:0]  key_sync;     // 两级同步寄存器，降低亚稳态传播风险
    reg        stable_level; // 已确认的稳定按键电平
    reg [20:0] count;        // 候选电平持续时间计数器

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            key_sync    <= 2'b11;
            stable_level <= 1'b1;
            count       <= 21'd0;
            pressed     <= 1'b0;
        end else begin
            // 将异步机械按键同步到clk时钟域。
            key_sync <= {key_sync[0], key_n};
            pressed  <= 1'b0;

            // 同步后的电平没有变化时清零计数；发生变化后持续计时。
            if (key_sync[1] == stable_level) begin
                count <= 21'd0;
            end else if (count == COUNT_MAX - 1) begin
                // 新电平稳定达到设定时间，才正式更新按键状态。
                count        <= 21'd0;
                stable_level <= key_sync[1];
                // 只对“按下”沿产生事件，“松开”仅更新稳定状态。
                if (key_sync[1] == 1'b0)
                    pressed <= 1'b1;
            end else begin
                count <= count + 1'b1;
            end
        end
    end

endmodule

`timescale 1ns / 1ps

// HX7A75C八位共阳数码管动态扫描模块。
// 经实物验证，段选和位选均为低电平有效。
module sevenseg_scan #(
    parameter integer CLK_FREQ_HZ = 50_000_000, // 系统时钟频率
    parameter integer PER_DIGIT_HZ = 1000       // 每一位的目标刷新频率
) (
    input  wire        clk,
    input  wire        reset_n,
    input  wire [31:0] display_data, // 8个4位字符编码
    output reg  [7:0]  seg,          // {dp,g,f,e,d,c,b,a}
    output reg  [7:0]  sel           // SEL0~SEL7位选
);

    // 50 MHz / (1 kHz * 8位) = 6250，每6250个时钟切换一次显示位。
    localparam integer SCAN_DIV = CLK_FREQ_HZ / (PER_DIGIT_HZ * 8);
    reg [15:0] scan_count;  // 扫描分频计数器
    reg [2:0]  digit_index; // 当前正在刷新的数码管编号0~7
    reg [3:0]  symbol;      // 当前位需要显示的字符编码

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            scan_count  <= 16'd0;
            digit_index <= 3'd0;
        end else if (scan_count == SCAN_DIV - 1) begin
            scan_count  <= 16'd0;
            digit_index <= digit_index + 1'b1;
        end else begin
            scan_count <= scan_count + 1'b1;
        end
    end

    // 按当前扫描位置，从32位显示数据中选出一个4位字符。
    always @(*) begin
        case (digit_index)
            3'd0: symbol = display_data[3:0];
            3'd1: symbol = display_data[7:4];
            3'd2: symbol = display_data[11:8];
            3'd3: symbol = display_data[15:12];
            3'd4: symbol = display_data[19:16];
            3'd5: symbol = display_data[23:20];
            3'd6: symbol = display_data[27:24];
            default: symbol = display_data[31:28];
        endcase

        // 位选低有效。实物调试发现逻辑位序与最初假设相反，因此从SEL7向SEL0扫描，
        // 同时从display_data最低4位开始取字符，保证字符串按正常左右顺序显示。
        sel = ~(8'b1000_0000 >> digit_index);

        // 字符到段码的查表转换。
        // 段码顺序为{dp,g,f,e,d,c,b,a}，输出0表示对应段点亮。
        case (symbol)
            4'h0: seg = 8'b1100_0000;
            4'h1: seg = 8'b1111_1001;
            4'h2: seg = 8'b1010_0100;
            4'h3: seg = 8'b1011_0000;
            4'h4: seg = 8'b1001_1001;
            4'h5: seg = 8'b1001_0010;
            4'h6: seg = 8'b1000_0010;
            4'h7: seg = 8'b1111_1000;
            4'h8: seg = 8'b1000_0000;
            4'h9: seg = 8'b1001_0000;
            4'hA: seg = 8'b1000_1000; // A
            4'hB: seg = 8'b1000_1100; // P
            4'hC: seg = 8'b1100_0110; // C
            4'hD: seg = 8'b1010_0001; // d
            4'hE: seg = 8'b1000_0110; // E
            default: seg = 8'b1111_1111; // blank
        endcase
    end

endmodule

`timescale 1ns / 1ps

// 自动售货机核心控制模块。
// 完成商品选择、购物车、付款、库存扣减、换购金额暂存、
// 逐枚/一键找零，以及可从找零页进入的管理员模式。
module vending_core (
    input  wire       clk,            // 系统时钟
    input  wire       reset_n,        // 异步低有效复位
    input  wire       pulse_add,      // KEY1单周期事件
    input  wire       pulse_qty,      // KEY2单周期事件
    input  wire       pulse_confirm,  // KEY3单周期事件
    input  wire       pulse_cancel,   // KEY4单周期事件
    input  wire [3:0] sw,             // 商品编号或投币面额编码

    output reg  [2:0] state,               // 当前有限状态机状态
    output reg  [1:0] cart_count,          // 购物车中商品项数0~2
    output reg  [3:0] current_qty,         // 当前准备加入的数量1~3
    output reg  [3:0] product1,            // 第一项商品编码
    output reg  [3:0] product2,            // 第二项商品编码
    output reg  [3:0] quantity1,           // 第一项购买数量
    output reg  [3:0] quantity2,           // 第二项购买数量
    output reg  [7:0] total_price,         // 购物车总价
    output reg  [7:0] paid_money,          // 当前已投入金额
    output reg  [7:0] change_money,        // 应找零或应退款金额
    output reg  [7:0] change_count_10,      // 本次找零使用的10元数量
    output reg  [7:0] change_count_5,       // 本次找零使用的5元数量
    output reg  [7:0] change_count_1,       // 本次找零使用的1元数量
    output reg        admin_page,           // 0=商品库存页，1=零钱库存页
    output wire [7:0] selected_stock,       // SW所选商品的当前库存
    output wire [7:0] selected_coin_value,  // SW所选零钱的面额
    output wire [7:0] selected_coin_stock,  // SW所选零钱的当前库存
    output reg        vend_pulse,           // 单周期出货事件
    output reg        error_pulse           // 单周期错误事件
);

    // 六状态有限状态机编码。
    localparam [2:0] ST_SELECT = 3'd0;
    localparam [2:0] ST_PAY    = 3'd1;
    localparam [2:0] ST_VEND   = 3'd2;
    localparam [2:0] ST_CHANGE = 3'd3;
    localparam [2:0] ST_ADMIN  = 3'd4;
    localparam [2:0] ST_REFUND = 3'd5;
    localparam [2:0] ST_VALIDATE = 3'd6;
    localparam [2:0] ST_COMMIT   = 3'd7;

    localparam [7:0] INITIAL_PRODUCT_STOCK = 8'd5;  // 每种商品上电库存
    localparam [7:0] INITIAL_COIN_STOCK    = 8'd8;  // 每种零钱上电库存
    localparam [7:0] MAX_PRODUCT_STOCK     = 8'd99; // 三位显示允许的最大库存
    localparam [7:0] MAX_COIN_STOCK        = 8'd99;

    // 16种商品分别保存库存，索引0~15对应A11~A44。
    reg [7:0] product_stock [0:15];
    // 售货机可用于找零的1元、5元和10元零钱库存。
    reg [7:0] coin_1_stock;
    reg [7:0] coin_5_stock;
    reg [7:0] coin_10_stock;

    // 当前交易临时接收的零钱数量。
    // 只有交易成功后才并入机器库存，取消交易时可直接退回原投入金额。
    reg [7:0] inserted_1;
    reg [7:0] inserted_5;
    reg [7:0] inserted_10;
    // 记录管理员模式是从普通选货页还是找零页进入。
    // 从找零页进入时，退出管理员后必须继续完成原交易的找零。
    reg       admin_return_to_change;
    // 付款达到总价后先锁存候选结果，再用两个内部状态完成找零校验和提交。
    // 这两个状态只持续40 ns左右，对用户不可见，却能切断较长组合路径。
    reg [7:0] pending_paid;
    reg [7:0] pending_change;
    reg [7:0] pending_coin_1;
    reg [7:0] pending_coin_5;
    reg [7:0] pending_coin_10;
    reg       validation_ok;
    reg [1:0] validation_mode; // 0=付款提交，1=逐枚找零，2=一键找零
    reg [7:0] pending_manual_denom;
    integer i;

    // 商品价格查表函数：4位开关编码映射到A11~A44的固定价格。
    function [7:0] product_price;
        input [3:0] product;
        begin
            case (product)
                4'h0: product_price = 8'd3;
                4'h1: product_price = 8'd4;
                4'h2: product_price = 8'd6;
                4'h3: product_price = 8'd3;
                4'h4: product_price = 8'd10;
                4'h5: product_price = 8'd8;
                4'h6: product_price = 8'd9;
                4'h7: product_price = 8'd7;
                4'h8: product_price = 8'd4;
                4'h9: product_price = 8'd6;
                4'hA: product_price = 8'd15;
                4'hB: product_price = 8'd8;
                4'hC: product_price = 8'd9;
                4'hD: product_price = 8'd4;
                4'hE: product_price = 8'd5;
                4'hF: product_price = 8'd5;
                default: product_price = 8'd0;
            endcase
        end
    endfunction

    // 投币面额查表函数：付款状态下SW编码决定KEY1代表的投入金额。
    function [7:0] denomination;
        input [3:0] code;
        begin
            case (code)
                4'h0: denomination = 8'd1;
                4'h1: denomination = 8'd5;
                4'h2: denomination = 8'd10;
                4'h3: denomination = 8'd20;
                4'h4: denomination = 8'd50;
                default: denomination = 8'd0;
            endcase
        end
    endfunction

    // 0~30除以5的小查表。8位数x可写成16*h+l=15*h+(h+l)，
    // 因此只需查(h+l)/5，不需要在FPGA中构造通用除法器。
    function [2:0] div5_small;
        input [4:0] value;
        begin
            case (value)
                5'd0,  5'd1,  5'd2,  5'd3,  5'd4:  div5_small = 3'd0;
                5'd5,  5'd6,  5'd7,  5'd8,  5'd9:  div5_small = 3'd1;
                5'd10, 5'd11, 5'd12, 5'd13, 5'd14: div5_small = 3'd2;
                5'd15, 5'd16, 5'd17, 5'd18, 5'd19: div5_small = 3'd3;
                5'd20, 5'd21, 5'd22, 5'd23, 5'd24: div5_small = 3'd4;
                5'd25, 5'd26, 5'd27, 5'd28, 5'd29: div5_small = 3'd5;
                default: div5_small = 3'd6;
            endcase
        end
    endfunction

    function [2:0] mod5_small;
        input [4:0] value;
        begin
            case (value)
                5'd0, 5'd5, 5'd10, 5'd15, 5'd20, 5'd25, 5'd30: mod5_small = 3'd0;
                5'd1, 5'd6, 5'd11, 5'd16, 5'd21, 5'd26:        mod5_small = 3'd1;
                5'd2, 5'd7, 5'd12, 5'd17, 5'd22, 5'd27:        mod5_small = 3'd2;
                5'd3, 5'd8, 5'd13, 5'd18, 5'd23, 5'd28:        mod5_small = 3'd3;
                default:                                          mod5_small = 3'd4;
            endcase
        end
    endfunction

    // 精确计算0~255的floor(value/5)，逻辑深度远小于“/5”。
    function [7:0] div5_u8;
        input [7:0] value;
        reg [4:0] nibble_sum;
        begin
            nibble_sum = {1'b0, value[7:4]} + {1'b0, value[3:0]};
            div5_u8 = ({4'd0, value[7:4]} << 1) +
                      {4'd0, value[7:4]} + {5'd0, div5_small(nibble_sum)};
        end
    endfunction

    // 检查给定零钱库存能否精确组成目标金额。
    // 依次尽量使用10元、5元，最后判断1元库存能否覆盖余数。
    function can_make_exact;
        input [7:0] amount;
        input [7:0] stock_1;
        input [7:0] stock_5;
        input [7:0] stock_10;
        reg [7:0] need_10;
        reg [7:0] use_10_local;
        reg [7:0] remainder_10_local;
        reg [7:0] need_5;
        reg [7:0] use_5_local;
        reg [7:0] required_ones;
        begin
            need_10            = div5_u8(amount) >> 1;
            use_10_local       = (need_10 > stock_10) ? stock_10 : need_10;
            remainder_10_local = amount - ((use_10_local << 3) + (use_10_local << 1));
            need_5             = div5_u8(remainder_10_local);
            use_5_local        = (need_5 > stock_5) ? stock_5 : need_5;
            required_ones      = remainder_10_local - ((use_5_local << 2) + use_5_local);
            can_make_exact     = (required_ones <= stock_1);
        end
    endfunction

    // 管理员页面使用的异步读口。
    assign selected_stock = product_stock[sw];
    assign selected_coin_value = (sw == 4'h0) ? 8'd1 :
                                 (sw == 4'h1) ? 8'd5 :
                                 (sw == 4'h2) ? 8'd10 : 8'd0;
    assign selected_coin_stock = (sw == 4'h0) ? coin_1_stock :
                                 (sw == 4'h1) ? coin_5_stock :
                                 (sw == 4'h2) ? coin_10_stock : 8'd0;

    // 当前商品成本和按下KEY1后的候选已付金额。
    wire [7:0] selected_denom = denomination(sw);
    wire [9:0] selected_cost  = product_price(sw) * current_qty;
    wire [8:0] paid_plus      = {1'b0, paid_money} + {1'b0, selected_denom};

    // 同一种商品分批加入时合并数量，不额外占用购物车商品项。
    wire same_as_product1 = (cart_count != 2'd0) && (product1 == sw);
    wire same_as_product2 = (cart_count == 2'd2) && (product2 == sw);
    wire [4:0] merged_quantity1 = {1'b0, quantity1} + {1'b0, current_qty};
    wire [4:0] merged_quantity2 = {1'b0, quantity2} + {1'b0, current_qty};
    wire [8:0] requested_stock = same_as_product1 ? {4'd0, merged_quantity1} :
                                 same_as_product2 ? {4'd0, merged_quantity2} :
                                 {5'd0, current_qty};
    wire stock_available = ({1'b0, product_stock[sw]} >= requested_stock);
    // 每一种商品在一笔交易中最多购买3件；分批加入也不能突破该上限。
    wire merged_quantity_overflow = (same_as_product1 && (merged_quantity1 > 5'd3)) ||
                                    (same_as_product2 && (merged_quantity2 > 5'd3));
    wire [10:0] cart_total_plus = {3'd0, total_price} + {1'b0, selected_cost};

    // 候选零钱库存=机器原库存+本次交易此前投入的零钱+当前准备投入的零钱。
    // 这样刚投入的1/5/10元也可以立即参与本次找零。
    wire [7:0] available_1  = coin_1_stock  + inserted_1  + ((selected_denom == 8'd1)  ? 1'b1 : 1'b0);
    wire [7:0] available_5  = coin_5_stock  + inserted_5  + ((selected_denom == 8'd5)  ? 1'b1 : 1'b0);
    wire [7:0] available_10 = coin_10_stock + inserted_10 + ((selected_denom == 8'd10) ? 1'b1 : 1'b0);

    // 当前投入后需要找零的金额。
    wire [7:0] change_needed = (paid_plus >= {1'b0, total_price}) ?
                               paid_plus[7:0] - total_price : 8'd0;

    // 退货换购时保留的已投金额，不再投入新币也可以与新购物车直接结账。
    wire [7:0] held_available_1  = coin_1_stock  + inserted_1;
    wire [7:0] held_available_5  = coin_5_stock  + inserted_5;
    wire [7:0] held_available_10 = coin_10_stock + inserted_10;
    wire [7:0] held_change_needed = (paid_money >= total_price) ?
                                    paid_money - total_price : 8'd0;
    // KEY2一键找零使用的自动组合，优先10元、再5元、最后1元。
    wire [7:0] auto_ten_needed = div5_u8(change_money) >> 1;
    wire [7:0] auto_use_10 = (auto_ten_needed > coin_10_stock) ? coin_10_stock : auto_ten_needed;
    wire [7:0] auto_remainder_10 = change_money - (auto_use_10 * 8'd10);
    wire [7:0] auto_five_needed = div5_u8(auto_remainder_10);
    wire [7:0] auto_use_5 = (auto_five_needed > coin_5_stock) ? coin_5_stock : auto_five_needed;
    wire [7:0] auto_remainder_5 = auto_remainder_10 - (auto_use_5 * 8'd5);
    wire [7:0] auto_use_1 = (auto_remainder_5 > coin_1_stock) ? coin_1_stock : auto_remainder_5;

    // 手动找零：SW=0/1/2选择1/5/10元，KEY1每按一次只找出一枚。
    // 每次动作前还要检查找出该枚后，剩余金额仍能由剩余库存精确组成。
    wire [7:0] manual_denom = selected_coin_value;
    wire manual_code_valid = (sw <= 4'h2);
    wire manual_stock_available = ((manual_denom == 8'd1)  && (coin_1_stock  != 8'd0)) ||
                                  ((manual_denom == 8'd5)  && (coin_5_stock  != 8'd0)) ||
                                  ((manual_denom == 8'd10) && (coin_10_stock != 8'd0));
    wire [7:0] manual_remaining = change_money - manual_denom;
    wire [7:0] manual_stock_1_after  = coin_1_stock  - ((manual_denom == 8'd1)  ? 1'b1 : 1'b0);
    wire [7:0] manual_stock_5_after  = coin_5_stock  - ((manual_denom == 8'd5)  ? 1'b1 : 1'b0);
    wire [7:0] manual_stock_10_after = coin_10_stock - ((manual_denom == 8'd10) ? 1'b1 : 1'b0);

    // 时序状态机：所有交易数据和库存只在时钟上升沿更新。
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state           <= ST_SELECT;
            cart_count      <= 2'd0;
            current_qty     <= 4'd1;
            product1        <= 4'd0;
            product2        <= 4'd0;
            quantity1       <= 4'd0;
            quantity2       <= 4'd0;
            total_price     <= 8'd0;
            paid_money      <= 8'd0;
            change_money    <= 8'd0;
            change_count_10 <= 8'd0;
            change_count_5  <= 8'd0;
            change_count_1  <= 8'd0;
            admin_page      <= 1'b0;
            inserted_1      <= 8'd0;
            inserted_5      <= 8'd0;
            inserted_10     <= 8'd0;
            admin_return_to_change <= 1'b0;
            pending_paid     <= 8'd0;
            pending_change   <= 8'd0;
            pending_coin_1   <= 8'd0;
            pending_coin_5   <= 8'd0;
            pending_coin_10  <= 8'd0;
            validation_ok    <= 1'b0;
            validation_mode  <= 2'd0;
            pending_manual_denom <= 8'd0;
            coin_1_stock    <= INITIAL_COIN_STOCK;
            coin_5_stock    <= INITIAL_COIN_STOCK;
            coin_10_stock   <= INITIAL_COIN_STOCK;
            vend_pulse      <= 1'b0;
            error_pulse     <= 1'b0;
            // 复位时将16种商品统一初始化为5件。
            for (i = 0; i < 16; i = i + 1)
                product_stock[i] <= INITIAL_PRODUCT_STOCK;
        end else begin
            vend_pulse  <= 1'b0;
            error_pulse <= 1'b0;

            case (state)
                // 选货状态：调整数量、加入购物车、确认付款或进入管理员模式。
                ST_SELECT: begin
                    change_money    <= 8'd0;
                    change_count_10 <= 8'd0;
                    change_count_5  <= 8'd0;
                    change_count_1  <= 8'd0;

                    // 购物车为空、SW=1111时按KEY3进入管理员模式。
                    // 正常购买A44不受影响：先按KEY1加入A44，再按KEY3确认即可。
                    if (pulse_confirm && (cart_count == 2'd0) && (sw == 4'hF)) begin
                        admin_page             <= 1'b0;
                        admin_return_to_change <= 1'b0;
                        state                  <= ST_ADMIN;
                    end else begin
                        // KEY2使当前数量按1->2->3->1循环。
                        if (pulse_qty) begin
                            if (current_qty == 4'd3)
                                current_qty <= 4'd1;
                            else
                                current_qty <= current_qty + 1'b1;
                        end

                        // KEY1加入商品：最多两种不同商品；同商品分批加入自动合并。
                        if (pulse_add) begin
                            if (!stock_available || merged_quantity_overflow ||
                                (cart_total_plus > 11'd255)) begin
                                error_pulse <= 1'b1;
                            end else if (same_as_product1) begin
                                quantity1   <= merged_quantity1[3:0];
                                total_price <= cart_total_plus[7:0];
                                current_qty <= 4'd1;
                            end else if (same_as_product2) begin
                                quantity2   <= merged_quantity2[3:0];
                                total_price <= cart_total_plus[7:0];
                                current_qty <= 4'd1;
                            end else if (cart_count == 2'd2) begin
                                error_pulse <= 1'b1;
                            end else if (cart_count == 2'd0) begin
                                product1    <= sw;
                                quantity1   <= current_qty;
                                total_price <= selected_cost[7:0];
                                cart_count  <= 2'd1;
                                current_qty <= 4'd1;
                            end else begin
                                product2    <= sw;
                                quantity2   <= current_qty;
                                total_price <= total_price + selected_cost[7:0];
                                cart_count  <= 2'd2;
                                current_qty <= 4'd1;
                            end
                        end

                        // 购物车非空时，KEY3确认并进入付款状态。
                        if (pulse_confirm) begin
                            if (cart_count == 2'd0) begin
                                error_pulse <= 1'b1;
                            end else if (paid_money < total_price) begin
                                state <= ST_PAY;
                            end else begin
                                // 使用之前保留的金额，无需再次投币；先进入内部校验状态。
                                pending_paid    <= paid_money;
                                pending_change  <= held_change_needed;
                                pending_coin_10 <= held_available_10;
                                pending_coin_5  <= held_available_5;
                                pending_coin_1  <= held_available_1;
                                validation_mode <= 2'd0;
                                state           <= ST_VALIDATE;
                            end
                        end

                        // KEY4：有商品时退货但保留已投金额；空购物车且存在
                        // 保留金额时进入退款提示；完全空闲时仅清空购物车。
                        if (pulse_cancel) begin
                            if ((cart_count == 2'd0) && (paid_money != 8'd0)) begin
                                change_money <= paid_money;
                                state        <= ST_REFUND;
                            end else begin
                                cart_count  <= 2'd0;
                                current_qty <= 4'd1;
                                product1    <= 4'd0;
                                product2    <= 4'd0;
                                quantity1   <= 4'd0;
                                quantity2   <= 4'd0;
                                total_price <= 8'd0;
                            end
                        end
                    end
                end

                // 付款状态：KEY1按SW编码投入金额，KEY4退货换购并暂存金额。
                ST_PAY: begin
                    if (pulse_cancel) begin
                        // 退货换购：清除当前商品，但保留已投金额和临时零钱，
                        // 返回选货页后可选择其他商品并用这笔金额重新结账。
                        state        <= ST_SELECT;
                        cart_count   <= 2'd0;
                        current_qty  <= 4'd1;
                        product1     <= 4'd0;
                        product2     <= 4'd0;
                        quantity1    <= 4'd0;
                        quantity2    <= 4'd0;
                        total_price  <= 8'd0;
                        change_money <= 8'd0;
                    end else if (pulse_add) begin
                        if ((selected_denom == 8'd0) || (paid_plus > 9'd255)) begin
                            error_pulse <= 1'b1;
                        end else if (paid_plus < {1'b0, total_price}) begin
                            // 金额不足：累计已付金额，并记录本次投入的可找零钱种。
                            paid_money <= paid_plus[7:0];
                            if (selected_denom == 8'd1)
                                inserted_1 <= inserted_1 + 1'b1;
                            else if (selected_denom == 8'd5)
                                inserted_5 <= inserted_5 + 1'b1;
                            else if (selected_denom == 8'd10)
                                inserted_10 <= inserted_10 + 1'b1;
                        end else begin
                            // 金额已足够：锁存候选金额和库存，交给内部状态校验。
                            pending_paid    <= paid_plus[7:0];
                            pending_change  <= change_needed;
                            pending_coin_10 <= available_10;
                            pending_coin_5  <= available_5;
                            pending_coin_1  <= available_1;
                            validation_mode <= 2'd0;
                            state           <= ST_VALIDATE;
                        end
                    end
                end

                // 内部校验状态：把组合找零判断结果寄存一拍，缩短50 MHz关键路径。
                ST_VALIDATE: begin
                    validation_ok <= can_make_exact(pending_change,
                                                    pending_coin_1,
                                                    pending_coin_5,
                                                    pending_coin_10);
                    state <= ST_COMMIT;
                end

                // 内部提交状态：校验失败则拒收最后一枚；成功才扣库存并出货。
                ST_COMMIT: begin
                    if (!validation_ok) begin
                        error_pulse <= 1'b1;
                        state       <= (validation_mode == 2'd0) ? ST_PAY : ST_CHANGE;
                    end else if (validation_mode == 2'd1) begin
                        // 提交一枚手动找零。
                        coin_10_stock <= pending_coin_10;
                        coin_5_stock  <= pending_coin_5;
                        coin_1_stock  <= pending_coin_1;
                        change_money  <= pending_change;
                        if (pending_manual_denom == 8'd10)
                            change_count_10 <= change_count_10 + 1'b1;
                        else if (pending_manual_denom == 8'd5)
                            change_count_5 <= change_count_5 + 1'b1;
                        else
                            change_count_1 <= change_count_1 + 1'b1;

                        if (pending_change == 8'd0) begin
                            state         <= ST_SELECT;
                            cart_count    <= 2'd0;
                            current_qty   <= 4'd1;
                            product1      <= 4'd0;
                            product2      <= 4'd0;
                            quantity1     <= 4'd0;
                            quantity2     <= 4'd0;
                            total_price   <= 8'd0;
                            paid_money    <= 8'd0;
                            inserted_1    <= 8'd0;
                            inserted_5    <= 8'd0;
                            inserted_10   <= 8'd0;
                        end else begin
                            state <= ST_CHANGE;
                        end
                    end else if (validation_mode == 2'd2) begin
                        // 提交自动组合找零。
                        coin_10_stock   <= coin_10_stock - auto_use_10;
                        coin_5_stock    <= coin_5_stock - auto_use_5;
                        coin_1_stock    <= coin_1_stock - auto_use_1;
                        change_count_10 <= change_count_10 + auto_use_10;
                        change_count_5  <= change_count_5 + auto_use_5;
                        change_count_1  <= change_count_1 + auto_use_1;
                        change_money    <= 8'd0;
                        state           <= ST_SELECT;
                        cart_count      <= 2'd0;
                        current_qty     <= 4'd1;
                        product1        <= 4'd0;
                        product2        <= 4'd0;
                        quantity1       <= 4'd0;
                        quantity2       <= 4'd0;
                        total_price     <= 8'd0;
                        paid_money      <= 8'd0;
                        inserted_1      <= 8'd0;
                        inserted_5      <= 8'd0;
                        inserted_10     <= 8'd0;
                    end else begin
                        paid_money      <= pending_paid;
                        change_money    <= pending_change;
                        change_count_10 <= 8'd0;
                        change_count_5  <= 8'd0;
                        change_count_1  <= 8'd0;
                        coin_10_stock   <= pending_coin_10;
                        coin_5_stock    <= pending_coin_5;
                        coin_1_stock    <= pending_coin_1;

                        if ((cart_count == 2'd2) && (product1 == product2)) begin
                            product_stock[product1] <= product_stock[product1] - quantity1 - quantity2;
                        end else begin
                            product_stock[product1] <= product_stock[product1] - quantity1;
                            if (cart_count == 2'd2)
                                product_stock[product2] <= product_stock[product2] - quantity2;
                        end
                        state <= ST_VEND;
                    end
                end

                // 找零：SW选择1/5/10元，KEY1每按一次找一枚，KEY2一键找完。
                // 若面额、库存或剩余组合不合法，则报警并保持原状态。
                ST_CHANGE: begin
                    // SW=1111并按KEY3：临时进入管理员模式补货或补零钱。
                    if (pulse_confirm && (sw == 4'hF)) begin
                        admin_page             <= 1'b0;
                        admin_return_to_change <= 1'b1;
                        state                  <= ST_ADMIN;
                    end else if (pulse_qty) begin
                        // KEY2一键找零：先校验管理员可能调整过的当前零钱库存。
                        pending_change  <= change_money;
                        pending_coin_10 <= coin_10_stock;
                        pending_coin_5  <= coin_5_stock;
                        pending_coin_1  <= coin_1_stock;
                        validation_mode <= 2'd2;
                        state           <= ST_VALIDATE;
                    end else if (pulse_add) begin
                        if (!manual_code_valid || (manual_denom == 8'd0) ||
                            (manual_denom > change_money) || !manual_stock_available) begin
                            error_pulse <= 1'b1;
                        end else begin
                            pending_change      <= manual_remaining;
                            pending_coin_10     <= manual_stock_10_after;
                            pending_coin_5      <= manual_stock_5_after;
                            pending_coin_1      <= manual_stock_1_after;
                            pending_manual_denom <= manual_denom;
                            validation_mode     <= 2'd1;
                            state               <= ST_VALIDATE;
                        end
                    end
                end

                // 出货状态只保持一个时钟周期；顶层会把vend_pulse延长约0.5秒。
                ST_VEND: begin
                    vend_pulse <= 1'b1;
                    if (change_money != 8'd0) begin
                        state <= ST_CHANGE;
                    end else begin
                        state        <= ST_SELECT;
                        cart_count   <= 2'd0;
                        current_qty  <= 4'd1;
                        product1     <= 4'd0;
                        product2     <= 4'd0;
                        quantity1    <= 4'd0;
                        quantity2    <= 4'd0;
                        total_price  <= 8'd0;
                        paid_money   <= 8'd0;
                        inserted_1   <= 8'd0;
                        inserted_5   <= 8'd0;
                        inserted_10  <= 8'd0;
                    end
                end

                // 退款显示：付款中途取消时显示应退总额；
                // 用户按KEY3或KEY4确认后清空交易，临时投入不计入机器库存。
                ST_REFUND: begin
                    if (pulse_confirm || pulse_cancel) begin
                        state           <= ST_SELECT;
                        cart_count      <= 2'd0;
                        current_qty     <= 4'd1;
                        product1        <= 4'd0;
                        product2        <= 4'd0;
                        quantity1       <= 4'd0;
                        quantity2       <= 4'd0;
                        total_price     <= 8'd0;
                        paid_money      <= 8'd0;
                        change_money    <= 8'd0;
                        change_count_10 <= 8'd0;
                        change_count_5  <= 8'd0;
                        change_count_1  <= 8'd0;
                        inserted_1      <= 8'd0;
                        inserted_5      <= 8'd0;
                        inserted_10     <= 8'd0;
                    end
                end

                // 管理员状态：四个LED同时点亮。
                // 商品页：SW选商品，KEY1加库存，KEY2减库存。
                // 零钱页：SW=0/1/2选择1/5/10元，KEY1加、KEY2减。
                // KEY3切换页面，KEY4退出管理员模式。
                ST_ADMIN: begin
                    cart_count  <= 2'd0;
                    total_price <= 8'd0;
                    current_qty <= 4'd1;

                    // 操作优先级：退出 > 切换页面 > 增加 > 减少。
                    if (pulse_cancel) begin
                        admin_page <= 1'b0;
                        state      <= admin_return_to_change ? ST_CHANGE : ST_SELECT;
                        admin_return_to_change <= 1'b0;
                    end else if (pulse_confirm) begin
                        admin_page <= ~admin_page;
                    end else if (pulse_add) begin
                        if (!admin_page) begin
                            if (product_stock[sw] < MAX_PRODUCT_STOCK)
                                product_stock[sw] <= product_stock[sw] + 1'b1;
                            else
                                error_pulse <= 1'b1;
                        end else begin
                            case (sw)
                                4'h0: if (coin_1_stock < MAX_COIN_STOCK) coin_1_stock <= coin_1_stock + 1'b1; else error_pulse <= 1'b1;
                                4'h1: if (coin_5_stock < MAX_COIN_STOCK) coin_5_stock <= coin_5_stock + 1'b1; else error_pulse <= 1'b1;
                                4'h2: if (coin_10_stock < MAX_COIN_STOCK) coin_10_stock <= coin_10_stock + 1'b1; else error_pulse <= 1'b1;
                                default: error_pulse <= 1'b1;
                            endcase
                        end
                    end else if (pulse_qty) begin
                        if (!admin_page) begin
                            if (product_stock[sw] != 8'd0)
                                product_stock[sw] <= product_stock[sw] - 1'b1;
                            else
                                error_pulse <= 1'b1;
                        end else begin
                            case (sw)
                                4'h0: if (coin_1_stock != 8'd0) coin_1_stock <= coin_1_stock - 1'b1; else error_pulse <= 1'b1;
                                4'h1: if (coin_5_stock != 8'd0) coin_5_stock <= coin_5_stock - 1'b1; else error_pulse <= 1'b1;
                                4'h2: if (coin_10_stock != 8'd0) coin_10_stock <= coin_10_stock - 1'b1; else error_pulse <= 1'b1;
                                default: error_pulse <= 1'b1;
                            endcase
                        end
                    end
                end

                default: state <= ST_SELECT;
            endcase
        end
    end

endmodule

`timescale 1ns / 1ps

module vending_machine_top (
    input  wire       clk,       // 开发板50 MHz系统时钟
    input  wire [3:0] key_n,     // KEY1~KEY4，按下为低电平
    input  wire [3:0] sw,        // SW1~SW4，商品编号或投币面额编码
    output wire [7:0] seg,       // 数码管段选：{dp,g,f,e,d,c,b,a}，低有效
    output wire [7:0] sel,       // 八位数码管位选，低有效
    output wire [3:0] led,       // 状态指示LED，高有效
    output wire       buzzer     // 出货或错误提示蜂鸣器
);

    // 上电复位：50 MHz下计数1,000,000个周期，约20 ms。
    // 复位期间禁止用户逻辑运行，避免刚上电时寄存器状态不稳定。
    reg [19:0] por_count = 20'd0;
    reg        por_done  = 1'b0;
    always @(posedge clk) begin
        if (!por_done) begin
            if (por_count == 20'd999_999)
                por_done <= 1'b1;
            else
                por_count <= por_count + 1'b1;
        end
    end

    // 同时按住KEY3和KEY4产生软复位。
    // 软复位会清空交易，并将商品与零钱库存恢复为初始值。
    wire soft_reset = (~key_n[2]) & (~key_n[3]);
    wire reset_n = por_done & (~soft_reset);

    // 消抖后的按键事件，每次有效按下只保持一个时钟周期。
    wire key_add;       // KEY1：加入商品、投币、逐枚找零或管理员加库存
    wire key_qty;       // KEY2：调整数量、一键找零或管理员减库存
    wire key_confirm;   // KEY3：确认、切换管理员页或从找零页进入管理员
    wire key_cancel;    // KEY4：退货换购、退款确认或退出管理员模式

    key_debounce db_key1 (.clk(clk), .reset_n(reset_n), .key_n(key_n[0]), .pressed(key_add));
    key_debounce db_key2 (.clk(clk), .reset_n(reset_n), .key_n(key_n[1]), .pressed(key_qty));
    key_debounce db_key3 (.clk(clk), .reset_n(reset_n), .key_n(key_n[2]), .pressed(key_confirm));
    key_debounce db_key4 (.clk(clk), .reset_n(reset_n), .key_n(key_n[3]), .pressed(key_cancel));

    // 核心模块输出的交易状态和数据。
    wire [2:0] state;
    wire [1:0] cart_count;
    wire [3:0] current_qty;
    wire [3:0] product1;
    wire [3:0] product2;
    wire [3:0] quantity1;
    wire [3:0] quantity2;
    wire [7:0] total_price;
    wire [7:0] paid_money;
    wire [7:0] change_money;
    wire [7:0] change_count_10;
    wire [7:0] change_count_5;
    wire [7:0] change_count_1;
    wire       admin_page;
    wire [7:0] selected_stock;
    wire [7:0] selected_coin_value;
    wire [7:0] selected_coin_stock;
    wire       vend_pulse;
    wire       error_pulse;

    // 售货机核心：负责购物车、付款、库存、找零和管理员模式。
    vending_core core (
        .clk(clk),
        .reset_n(reset_n),
        .pulse_add(key_add),
        .pulse_qty(key_qty),
        .pulse_confirm(key_confirm),
        .pulse_cancel(key_cancel),
        .sw(sw),
        .state(state),
        .cart_count(cart_count),
        .current_qty(current_qty),
        .product1(product1),
        .product2(product2),
        .quantity1(quantity1),
        .quantity2(quantity2),
        .total_price(total_price),
        .paid_money(paid_money),
        .change_money(change_money),
        .change_count_10(change_count_10),
        .change_count_5(change_count_5),
        .change_count_1(change_count_1),
        .admin_page(admin_page),
        .selected_stock(selected_stock),
        .selected_coin_value(selected_coin_value),
        .selected_coin_stock(selected_coin_stock),
        .vend_pulse(vend_pulse),
        .error_pulse(error_pulse)
    );

    // 8个数码管字符，每个字符使用4位编码，共32位。
    wire [31:0] display_data;
    // 根据当前状态将内部数据组织为可显示的字符序列。
    display_formatter formatter (
        .state(state),
        .cart_count(cart_count),
        .sw(sw),
        .current_qty(current_qty),
        .total_price(total_price),
        .paid_money(paid_money),
        .change_money(change_money),
        .change_count_10(change_count_10),
        .change_count_5(change_count_5),
        .change_count_1(change_count_1),
        .admin_page(admin_page),
        .selected_stock(selected_stock),
        .selected_coin_value(selected_coin_value),
        .selected_coin_stock(selected_coin_stock),
        .display_data(display_data)
    );

    // 动态扫描模块将字符编码转换为实际段选和位选信号。
    sevenseg_scan display (
        .clk(clk),
        .reset_n(reset_n),
        .display_data(display_data),
        .seg(seg),
        .sel(sel)
    );

    // 核心产生的出货/错误信号只有一个时钟周期，人眼无法观察。
    // 这里将事件延长25,000,000个周期，在50 MHz下约为0.5秒。
    reg [24:0] vend_hold;
    reg [24:0] error_hold;
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            vend_hold  <= 25'd0;
            error_hold <= 25'd0;
        end else begin
            if (vend_pulse)
                vend_hold <= 25'd25_000_000;
            else if (vend_hold != 0)
                vend_hold <= vend_hold - 1'b1;

            if (error_pulse)
                error_hold <= 25'd25_000_000;
            else if (error_hold != 0)
                error_hold <= error_hold - 1'b1;
        end
    end

    // LED状态说明：
    // LED1=选货，LED2=付款，LED3=出货，LED4=找零/退款/错误。
    // 管理员模式下四个LED全部点亮，便于与普通交易区分。
    assign led[0] = (state == 3'd0) | (state == 3'd4);
    assign led[1] = (state == 3'd1) | (state == 3'd4);
    assign led[2] = (vend_hold != 0) | (state == 3'd4);
    assign led[3] = (state == 3'd3) | (state == 3'd4) | (state == 3'd5) | (error_hold != 0);
    assign buzzer = (vend_hold != 0) | (error_hold != 0);

endmodule

