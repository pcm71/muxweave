# -*- coding: utf-8 -*-
"""condition 开/关消融：12 小例 + 售货机。输出 LUT 对照 + post_abc.il 供等价证明。"""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

os.environ['PATH'] = 'C:/opt/msys64/clang64/bin;C:/opt/msys64/usr/bin;' + os.environ.get('PATH', '')
_PKG = Path(__file__).resolve().parents[2]
ROOT = Path(__file__).resolve().parent
Y = str((Path(__file__).resolve().parents[2] / 'runtime' / 'windows' / 'bin' / 'yosys.exe').resolve())
sys.path.insert(0, str(_PKG / 'scripts'))
from resources import count  # noqa: E402

CASES = ['test1', 'test2', 'test3', 'test4', 'comb_2', 'comb_4', 'comb_8',
         'reg_2', 'enable_4', 'sync_reset_8', 'async_reset_4', 'pipeline_8']
TOPS = {'vending': 'vending_machine_top', 'i2c': 'i2c_master'}
LOCAL_SRC = {'vending': None, 'i2c': None}  # None = 用 ROOT 下同名目录的 input.v
SRC = _PKG / 'validation' / 'replay946'
OUT = ROOT / 'ablation.json'
results = json.loads(OUT.read_text()) if OUT.exists() else []
done_cases = {r['case'] for r in results if 'off' in r and 'on' in r}


def run_yosys(d, script, logname='run.log'):
    (d / 'run.ys').write_text(script)
    r = subprocess.run([Y, '-Q', '-s', 'run.ys'], cwd=d, capture_output=True, timeout=600)
    (d / logname).write_bytes(r.stdout + r.stderr)
    return r.returncode


for case in CASES + ['vending', 'i2c']:
    if case in done_cases:
        print(case, 'skip (已存在)')
        continue
    top = TOPS.get(case, case)
    d = (ROOT / (case + '_case')) if case == 'vending' else (ROOT / case)
    d.mkdir(parents=True, exist_ok=True)
    src = (ROOT / case / 'input.v') if case in LOCAL_SRC else (SRC / case / 'optimized/input.v')
    if Path(src).resolve() != (d / 'input.v').resolve():
        shutil.copy(src, d / 'input.v')
    row = dict(case=case, top=top)
    for mode, cond in [('off', ''), ('on', 'scratchpad -set pmux_opt.condition 1\n')]:
        m = d / mode
        m.mkdir(exist_ok=True)
        shutil.copy(d / 'input.v', m / 'input.v')
        script = (f'read_verilog input.v\nhierarchy -top {top}\n'
                  f'scratchpad -set abc9.nocleanup 1\n{cond}'
                  f'synth_intel -family cycloneiv -top {top}\n'
                  f'write_json final.json\n')
        if run_yosys(m, script) != 0:
            row[mode] = 'RUNTIME-FAIL'
            print(case, mode, 'RUNTIME-FAIL')
            continue
        row[mode] = count(json.loads((m / 'final.json').read_text()), top)['logic']
        script2 = (f'read_verilog input.v\nhierarchy -top {top}\n'
                   f'scratchpad -set abc9.nocleanup 1\n{cond}'
                   f'synth_intel -family cycloneiv -top {top} -run begin:map_cells\n'
                   f'write_rtlil post_abc.il\n')
        if run_yosys(m, script2, 'run2.log') != 0:
            row[mode + '_postabc'] = 'FAIL'
        else:
            row[mode + '_postabc'] = 'ok'
    results.append(row)
    (ROOT / 'ablation.json').write_text(json.dumps(results, indent=1))  # 增量落盘，超时续跑不丢
    print(case, {k: v for k, v in row.items() if k not in ('case', 'top')})

print('DONE')
