# -*- coding: utf-8 -*-
"""condition 深度消融：begin:map_bram 后手动 pmux_condition -auto，再继续后半流程。"""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

os.environ['PATH'] = 'C:/opt/msys64/clang64/bin;C:/opt/msys64/usr/bin;' + os.environ.get('PATH', '')
_PKG = Path(__file__).resolve().parents[2]
ROOT = Path(__file__).resolve().parent
Y = str((Path(__file__).resolve().parents[2] / 'runtime' / 'windows' / 'bin' / 'yosys.exe').resolve())
sys.path.insert(0, str(_PKG / 'scripts'))
from resources import count  # noqa: E402

CASES = ['test1', 'test2', 'test3', 'test4', 'comb_2', 'comb_4', 'comb_8',
         'reg_2', 'enable_4', 'sync_reset_8', 'async_reset_4', 'pipeline_8']
TOPS = {'vending': 'vending_machine_top', 'i2c': 'i2c_master'}
results = []


def run(d, script, log='run.log'):
    (d / 'run.ys').write_text(script)
    r = subprocess.run([Y, '-Q', '-s', 'run.ys'], cwd=d, capture_output=True, timeout=600)
    (d / log).write_bytes(r.stdout + r.stderr)
    return r.returncode, r.stdout + r.stderr


OUT = ROOT / 'ablation-deep.json'
results = json.loads(OUT.read_text()) if OUT.exists() else []
done_cases = {r['case'] for r in results if r.get('status') != 'RUNTIME-FAIL'}

for case in CASES + ['vending', 'i2c']:
    if case in done_cases:
        print(case, 'skip (已存在)')
        continue
    top = TOPS.get(case, case)
    d = ROOT / case / 'deep'
    d.mkdir(parents=True, exist_ok=True)
    src = (ROOT / 'vending/input.v') if case == 'vending' else (ROOT / case / 'input.v')
    shutil.copy(src, d / 'input.v')
    script = (f'read_verilog input.v\nhierarchy -top {top}\n'
              f'scratchpad -set abc9.nocleanup 1\n'
              f'scratchpad -set pmux_opt.condition 1\n'
              f'synth_intel -family cycloneiv -top {top} -run begin:map_bram\n'
              f'pmux_condition -json cond.json\n'
              f'synth_intel -family cycloneiv -top {top} -run map_bram:check\n'
              f'write_json final.json\n')
    rc, log = run(d, script)
    row = dict(case=case)
    if rc != 0:
        row['status'] = 'RUNTIME-FAIL'
        print(case, 'RUNTIME-FAIL')
    else:
        m = [l for l in log.decode(errors='replace').splitlines() if 'examined=' in l]
        row['condition'] = m[-1].strip() if m else 'NO-LINE'
        row['logic'] = count(json.loads((d / 'final.json').read_text()), top)['logic']
        row['off_logic'] = json.loads((ROOT / 'ablation.json').read_text())
        print(case, row['condition'], 'logic', row['logic'])
    results.append(row)
    OUT.write_text(json.dumps(results, indent=1))  # 增量落盘，超时续跑不丢

print('DONE')
