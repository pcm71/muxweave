module comb_2(input clk,en,rst,input [1:0] a,b,c,d,input [1:0] s,t,output [1:0] y);
reg [1:0] u,v;
always @* begin
 case(s)
 0:u=a;
 1:u=b;
 2:u=c;
 default:u=d;
 endcase
 case(t)
 0:v=u;
 1:v=a^c;
 2:v=b&d;
 default:v=a|d;
 endcase
end
assign y=v;
endmodule
