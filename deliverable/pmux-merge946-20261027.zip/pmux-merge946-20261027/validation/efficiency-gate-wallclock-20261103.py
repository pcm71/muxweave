# -*- coding: utf-8 -*-
"""Efficiency gate (2026-11-03 re-measurement, official protocol).

Official basis (FPGA contest Q&A 2026.10.31-11.2):
  - Q150: time metric corrected to WALL-CLOCK (not CPU time)
  - Q164.5: memory = peak of yosys.exe MAIN PROCESS only
  - Q131/Q147: warm up (pristine + case) x10 at test start; run pristine first,
    then optimized; small cases (<1s, and 1-10s per Q146.3) may be re-checked
    5x and averaged -> we time 5 rounds and average (discard max)
  - Q132: time and memory from the SAME run
  - Q144: eval script shape: read_verilog ...; synth_intel -family cycloneiv
Resources: logic = LUT + $not (Q66).
"""
import json
import os
import shutil
import subprocess
import sys
import time

import psutil

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)                      # pmux-merge946-20261027
_PROJ = os.path.dirname(_PKG)                      # pmuxv2
MERGED_EXE = os.path.join(_PKG, 'runtime', 'windows', 'bin', 'yosys.exe')
PRISTINE_EXE = os.path.join(_PROJ, 'work-v3', 'pristine-069', 'build', 'yosys.exe')
OUTDIR = os.path.join(_HERE, 'efficiency-gate-20261103')
FOUR = os.path.join(_PKG, 'validation', 'four-cases')
FIVE = os.path.join(_PROJ, 'pmux_cases')
sys.path.insert(0, os.path.join(_PKG, 'scripts'))
from resources import count  # noqa: E402

CASES = ([('test%d' % i, os.path.join(FOUR, 'test%d.v' % i), 'test%d' % i) for i in range(1, 5)] +
         [('pmux_case0%d_%s' % (i, s),
           os.path.join(FIVE, 'pmux_case0%d_%s.v' % (i, s)),
           'pmux_case0%d_%s' % (i, s))
          for i, s in [(1, 'balanced'), (2, 'pipeline'), (3, 'crossbar'),
                       (4, 'feedback'), (5, 'nested')]])

CLANG64 = r'C:\opt\msys64\clang64\bin'

RUN_YS = ('read_verilog input.v\n'
          'hierarchy -top {top}\n'
          'scratchpad -set abc9.nocleanup 1\n'
          'synth_intel -family cycloneiv -top {top}\n'
          'write_json final.json\n')


def make_env(cwd):
    env = dict(os.environ)
    env['PATH'] = CLANG64 + os.pathsep + env.get('PATH', '')
    tmp = os.path.join(cwd, 'tmp')
    os.makedirs(tmp, exist_ok=True)
    env['TEMP'] = tmp
    env['TMP'] = tmp
    env['TMPDIR'] = tmp
    return env


def run_one(exe, cwd, tag):
    """Run yosys; return (wall_seconds, peak_working_set_bytes of main process)."""
    log = os.path.join(cwd, 'run-%s.log' % tag)
    t0 = time.perf_counter()
    with open(log, 'w') as lf:
        p = subprocess.Popen([exe, '-s', 'run.ys'], cwd=cwd,
                             stdout=lf, stderr=subprocess.STDOUT, env=make_env(cwd))
        proc = psutil.Process(p.pid)
        peak = 0
        try:
            while p.poll() is None:
                try:
                    # peak_wset: peak since process start (main process only)
                    peak = max(peak, proc.memory_full_info().peak_wset)
                except psutil.Error:
                    pass
                time.sleep(0.02)
        except psutil.Error:
            pass
        p.wait()
    wall = time.perf_counter() - t0
    try:
        peak = max(peak, proc.memory_full_info().peak_wset)
    except psutil.Error:
        pass
    if p.returncode != 0:
        raise RuntimeError('%s rc=%d, see %s' % (tag, p.returncode, log))
    return wall, peak


def main():
    rounds = int(sys.argv[sys.argv.index('--rounds') + 1]) if '--rounds' in sys.argv else 5
    sel = None
    if '--cases' in sys.argv:
        sel = set(sys.argv[sys.argv.index('--cases') + 1].split(','))
    results_path = os.path.join(OUTDIR, 'results.json')
    results = json.load(open(results_path)) if os.path.exists(results_path) else {}
    for name, src, top in CASES:
        if sel and name not in sel:
            continue
        cwd = os.path.join(OUTDIR, name)
        os.makedirs(cwd, exist_ok=True)
        dst_input = os.path.join(cwd, 'input.v')
        if os.path.abspath(src) != os.path.abspath(dst_input):
            shutil.copyfile(src, dst_input)
        with open(os.path.join(cwd, 'run.ys'), 'w') as f:
            f.write(RUN_YS.format(top=top))
        print('=== %s: warmup pristine x10, merged x3' % name, flush=True)
        for _ in range(10):
            run_one(PRISTINE_EXE, cwd, 'warmup-pristine')
        for i in range(3):
            run_one(MERGED_EXE, cwd, 'warmup-merged-%d' % i)
        rec = {'top': top, 'pristine': {'walls': [], 'peaks': []},
               'merged': {'walls': [], 'peaks': []}}
        for r in range(rounds):
            w, pk = run_one(PRISTINE_EXE, cwd, 'pristine-r%d' % r)
            rec['pristine']['walls'].append(w)
            rec['pristine']['peaks'].append(pk)
            w, pk = run_one(MERGED_EXE, cwd, 'merged-r%d' % r)
            rec['merged']['walls'].append(w)
            rec['merged']['peaks'].append(pk)
            print('  round %d: pristine %.3fs/%.1fMB  merged %.3fs/%.1fMB' % (
                r, rec['pristine']['walls'][-1], rec['pristine']['peaks'][-1] / 2**20,
                rec['merged']['walls'][-1], rec['merged']['peaks'][-1] / 2**20), flush=True)
        for label, exe in [('pristine', PRISTINE_EXE), ('merged', MERGED_EXE)]:
            final_json = os.path.join(cwd, 'final.json')
            if os.path.exists(final_json):
                os.remove(final_json)
            run_one(exe, cwd, 'final-' + label)
            stats = count(json.load(open(final_json)), top)
            rec[label]['resources'] = {k: stats[k] for k in ['lut', 'inverter', 'sequential_bits', 'io', 'logic']}
            for key in ('walls', 'peaks'):
                arr = sorted(rec[label][key])
                trimmed = arr[:-1] if len(arr) >= 4 else arr
                rec[label]['avg_' + key[:-1]] = sum(trimmed) / len(trimmed)
        results[name] = rec
        json.dump(results, open(results_path, 'w'), indent=1)
    print('\n==== SUMMARY (wall-clock + yosys.exe peak WS) ====')
    print('%-24s %7s %7s %9s %9s %9s %9s %8s %8s' % (
        'case', 'p_lut', 'm_lut', 'p_logic', 'm_logic', 'd_logic%',
        'd_time%', 'd_mem%', 'p_wall'))
    gate_fail = []
    tot_dl, tot_dt, tot_dm, n = 0.0, 0.0, 0.0, 0
    for name, rec in results.items():
        pr, mr = rec['pristine']['resources'], rec['merged']['resources']
        dl = (mr['logic'] - pr['logic']) / max(pr['logic'], 1) * 100
        dt = (rec['merged']['avg_wall'] - rec['pristine']['avg_wall']) / rec['pristine']['avg_wall'] * 100
        dm = (rec['merged']['avg_peak'] - rec['pristine']['avg_peak']) / max(rec['pristine']['avg_peak'], 1) * 100
        flag = ''
        if mr['logic'] > pr['logic']:
            flag += ' LOGIC-UP!'
            gate_fail.append(name)
        if dt > 5:
            flag += ' TIME>5%!'
            gate_fail.append(name)
        if dm > 5:
            flag += ' MEM>5%!'
            gate_fail.append(name)
        print('%-24s %7d %7d %9d %9d %+8.2f%% %+8.2f%% %+8.2f%% %8.3fs%s' % (
            name, pr['lut'], mr['lut'], pr['logic'], mr['logic'], dl, dt, dm,
            rec['pristine']['avg_wall'], flag))
        tot_dl += dl; tot_dt += dt; tot_dm += dm; n += 1
    if n:
        print('\nAVERAGE: d_logic=%+.2f%%  d_time=%+.2f%%  d_mem=%+.2f%%' % (
            tot_dl / n, tot_dt / n, tot_dm / n))
    print('GATE:', 'FAIL ' + ','.join(set(gate_fail)) if gate_fail
          else 'PASS (logic<=baseline, time<=+5%, mem<=+5% per case)')
    json.dump(results, open(results_path, 'w'), indent=1)


if __name__ == '__main__':
    main()
