# -*- coding: utf-8 -*-
"""Formal equivalence: merged netlist vs pristine netlist for the 9 gate cases.

For each case, regenerate final-pristine.json / final-merged.json, then run
the standard yosys equiv flow (equiv_make -> equiv_simple -> equiv_induct ->
equiv_status). Any non-equivalent cell fails the case.
"""
import json
import os
import re
import subprocess
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
if os.path.exists(os.path.join(os.path.dirname(_HERE), 'runtime', 'windows', 'bin', 'yosys.exe')):
    # 交付包内布局：merged 用包内 runtime；pristine 需评审方自备（PRISTINE_YOSYS 环境变量）。
    _PKG = os.path.dirname(_HERE)
    GATE = os.path.join(_PKG, 'validation', 'efficiency-gate-20261027')
    MERGED = os.path.join(_PKG, 'runtime', 'windows', 'bin', 'yosys.exe')
    PRISTINE = os.environ.get('PRISTINE_YOSYS')
    if not PRISTINE:
        _cand = os.path.join(os.path.dirname(_PKG), 'pristine-069', 'build', 'yosys.exe')
        PRISTINE = _cand if os.path.exists(_cand) else r'C:\pristine-yosys-069\yosys.exe'
    MINI_SIM = os.path.join(_PKG, 'validation', 'mini_cells_sim.v')
else:
    ROOT = os.path.dirname(os.path.dirname(_HERE))   # work-v3
    GATE = os.path.join(ROOT, 'merge-946', 'validation', 'efficiency-gate-20261027')
    MERGED = os.path.join(ROOT, 'merge-946', 'build', 'install', 'bin', 'yosys.exe')
    PRISTINE = os.path.join(ROOT, 'pristine-069', 'build', 'yosys.exe')
    MINI_SIM = os.path.join(ROOT, 'merge-946', 'validation', 'mini_cells_sim.v')
CLANG64 = r'C:\opt\msys64\clang64\bin'

CASES = [('test%d' % i, 'test%d' % i) for i in range(1, 5)] + [
    ('pmux_case0%d_' % i + s, 'pmux_case0%d_%s' % (i, s))
    for i, s in [(1, 'balanced'), (2, 'pipeline'), (3, 'crossbar'), (4, 'feedback'), (5, 'nested')]]


def env(cwd):
    e = dict(os.environ)
    e['PATH'] = CLANG64 + os.pathsep + e.get('PATH', '')
    tmp = os.path.join(cwd, 'tmp')
    os.makedirs(tmp, exist_ok=True)
    e['TEMP'] = e['TMP'] = e['TMPDIR'] = tmp
    return e


def run(exe, cwd, ys_text, tag):
    ys = os.path.join(cwd, 'equiv.ys')
    with open(ys, 'w') as f:
        f.write(ys_text)
    log = os.path.join(cwd, 'equiv-%s.log' % tag)
    with open(log, 'w') as lf:
        p = subprocess.run([exe, '-Q', '-s', ys], cwd=cwd, stdout=lf,
                           stderr=subprocess.STDOUT, env=env(cwd), timeout=600)
    return p.returncode, log


def main():
    only = set(sys.argv[1].split(',')) if len(sys.argv) > 1 else None
    results = {}
    for name, top in CASES:
        if only and name not in only:
            continue
        cwd = os.path.join(GATE, name)
        # regenerate per-side netlists (run.ys already in dir)
        for label, exe in [('pristine', PRISTINE), ('merged', MERGED)]:
            p = subprocess.run([exe, '-Q', '-s', 'run.ys'], cwd=cwd,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               env=env(cwd), timeout=600)
            if p.returncode != 0:
                print('%-24s %s RUN-FAIL rc=%d' % (name, label, p.returncode))
                results[name] = 'RUN-FAIL'
                break
            os.replace(os.path.join(cwd, 'final.json'),
                       os.path.join(cwd, 'final-%s.json' % label))
        if name in results:
            continue
        CELLS_SIM = MINI_SIM
        STRIP = {'cycloneiv_lcell_comb', 'cycloneive_lcell_comb', 'dffeas'}
        ys = ('read_verilog -sv "' + CELLS_SIM + '"\n'
              'read_json final-pristine-renamed.json\n'
              'read_json final-merged.json\n'
              'proc\n'
              'async2sync\n'
              'flatten %s_gold\n'
              'flatten %s\n'
              'equiv_make %s_gold %s %s_equiv\n'
              'delete %s_gold\n'
              'delete %s\n'
              'equiv_simple\n'
              'equiv_induct -seq 16\n'
              'equiv_status\n' % (top, top, top, top, top, top, top))
        pj = json.load(open(os.path.join(cwd, 'final-pristine.json')))
        assert top in pj['modules'], 'top %s missing in pristine json' % top
        # 1) drop behavioral-model modules (loaded from cells_sim.v instead)
        for s in STRIP:
            pj['modules'].pop(s, None)
        # 2) suffix every remaining module (and internal cell refs) with _gold
        old_names = set(pj['modules'].keys())
        renamed = {}
        for mname, mod in pj['modules'].items():
            renamed[mname + '_gold'] = mod
        for mod in renamed.values():
            for cell in mod.get('cells', {}).values():
                if cell.get('type') in old_names:
                    cell['type'] = cell['type'] + '_gold'
        pj['modules'] = renamed
        json.dump(pj, open(os.path.join(cwd, 'final-pristine-renamed.json'), 'w'))
        mj = json.load(open(os.path.join(cwd, 'final-merged.json')))
        for s in STRIP:
            mj['modules'].pop(s, None)
        json.dump(mj, open(os.path.join(cwd, 'final-merged-stripped.json'), 'w'))
        ys = ys.replace('read_json final-merged.json', 'read_json final-merged-stripped.json')
        rc, log = run(PRISTINE, cwd, ys, name)
        out = open(log, errors='replace').read()
        # Verdict: every primary-OUTPUT bit must be proven by equiv_simple.
        # (Unproven *internal* $equiv cells are expected: same-named intermediate
        #  wires after LUT re-partitioning are genuinely different functions and
        #  do not affect I/O equivalence.)
        mj_top = json.load(open(os.path.join(cwd, 'final-merged.json')))['modules'][top]
        out_bits = []
        for pname, p in mj_top['ports'].items():
            if p['direction'] == 'output':
                for i in range(len(p['bits'])):
                    out_bits.append((pname, i if len(p['bits']) > 1 else None))
        sec = out.split('Executing EQUIV_SIMPLE pass.')
        sec = sec[1].split('Executing EQUIV_INDUCT')[0] if len(sec) > 1 else ''
        proved = set()
        cur = None
        for line in sec.splitlines():
            m = re.search(r'Trying to prove \$equiv for \\([^\s:\[]+)(?: \[(\d+)\])?:ezsat', line)
            if m:
                cur = (m.group(1), int(m.group(2)) if m.group(2) else None)
                continue
            if cur and ' success!' in line:
                proved.add(cur)
            if cur and (' failed.' in line or 'Trying to prove' in line):
                cur = None if 'Trying to prove' not in line else cur
        missing = [b for b in out_bits if b not in proved]
        if rc == 0 and not missing:
            status = 'EQUIV'
        elif rc == 0:
            status = 'NOT-EQUIV(missing %d output bits: %s)' % (len(missing), missing[:6])
        else:
            status = 'UNKNOWN(rc=%d)' % rc
        results[name] = status
        print('%-24s %s' % (name, status), flush=True)
        json.dump(results, open(os.path.join(GATE, 'equiv-results.json'), 'w'), indent=1)
    bad = [k for k, v in results.items() if v != 'EQUIV']
    print('EQUIV-PASS ALL' if not bad else 'EQUIV-FAIL: %s' % ','.join(bad))


if __name__ == '__main__':
    main()
