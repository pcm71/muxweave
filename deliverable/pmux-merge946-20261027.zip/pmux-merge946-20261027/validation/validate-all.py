# -*- coding: utf-8 -*-
"""合并二进制一键验收：四例对账 + condition/propagation 回归 + 重放哨兵 + 双层消融。

用法：
  python validate-all.py            # 全部阶段
  python validate-all.py --list     # 列出阶段
  python validate-all.py replay ablation-deep   # 只跑指定阶段（可多个）
  python validate-all.py --force condition       # 忽略既有进度重跑该阶段

判定口径（与 merge3-condition家族.md 一致）：
  - 重放只判 optimized 模式 13/13（baseline 为 946 历史产物，不判）；
  - 消融判 condition 开/关 LUT 一致（浅层）与 13 例无运行时失败 + 售货机深层基线值（深层）；
  - 回归判与 results.json 逐例一致（含 SKIP_CONTRACT 语义例）。
退出码 0 = 全过。
"""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

os.environ['PATH'] = 'C:/opt/msys64/clang64/bin;C:/opt/msys64/usr/bin;' + os.environ.get('PATH', '')
ROOT = Path(__file__).resolve().parent          # merge-946/validation
MERGE = ROOT.parent                             # merge-946
TMP = ROOT / 'tmp'
TMP.mkdir(exist_ok=True)
os.environ['TMPDIR'] = os.environ['TEMP'] = os.environ['TMP'] = str(TMP)
PY = sys.executable


def stage_four_cases():
    r = subprocess.run([PY, str(MERGE / 'four-case-check.py')],
                       cwd=MERGE, capture_output=True, timeout=1800, text=True)
    ok = 'ALL-OK' in (r.stdout + r.stderr)
    detail = [l for l in (r.stdout + r.stderr).splitlines() if 'ref' in l or 'ALL' in l]
    return ok, '; '.join(detail)


def _regression(suite):
    r = subprocess.run([PY, str(ROOT / 'rerun_regression.py'), suite],
                       cwd=ROOT, capture_output=True, timeout=3600, text=True)
    out = r.stdout + r.stderr
    import re
    m = re.findall(rf'{suite}: (\d+)/(\d+) OK', out)
    ok = bool(m) and m[-1][0] == m[-1][1] and 'FAIL' not in out.split('==')[-1]
    tail = [l for l in out.splitlines() if l.startswith('==') or l.startswith('fails')]
    return ok, ' '.join(tail)


def stage_condition():
    return _regression('condition')


def stage_propagation():
    return _regression('propagation')


def stage_replay():
    r = subprocess.run([PY, str(ROOT / 'replay946' / 'replay.py')],
                       cwd=ROOT / 'replay946', capture_output=True, timeout=7200, text=True)
    rep_path = ROOT / 'replay946' / 'replay-report.json'
    if not rep_path.exists():
        return False, 'replay-report.json 未生成: ' + (r.stdout + r.stderr)[-300:]
    rep = json.loads(rep_path.read_text())
    cases = rep['cases']
    opt = [c for c in cases if c['mode'] == 'optimized']
    opt_ok = all(c['status'] == 'OK' for c in opt)
    local = [c for c in cases if c.get('ref_source') == 'local']
    local_ok = all(c['status'] == 'OK' for c in local)
    ok = opt_ok and local_ok and len(opt) == 14
    detail = (f'optimized {sum(1 for c in opt if c["status"]=="OK")}/{len(opt)} OK; '
              f'local-ref {sum(1 for c in local if c["status"]=="OK")}/{len(local)} OK; '
              f'baseline 不判（历史产物，MISMATCH {sum(1 for c in cases if c["mode"]=="baseline" and c["status"]!="OK")} 例）')
    return ok, detail


def stage_ablation_shallow():
    r = subprocess.run([PY, str(ROOT / 'ablation' / 'ablate.py')],
                       cwd=ROOT / 'ablation', capture_output=True, timeout=7200, text=True)
    p = ROOT / 'ablation' / 'ablation.json'
    if not p.exists():
        return False, 'ablation.json 未生成'
    rows = json.loads(p.read_text())
    bad = [x['case'] for x in rows
           if x.get('off') == 'RUNTIME-FAIL' or x.get('on') == 'RUNTIME-FAIL'
           or x['off'] != x['on']]
    ok = not bad and len(rows) == 14
    return ok, f'{len(rows)} 例, off==on {len(rows) - len(bad)}/{len(rows)}' + (
        f', 不一致: {bad}' if bad else '')


def stage_ablation_deep():
    r = subprocess.run([PY, str(ROOT / 'ablation' / 'ablate-deep.py')],
                       cwd=ROOT / 'ablation', capture_output=True, timeout=7200, text=True)
    p = ROOT / 'ablation' / 'ablation-deep.json'
    if not p.exists():
        return False, 'ablation-deep.json 未生成'
    rows = json.loads(p.read_text())
    fails = [x['case'] for x in rows if x.get('status') == 'RUNTIME-FAIL']
    deep_refs = {}
    vend_refs = json.loads((ROOT / 'replay946' / 'vending-refs.json').read_text())
    deep_refs['vending'] = vend_refs.get('deep_flow', {}).get('cond_on_logic')
    i2c_base_path = ROOT / 'ablation' / 'i2c' / 'deep-baseline.json'
    deep_refs['i2c'] = (json.loads(i2c_base_path.read_text())['deep_cond_on']
                        if i2c_base_path.exists() else None)
    ref_bad = []
    for case, want in deep_refs.items():
        row = next((x for x in rows if x['case'] == case), None)
        if row is None or row.get('logic') != want:
            ref_bad.append(case)
    ok = not fails and len(rows) == 14 and not ref_bad
    detail = (f'{len(rows)} 例, RUNTIME-FAIL {len(fails)}; '
              f'深层基线对账: ' + ', '.join(
                  f'{c}={next((x for x in rows if x["case"]==c), {}).get("logic")}/ref {w}'
                  for c, w in deep_refs.items())
              + (f', 偏差: {ref_bad}' if ref_bad else ''))
    return ok, detail


def stage_efficiency_gate():
    r = subprocess.run([PY, str(ROOT / 'efficiency-gate-20261027.py')],
                       cwd=ROOT, capture_output=True, timeout=3600, text=True)
    out = r.stdout + r.stderr
    ok = 'GATE: PASS' in out
    tail = [l for l in out.splitlines() if l.strip().startswith(('test', 'pmux_', 'GATE', '平均'))]
    return ok, ' '.join(tail[-4:]) if ok else out[-400:]


def stage_equivalence():
    r = subprocess.run([PY, str(ROOT / 'equivalence-gate-20261027.py')],
                       cwd=ROOT, capture_output=True, timeout=3600, text=True)
    out = r.stdout + r.stderr
    ok = 'EQUIV-PASS ALL' in out
    tail = [l for l in out.splitlines() if 'EQUIV' in l]
    return ok, ' '.join(tail[-10:]) if ok else out[-400:]


EQY_CASES = ['test%d' % i for i in range(1, 5)] + [
    'pmux_case01_balanced', 'pmux_case02_pipeline', 'pmux_case03_crossbar',
    'pmux_case04_feedback', 'pmux_case05_nested']


def stage_eqy_final():
    # 离线校验 eqy 证明工件：9 例 PASS + 每例 gold/gate/check.eqy 齐全 + 工具链完整。
    base = ROOT / 'eqy-final-20261027'
    missing = []
    for case in EQY_CASES:
        d = base / case
        for f in (Path('check') / 'PASS', 'gold.il', 'gate.il', 'check.eqy', 'input.v'):
            if not (d / f).exists():
                missing.append('%s/%s' % (case, f))
    eqy_dir = ROOT.parent / 'runtime' / 'eqy'
    for f in ('eqy.py', 'eqy_job.py', 'eqy_combine.so', 'eqy_partition.so',
              'eqy_recode.so', 'eqy_support.so'):
        if not (eqy_dir / f).exists():
            missing.append('runtime/eqy/' + f)
    ok = not missing
    return ok, '9/9 PASS 工件齐' if ok else '缺失: ' + ', '.join(missing[:8])


STAGES = [
    ('four-cases', '四例对账（946 基准 288/16/13/26）', stage_four_cases),
    ('condition', 'test_condition 回归 59 组', stage_condition),
    ('propagation', 'test_condition_propagation 回归 13 例', stage_propagation),
    ('replay', '14 例重放哨兵（判 optimized 14/14 + 本地参照）', stage_replay),
    ('ablation-shallow', '浅层消融：condition 开/关 LUT 一致（14 例）', stage_ablation_shallow),
    ('ablation-deep', '深层消融：begin:map_bram 后手动 condition（14 例 + 售货机/I²C 深层基线）', stage_ablation_deep),
    ('efficiency-gate', '9 例效率门（merged vs 官方 pristine 0.69，资源不增 + 耗时 ≤ +5%）', stage_efficiency_gate),
    ('equivalence', '9 例形式等价（merged vs pristine 最终网表，顶层输出 SAT 证明）', stage_equivalence),
    ('eqy-final', '9 例 eqy 归纳证明工件校验（YosysHQ eqy，PASS/网表/工具链齐全）', stage_eqy_final),
]

PROGRESS = ROOT / 'validate-progress.json'


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    force = '--force' in sys.argv
    if '--list' in sys.argv:
        for name, desc, _ in STAGES:
            print(f'{name:18s} {desc}')
        return 0
    only = set(args) if args else None
    progress = json.loads(PROGRESS.read_text()) if PROGRESS.exists() and not force else {}
    report = []
    all_ok = True
    for name, desc, fn in STAGES:
        if only and name not in only:
            continue
        if name in progress and progress[name].get('ok') and not force:
            print(f'[skip] {name} (已 PASS，--force 重跑)')
            report.append(progress[name])
            continue
        print(f'[run ] {name} — {desc}')
        t0 = time.time()
        try:
            ok, detail = fn()
        except subprocess.TimeoutExpired:
            ok, detail = False, '阶段超时'
        dt = time.time() - t0
        rec = dict(stage=name, ok=ok, detail=detail, seconds=round(dt, 1),
                   time=time.strftime('%Y-%m-%d %H:%M:%S'))
        progress[name] = rec
        PROGRESS.write_text(json.dumps(progress, indent=1))
        report.append(rec)
        print(f'[{"PASS" if ok else "FAIL"}] {name} ({dt:.0f}s) {detail}')
        all_ok = all_ok and ok
    print()
    print('=' * 60)
    for rec in report:
        print(f'{"PASS" if rec["ok"] else "FAIL"}  {rec["stage"]:18s} {rec["detail"]}')
    print('=' * 60)
    print('ALL-OK' if all_ok else 'FAILURES-FOUND')
    return 0 if all_ok else 1


if __name__ == '__main__':
    sys.exit(main())
