# -*- coding: utf-8 -*-
"""增量重跑 condition/propagation 回归套件，与 results.json 预期对账。"""
import json
import os
import subprocess
import sys
from pathlib import Path

os.environ['PATH'] = 'C:/opt/msys64/clang64/bin;' + os.environ.get('PATH', '')
Y = str((Path(__file__).resolve().parents[2] / 'runtime' / 'windows' / 'bin' / 'yosys.exe').resolve())
ROOT = Path(__file__).resolve().parent / 'regression'
TMP = Path(__file__).resolve().parent / 'tmp'
TMP.mkdir(exist_ok=True)
os.environ['TMPDIR'] = str(TMP)
os.environ['TEMP'] = str(TMP)
os.environ['TMP'] = str(TMP)


def run_case(suite, case):
    d = ROOT / suite / case
    log = d / 'check.log'
    r = subprocess.run([Y, '-Q', '-s', 'check.ys'], cwd=d,
                       capture_output=True, timeout=300)
    log.write_bytes(r.stdout + r.stderr)
    text = r.stdout.decode(errors='replace') + r.stderr.decode(errors='replace')
    sat = 'PASS' if 'SUCCESS!' in text else 'SKIP_CONTRACT'
    cb = None
    for line in text.splitlines():
        if 'pmux_condition:' in line and 'changed_bits=' in line:
            cb = int(line.rsplit('changed_bits=', 1)[1].split()[0])
    return r.returncode, sat, cb


def main():
    suite = sys.argv[1]
    suite_dir = ROOT / suite
    expected = {c['case']: c for c in json.loads(
        (suite_dir / 'results.json').read_text())['cases']}
    progress_path = suite_dir / 'rerun-progress.json'
    done = json.loads(progress_path.read_text()) if progress_path.exists() else {}
    fails = []
    for case in sorted(expected):
        if case in done:
            continue
        rc, sat, cb = run_case(suite, case)
        exp = expected[case]
        want_sat = exp.get('sat', 'PASS')
        ok = (rc == 0 and sat == want_sat and cb == exp['changed_bits'])
        if ok and 'edits' in exp:
            edits = json.loads((suite_dir / case / 'edits.json').read_text())
            if isinstance(edits, dict):
                n = len(edits.get('edits', []))
            else:
                n = len(edits)
            ok = (n == exp['edits'])
        done[case] = dict(rc=rc, sat=sat, changed_bits=cb,
                          expected=exp, ok=ok)
        progress_path.write_text(json.dumps(done, indent=1))
        print(('OK ' if ok else 'FAIL ') + case, f'rc={rc} sat={sat} cb={cb} exp_cb={exp["changed_bits"]}')
        if not ok:
            fails.append(case)
    total = len(done)
    passed = sum(1 for v in done.values() if v['ok'])
    print(f'== {suite}: {passed}/{total} OK, {len(fails)} FAIL ==')
    if fails:
        print('fails:', fails)
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main())
