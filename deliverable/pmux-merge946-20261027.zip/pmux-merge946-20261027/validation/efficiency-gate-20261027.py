# -*- coding: utf-8 -*-
"""Efficiency gate: merged (pmux-946) vs pristine yosys 0.69 official baseline.

Protocol (per FPGA contest Q&A):
  - warm up pristine + case 10 times before timing
  - run pristine first, optimized (merged) second, alternating
  - small cases (<1s): if time delta > 5%, re-measure 5x and average -> we do 5 timed rounds by default
Resources: logic = lut + inverter (inverters count as logic cells per official Q&A).
Cell counts are read from the output netlist JSON (write_json), per official rule.
"""
import json
import os
import shutil
import subprocess
import sys
import time

_HERE = os.path.dirname(os.path.abspath(__file__))
if os.path.exists(os.path.join(os.path.dirname(_HERE), 'runtime', 'windows', 'bin', 'yosys.exe')):
    # 交付包内布局：merged 用包内 runtime；pristine 为对照组，不在包内，
    # 评审方需用官方 Yosys 0.69 自编译基线，并用环境变量 PRISTINE_YOSYS 指向其 yosys.exe。
    _PKG = os.path.dirname(_HERE)
    MERGED_EXE = os.path.join(_PKG, 'runtime', 'windows', 'bin', 'yosys.exe')
    PRISTINE_EXE = os.environ.get('PRISTINE_YOSYS')
    if not PRISTINE_EXE:
        _cand = os.path.join(os.path.dirname(_PKG), 'pristine-069', 'build', 'yosys.exe')
        PRISTINE_EXE = _cand if os.path.exists(_cand) else r'C:\pristine-yosys-069\yosys.exe'
    OUTDIR = os.path.join(_PKG, 'validation', 'efficiency-gate-20261027')
    sys.path.insert(0, os.path.join(_PKG, 'scripts'))
    sys.path.insert(0, os.path.join(os.path.dirname(_PKG), 'scripts'))
    FOUR = os.path.join(_PKG, 'validation', 'four-cases')
    _PMUX_SRC = None  # 五例输入已在 OUTDIR/<case>/input.v
else:
    ROOT = os.path.dirname(os.path.dirname(_HERE))   # work-v3
    PROJ = os.path.dirname(ROOT)
    MERGED_EXE = os.path.join(ROOT, 'merge-946', 'build', 'install', 'bin', 'yosys.exe')
    PRISTINE_EXE = os.path.join(ROOT, 'pristine-069', 'build', 'yosys.exe')
    OUTDIR = os.path.join(ROOT, 'merge-946', 'validation', 'efficiency-gate-20261027')
    sys.path.insert(0, os.path.join(ROOT, 'scripts'))
    FOUR = os.path.join(ROOT, 'merge-946', 'validation', 'four-cases')
    _PMUX_SRC = os.path.join(PROJ, 'pmux_cases')
from resources import count  # noqa: E402

CASES = ([('test%d' % i, os.path.join(FOUR, 'test%d.v' % i), 'test%d' % i) for i in range(1, 5)] +
         [('pmux_case0%d_' % i + s,
           (os.path.join(_PMUX_SRC, 'pmux_case0%d_%s.v' % (i, s)) if _PMUX_SRC
            else os.path.join(OUTDIR, 'pmux_case0%d_%s' % (i, s), 'input.v')),
           'pmux_case0%d_%s' % (i, s))
          for i, s in [(1, 'balanced'), (2, 'pipeline'), (3, 'crossbar'), (4, 'feedback'), (5, 'nested')]])

CLANG64 = r'C:\opt\msys64\clang64\bin'

RUN_YS = ('read_verilog input.v\n'
          'hierarchy -top {top}\n'
          'scratchpad -set abc9.nocleanup 1\n'
          'synth_intel -family cycloneiv -top {top}\n'
          'write_json final.json\n')


def make_env(cwd):
    env = dict(os.environ)
    env['PATH'] = CLANG64 + os.pathsep + env.get('PATH', '')
    tmp = os.path.join(cwd, 'tmp')
    os.makedirs(tmp, exist_ok=True)
    env['TEMP'] = tmp
    env['TMP'] = tmp
    env['TMPDIR'] = tmp
    return env


def run_one(exe, cwd, tag):
    log = os.path.join(cwd, 'run-%s.log' % tag)
    t0 = time.perf_counter()
    with open(log, 'w') as lf:
        p = subprocess.run([exe, '-s', 'run.ys'], cwd=cwd, stdout=lf, stderr=subprocess.STDOUT,
                           env=make_env(cwd))
    wall = time.perf_counter() - t0
    if p.returncode != 0:
        raise RuntimeError('%s rc=%d, see %s' % (tag, p.returncode, log))
    return wall


def main():
    rounds = int(sys.argv[sys.argv.index('--rounds') + 1]) if '--rounds' in sys.argv else 7
    warmup = int(sys.argv[sys.argv.index('--warmup') + 1]) if '--warmup' in sys.argv else 10
    sel = None
    if '--cases' in sys.argv:
        sel = set(sys.argv[sys.argv.index('--cases') + 1].split(','))
    results_path = os.path.join(OUTDIR, 'results.json')
    results = {}
    if os.path.exists(results_path):
        results = json.load(open(results_path))
    for name, src, top in CASES:
        if sel and name not in sel:
            continue
        cwd = os.path.join(OUTDIR, name)
        os.makedirs(cwd, exist_ok=True)
        dst_input = os.path.join(cwd, 'input.v')
        if os.path.abspath(src) != os.path.abspath(dst_input):
            shutil.copyfile(src, dst_input)
        with open(os.path.join(cwd, 'run.ys'), 'w') as f:
            f.write(RUN_YS.format(top=top))
        print('=== %s: warmup pristine x%d, merged x3' % (name, warmup), flush=True)
        for _ in range(warmup):
            run_one(PRISTINE_EXE, cwd, 'warmup-pristine')
        for i in range(3):
            run_one(MERGED_EXE, cwd, 'warmup-merged-%d' % i)
        rec = {'top': top, 'pristine': {'walls': []}, 'merged': {'walls': []}}
        for r in range(rounds):
            rec['pristine']['walls'].append(run_one(PRISTINE_EXE, cwd, 'pristine-r%d' % r))
            rec['merged']['walls'].append(run_one(MERGED_EXE, cwd, 'merged-r%d' % r))
            print('  round %d: pristine %.3fs  merged %.3fs' % (
                r, rec['pristine']['walls'][-1], rec['merged']['walls'][-1]), flush=True)
        for label, exe in [('pristine', PRISTINE_EXE), ('merged', MERGED_EXE)]:
            final_json = os.path.join(cwd, 'final.json')
            if os.path.exists(final_json):
                os.remove(final_json)
            run_one(exe, cwd, 'final-' + label)
            stats = count(json.load(open(final_json)), top)
            rec[label]['resources'] = {k: stats[k] for k in ['lut', 'inverter', 'sequential_bits', 'io', 'logic']}
            w = sorted(rec[label]['walls'])
            trimmed = w[:-1] if len(w) >= 4 else w   # 去最大值抗冷启动/干扰
            rec[label]['avg_wall'] = sum(trimmed) / len(trimmed)
            rec[label]['trimmed_from'] = w[-1] if len(w) >= 4 else None
        results[name] = rec
        json.dump(results, open(results_path, 'w'), indent=1)
    print('\n==== SUMMARY ====')
    hdr = '%-24s %8s %8s %8s %8s %8s %8s %8s' % ('case', 'p_lut', 'm_lut', 'p_inv', 'm_inv',
                                                 'p_logic', 'm_logic', 'd_logic%')
    print(hdr)
    gate_fail = []
    for name, rec in results.items():
        pr, mr = rec['pristine']['resources'], rec['merged']['resources']
        dl = (mr['logic'] - pr['logic']) / max(pr['logic'], 1) * 100
        dt = (rec['merged']['avg_wall'] - rec['pristine']['avg_wall']) / rec['pristine']['avg_wall'] * 100
        flag = ''
        if mr['logic'] > pr['logic']:
            flag += ' LOGIC-UP!'
            gate_fail.append(name)
        if dt > 5:
            flag += ' TIME>5%!'
            gate_fail.append(name)
        print('%-24s %8d %8d %8d %8d %8d %8d %+8.2f%%  time p=%.3fs m=%.3fs (%+.2f%%)%s' % (
            name, pr['lut'], mr['lut'], pr['inverter'], mr['inverter'], pr['logic'], mr['logic'],
            dl, rec['pristine']['avg_wall'], rec['merged']['avg_wall'], dt, flag))
    print('\nGATE:', 'FAIL ' + ','.join(gate_fail) if gate_fail else 'PASS (all cases logic<=baseline, time<=+5%)')
    json.dump(results, open(results_path, 'w'), indent=1)


if __name__ == '__main__':
    main()
