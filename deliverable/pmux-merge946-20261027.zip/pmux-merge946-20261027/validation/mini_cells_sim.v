// Minimal behavioral models for formal equivalence only (not for mapping).
// lcell_comb as plain LUT4 via constant-index mux tree (sat-friendly, no $shiftx),
// dffeas with full async/sync control.
`timescale 1ps/1ps

module cycloneiv_lcell_comb(output combout, output cout,
                            input dataa, datab, datac, datad, cin);
    parameter lut_mask = 16'hFFFF;
    wire d0 = dataa, d1 = datab, d2 = datac, d3 = datad;
    wire [7:0]  lev0;
    wire [3:0]  lev1;
    wire [1:0]  lev2;
    assign lev0[0] = d0 ? lut_mask[1]  : lut_mask[0];
    assign lev0[1] = d0 ? lut_mask[3]  : lut_mask[2];
    assign lev0[2] = d0 ? lut_mask[5]  : lut_mask[4];
    assign lev0[3] = d0 ? lut_mask[7]  : lut_mask[6];
    assign lev0[4] = d0 ? lut_mask[9]  : lut_mask[8];
    assign lev0[5] = d0 ? lut_mask[11] : lut_mask[10];
    assign lev0[6] = d0 ? lut_mask[13] : lut_mask[12];
    assign lev0[7] = d0 ? lut_mask[15] : lut_mask[14];
    assign lev1[0] = d1 ? lev0[1] : lev0[0];
    assign lev1[1] = d1 ? lev0[3] : lev0[2];
    assign lev1[2] = d1 ? lev0[5] : lev0[4];
    assign lev1[3] = d1 ? lev0[7] : lev0[6];
    assign lev2[0] = d2 ? lev1[1] : lev1[0];
    assign lev2[1] = d2 ? lev1[3] : lev1[2];
    assign combout = d3 ? lev2[1] : lev2[0];
    assign cout = 1'b0;
endmodule

module cycloneive_lcell_comb(output combout, output cout,
                             input dataa, datab, datac, datad, cin);
    parameter lut_mask = 16'hFFFF;
    wire d0 = dataa, d1 = datab, d2 = datac, d3 = datad;
    wire [7:0]  lev0;
    wire [3:0]  lev1;
    wire [1:0]  lev2;
    assign lev0[0] = d0 ? lut_mask[1]  : lut_mask[0];
    assign lev0[1] = d0 ? lut_mask[3]  : lut_mask[2];
    assign lev0[2] = d0 ? lut_mask[5]  : lut_mask[4];
    assign lev0[3] = d0 ? lut_mask[7]  : lut_mask[6];
    assign lev0[4] = d0 ? lut_mask[9]  : lut_mask[8];
    assign lev0[5] = d0 ? lut_mask[11] : lut_mask[10];
    assign lev0[6] = d0 ? lut_mask[13] : lut_mask[12];
    assign lev0[7] = d0 ? lut_mask[15] : lut_mask[14];
    assign lev1[0] = d1 ? lev0[1] : lev0[0];
    assign lev1[1] = d1 ? lev0[3] : lev0[2];
    assign lev1[2] = d1 ? lev0[5] : lev0[4];
    assign lev1[3] = d1 ? lev0[7] : lev0[6];
    assign lev2[0] = d2 ? lev1[1] : lev1[0];
    assign lev2[1] = d2 ? lev1[3] : lev1[2];
    assign combout = d3 ? lev2[1] : lev2[0];
    assign cout = 1'b0;
endmodule

module dffeas(output reg q,
              input d, clk, ena, clrn, prn, aload, asdata, sclr, sload);
    parameter power_up = "low";
    parameter is_wysiwyg = "false";
    initial q = (power_up == "high") ? 1'b1 : 1'b0;
    always @(posedge clk or negedge clrn or negedge prn or posedge aload) begin
        if (!clrn) q <= 1'b0;
        else if (!prn) q <= 1'b1;
        else if (aload) q <= asdata;
        else if (ena) begin
            if (sclr) q <= 1'b0;
            else if (sload) q <= asdata;
            else q <= d;
        end
    end
endmodule
