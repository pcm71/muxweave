# -*- coding: utf-8 -*-
"""946 侧 12 例资产重放：合并二进制复跑 baseline/optimized，对照 946 results.json 的 resources.logic。"""
import json
import os
import subprocess
import sys
from pathlib import Path

os.environ['PATH'] = 'C:/opt/msys64/clang64/bin;C:/opt/msys64/usr/bin;' + os.environ.get('PATH', '')
ROOT = Path(__file__).resolve().parent
_tmp = ROOT.parent / 'tmp'
_tmp.mkdir(exist_ok=True)
os.environ['TMPDIR'] = os.environ['TEMP'] = os.environ['TMP'] = str(_tmp)
Y = str((Path(__file__).resolve().parents[2] / 'runtime' / 'windows' / 'bin' / 'yosys.exe').resolve())
sys.path.insert(0, str((ROOT.parents[1] / '..' / 'scripts').resolve()))
from resources import count  # noqa: E402
from pathlib import Path  # noqa: E402

PMUX = Path(r'C:\Users\LEGION\Desktop\PMUX\pmuxv2')
try:
    REF = json.load(open(PMUX / 'pmux-946-clean-20261026' / 'pmux-946-clean-20261026'
                         / 'validation' / 'runtime-efficiency-20261025' / 'main-single-evaluation' / 'results.json'))
    ref = {r['case']: r['resources'] for r in REF['records']}
except OSError:
    ref = {}  # 946 历史参照不在包内时，仅判本地参照用例
TOPS = {'vending': 'vending_machine_top', 'i2c': 'i2c_master'}
# 本地参照：946 无历史记录的用例（vending/i2c 哨兵），基线值在本机合并二进制上建立。
LOCAL_REFS = {}
for local_refs_path in sorted(ROOT.glob('*-refs.json')):
    lr = json.loads(local_refs_path.read_text())
    LOCAL_REFS[lr['case']] = lr['resources']
    LOCAL_REFS[lr['case']]['_provenance'] = lr.get('provenance', 'local')

all_ok = True
report = []
for case_dir in sorted(ROOT.iterdir()):
    if not case_dir.is_dir():
        continue
    case = case_dir.name
    top = TOPS.get(case, case)
    for mode in ['baseline', 'optimized']:
        d = case_dir / mode
        ys = (d / 'export.ys').read_text()
        if 'abc9.nocleanup' not in ys:
            ys = ys.replace('read_verilog input.v',
                            'read_verilog input.v\nscratchpad -set abc9.nocleanup 1')
        (d / 'replay.ys').write_text(ys)
        r = subprocess.run([Y, '-Q', '-s', 'replay.ys'], cwd=d, capture_output=True, timeout=300)
        (d / 'replay.log').write_bytes(r.stdout + r.stderr)
        if r.returncode != 0:
            print(case, mode, 'RUNTIME-FAIL')
            all_ok = False
            report.append(dict(case=case, mode=mode, status='RUNTIME-FAIL'))
            continue
        got = count(json.loads((d / 'final.json').read_text()), top)['logic']
        if case in ref:
            want = ref[case][mode]['logic']
            provenance = '946'
        elif case in LOCAL_REFS:
            want = LOCAL_REFS[case][mode]['logic']
            provenance = 'local'
        else:
            print(case, mode, got, 'NO-REF')
            all_ok = False
            report.append(dict(case=case, mode=mode, got=got, status='NO-REF'))
            continue
        ok = got == want
        all_ok = all_ok and ok
        report.append(dict(case=case, mode=mode, got=got, ref=want,
                           status='OK' if ok else 'MISMATCH', ref_source=provenance))
        print(case, mode, got, 'ref', want, f'[{provenance}]',
              'OK' if ok else 'MISMATCH')
(ROOT / 'replay-report.json').write_text(json.dumps(dict(all_ok=all_ok, cases=report), indent=1))
print('ALL-OK' if all_ok else 'MISMATCHES-FOUND')
