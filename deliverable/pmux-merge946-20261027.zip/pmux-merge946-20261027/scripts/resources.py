"""Count reachable physical instances in Yosys write_json output."""
from collections import Counter
import re

LUT = {'$lut', 'cycloneiv_lcell_comb', 'cycloneive_lcell_comb'}
INV = {'$not', '$_NOT_'}
IO = {'$__inpad', '$__outpad', '$__iopad', 'cycloneiv_io', 'cycloneive_io',
      'cycloneiv_io_ibuf', 'cycloneiv_io_obuf', 'cycloneive_io_ibuf', 'cycloneive_io_obuf'}
FF = {'$ff', '$dff', '$dffe', '$adff', '$adffe', '$aldff', '$aldffe', '$sdff', '$sdffe',
      '$sdffce', '$dffsr', '$dffsre', '$dlatch', '$adlatch', '$dlatchsr', '$sr', 'dffeas'}


def truth(value):
    return value not in (None, '', 0, '0') and (not isinstance(value, str) or set(value) != {'0'})


def count(netlist, top):
    modules = netlist['modules']
    totals = Counter(lut=0, inverter=0, sequential_bits=0, io=0)
    other = Counter()
    def visit(name, active):
        if name in active: raise ValueError('Recursive hierarchy: '+name)
        for cell in modules[name].get('cells', {}).values():
            t = cell['type']
            if t in LUT: totals['lut'] += 1
            elif t in INV: totals['inverter'] += len(cell['connections'].get('Y', [0]))
            elif t in FF or re.match(r'^\$_(DFF|DFFE|SDFF|SDFFE|SDFFCE|DFFSR|DFFSRE|DLATCH|SR|FF)_', t):
                totals['sequential_bits'] += len(cell['connections'].get('Q', [0]))
            elif t in IO: totals['io'] += 1
            elif t in modules and not any(truth(modules[t].get('attributes', {}).get(a)) for a in ['blackbox', 'whitebox']):
                visit(t, active | {name})
            else: other[t] += 1
    visit(top, set())
    totals['logic'] = totals['lut']+totals['inverter']
    return dict(totals, other=dict(other), port_bits={k: sum(len(p['bits']) for p in modules[top]['ports'].values()
                if p['direction'] == k) for k in ['input', 'output', 'inout']})


def violations(baseline, optimized):
    errors = []
    for key in ['sequential_bits', 'io']:
        if optimized[key] > baseline[key]: errors.append(key+' increased')
    if optimized['port_bits'] != baseline['port_bits']: errors.append('port widths changed')
    for t, n in optimized['other'].items():
        if n > baseline['other'].get(t, 0): errors.append(t+' increased')
    return errors
