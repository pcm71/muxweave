# -*- coding: utf-8 -*-
"""合并二进制四例对账：对比 946 参照值 test1=288, test2=16, test3=13, test4=26。"""
import json
import os
import subprocess
import sys
from pathlib import Path

os.environ['PATH'] = 'C:/opt/msys64/clang64/bin;C:/opt/msys64/usr/bin;' + os.environ.get('PATH', '')

ROOT = Path(__file__).resolve().parent
Y = str((ROOT / 'runtime' / 'windows' / 'bin' / 'yosys.exe').resolve())
sys.path.insert(0, str((ROOT / 'scripts').resolve()))
from resources import count  # noqa: E402

ref = json.load(open(ROOT / 'validation-ref-946.json'))
out = ROOT / 'validation' / 'four-cases'
all_ok = True
for name in ['test1', 'test2', 'test3', 'test4']:
    d = out / name
    d.mkdir(parents=True, exist_ok=True)
    src = (out / (name + '.v')).resolve()
    (d / 'run.ys').write_text(
        'read_verilog ' + str(src) + chr(10)
        + 'hierarchy -top ' + name + chr(10)
        + 'scratchpad -set abc9.nocleanup 1' + chr(10)
        + 'synth_intel -family cycloneiv -top ' + name + chr(10)
        + 'write_json final.json' + chr(10)
    )
    r = subprocess.run([Y, '-Q', '-s', 'run.ys'], cwd=d, capture_output=True, timeout=300)
    (d / 'run.log').write_bytes(r.stdout + r.stderr)
    if r.returncode != 0:
        print(name, 'RUNTIME-FAIL', 'ref', ref[name])
        all_ok = False
        continue
    got = count(json.loads((d / 'final.json').read_text()), name)['logic']
    ok = (got == ref[name])
    all_ok = all_ok and ok
    print(name, got, 'ref', ref[name], 'OK' if ok else 'MISMATCH')
print('ALL-OK' if all_ok else 'MISMATCHES-FOUND')
