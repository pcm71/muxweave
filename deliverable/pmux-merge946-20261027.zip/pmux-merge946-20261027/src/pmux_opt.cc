/*
 * PMUX structure analysis and configurable abc9 LUT mapping, Yosys 0.69.
 * Default: one fast profile, without design copies or a no-regression claim.
 * Opt-in multi-candidate mode includes the exact official abc9 command and
 * retains the best valid mapped snapshot. Runtime and memory must be measured.
 */
#include "kernel/yosys.h"
#include "kernel/sigtools.h"
#include "pmux_resources.h"
#include "pmux_features.h"
#include <memory>
#include <algorithm>
#include <chrono>
#include <fstream>
#include <iomanip>
#include <map>
#include <sstream>
#include <string>
#include <vector>

USING_YOSYS_NAMESPACE
PRIVATE_NAMESPACE_BEGIN

using PmuxFeatures = pmux::FeatureSummary;

static void cache_features(RTLIL::Design *design, const PmuxFeatures &f)
{
    design->scratchpad_set_string("pmux_opt.features.top", design->top_module()->name.str());
    design->scratchpad_set_int("pmux_opt.features.pmux", f.pmux_count);
    design->scratchpad_set_int("pmux_opt.features.mux", f.mux_count);
    design->scratchpad_set_int("pmux_opt.features.reuse", f.bits_with_reuse_total);
    design->scratchpad_set_int("pmux_opt.features.shared", f.shared_bits_total);
    design->scratchpad_set_int("pmux_opt.features.width", f.max_w);
    design->scratchpad_set_int("pmux_opt.features.choices", f.max_k);
}

struct Candidate {
    std::string name, body, lutopt = "-lut", lutvalue = "4";
};

// Kept byte-for-byte in abc_scripts/area_script.abc; tests verify synchronization.
static const char *SCRIPT_AREA =
    "&rrr -T 10 -X 2\n&dch -f -r\n&compress3rs\n&if -a -F 16 -v\n";
static const char *SCRIPT_FAST = "&sweep\n&dc2\n&dch -s -f -r\n&if -a -v\n";
static const char *SCRIPT_NO_RRR = "&dch -f -r\n&compress3rs\n&if -a -F 16 -v\n";
static const char *SCRIPT_BUDGET1 = "&rrr -T 1 -X 1\n&dch -f -r\n&compress3rs\n&if -a -F 16 -v\n";
static const char *SCRIPT_BUDGET2 = "&rrr -T 2 -X 1\n&dch -f -r\n&compress3rs\n&if -a -F 16 -v\n";
static const char *SCRIPT_BALANCED = "&dch -p -f -r\n&compress3rs\n&if -a -F 16 -v\n";

static Candidate profile(const std::string &name)
{
    if (name == "area") return {name, SCRIPT_AREA};
    if (name == "fast") return {name, SCRIPT_FAST};
    if (name == "no-rrr") return {name, SCRIPT_NO_RRR};
    if (name == "budget1") return {name, SCRIPT_BUDGET1};
    if (name == "budget2") return {name, SCRIPT_BUDGET2};
    if (name == "balanced") return {name, SCRIPT_BALANCED};
    if (name == "wide") return {name, SCRIPT_AREA, "-luts", "4,4,4,1"};
    if (name == "official") return {name, ""};
    log_cmd_error("pmux_opt: unknown profile '%s'.\n", name);
}

// ABC9 supports +inline scripts. Commas encode spaces, quotes preserve the
// semicolons through abc9's internal command forwarding. No private temp files.
static std::vector<std::string> command(const Candidate &c, bool dff)
{
    std::vector<std::string> args = {"abc9", c.lutopt, c.lutvalue};
    if (c.name == "official") {
        args.insert(args.end(), {"-W", "300"});
    } else {
        std::string encoded = "\"+";
        for (char ch : c.body) {
            if (ch == ' ' || ch == '\t') encoded += ',';
            else if (ch == '\n') encoded += ';';
            else encoded += ch;
        }
        encoded += '"';
        args.insert(args.end(), {"-script", encoded});
    }
    if (dff) args.push_back("-dff");
    return args;
}

static std::string joined(const std::vector<std::string> &args)
{
    std::string s;
    for (auto &a : args) { if (!s.empty()) s += ' '; s += a; }
    return s;
}

// Unique names avoid overwriting a user's design -save slot. Both pre and best
// snapshots are released on normal completion and recoverable command errors.
struct Snapshots {
    RTLIL::Design *design;
    std::string pre, best;
    dict<std::string, std::string> scratchpad;
    explicit Snapshots(RTLIL::Design *d) : design(d), scratchpad(d->scratchpad) {
        static unsigned sequence = 0;
        do {
            pre = "pmux_pre_" + std::to_string(++sequence);
            best = "pmux_best_" + std::to_string(sequence);
        } while (saved_designs.count(pre) || saved_designs.count(best));
    }
    void save(const std::string &name) { Pass::call(design, std::vector<std::string>{"design", "-save", name}); }
    void load(const std::string &name) {
        Pass::call(design, std::vector<std::string>{"design", "-load", name});
        design->scratchpad = scratchpad;
    }
    ~Snapshots() {
        for (auto &name : {pre, best}) {
            auto it = saved_designs.find(name);
            if (it != saved_designs.end()) { delete it->second; saved_designs.erase(it); }
        }
    }
};

struct Result {
    std::string name, cmd, status = "NOT_RUN", reason;
    pmux::Resources resources;
    double wall_seconds = 0;
};

struct PmuxOptPass : public Pass {
    PmuxOptPass() : Pass("pmux_opt", "analyze PMUX structure and map with validated abc9 candidates") {}
    void help() override {
        log("    pmux_opt [options]\n\n");
        log("    -profile area|fast|no-rrr|budget1|budget2|balanced|wide|official\n");
        log("        Single profile. Default fast avoids the timed RRR search.\n");
        log("        area preserves the original script; other profiles are experiments.\n");
        log("    -candidates 1|2|3|4\n");
        log("        1: selected profile, no baseline comparison (default).\n");
        log("        2: official+area; 3: official+area+fast; 4: also wide.\n");
        log("        Multi-candidate mode costs additional time and snapshot memory.\n");
        log("        Cannot combine >1 candidates with a non-area profile.\n");
        log("    -json <file>     Write actual commands, wall times and resource counts.\n");
        log("    -analyze-only    Cache PMUX features on this design; do not map.\n");
        log("    -dry-run        Report planned commands without mapping or temp files.\n");
        log("    -dff            Forward synth_intel's sequential mapping option.\n");
        log("    -quiet          Suppress this pass's progress messages.\n\n");
        log("For synth_intel use scratchpad keys pmux_opt.profile, pmux_opt.candidates,\n");
        log("pmux_opt.json. The baseline binary ignores these keys.\n");
        log("LUT and inverter counts are measured after abc9 + clean/opt -fast/clean,\n");
        log("before final device mapping. Formal equivalence is checked externally.\n");
    }
    void execute(std::vector<std::string> args, RTLIL::Design *design) override {
        const auto started = std::chrono::steady_clock::now();
        std::string selected = design->scratchpad_get_string("pmux_opt.profile", "fast");
        bool profile_explicit = design->scratchpad.count("pmux_opt.profile");
        std::string json_file = design->scratchpad_get_string("pmux_opt.json");
        int candidates = design->scratchpad_get_int("pmux_opt.candidates", 1);
        bool dff = false, dry_run = false, quiet = false, analyze_only = false;
        size_t argidx;
        for (argidx = 1; argidx < args.size(); ++argidx) {
            auto a = args[argidx];
            if (a == "-profile" && argidx+1 < args.size()) { selected = args[++argidx]; profile_explicit = true; continue; }
            if (a == "-json" && argidx+1 < args.size()) { json_file = args[++argidx]; continue; }
            if (a == "-candidates" && argidx+1 < args.size()) {
                auto n = args[++argidx];
                if (n.size() != 1 || n[0] < '1' || n[0] > '4')
                    log_cmd_error("pmux_opt: candidates must be an integer from 1 to 4.\n");
                candidates = n[0]-'0'; continue;
            }
            if (a == "-dff") { dff = true; continue; }
            if (a == "-dry-run") { dry_run = true; continue; }
            if (a == "-quiet") { quiet = true; continue; }
            if (a == "-analyze-only") { analyze_only = true; continue; }
            break;
        }
        extra_args(args, argidx, design);
        if (!design->full_selection()) log_cmd_error("pmux_opt requires a full design selection.\n");
        if (candidates < 1 || candidates > 4) log_cmd_error("Invalid pmux_opt.candidates scratchpad value.\n");
        if (candidates > 1 && !profile_explicit) selected = "area";
        if (candidates > 1 && selected != "area") log_cmd_error("Use a single candidate with -profile.\n");
        auto chosen = profile(selected); // validate options even in dry-run mode
        if (!design->top_module()) log_cmd_error("pmux_opt: run hierarchy -top <name> first.\n");
        PmuxFeatures features;
        if (analyze_only || !json_file.empty()) features = pmux::analyze_features(design);
        if (analyze_only) { cache_features(design, features); return; }
        // Reuse only immutable built-in classification within this invocation.
        CellTypes resource_types;
        resource_types.setup();
        auto before = pmux::count_resources(design, resource_types);
        if (!features.pmux_count && !features.mux_count &&
            design->scratchpad_get_string("pmux_opt.features.top") == design->top_module()->name.str()) {
            features.pmux_count = design->scratchpad_get_int("pmux_opt.features.pmux");
            features.mux_count = design->scratchpad_get_int("pmux_opt.features.mux");
            features.bits_with_reuse_total = design->scratchpad_get_int("pmux_opt.features.reuse");
            features.shared_bits_total = design->scratchpad_get_int("pmux_opt.features.shared");
            features.max_w = design->scratchpad_get_int("pmux_opt.features.width");
            features.max_k = design->scratchpad_get_int("pmux_opt.features.choices");
        }
        if (!dry_run) design->scratchpad_unset("pmux_opt.features.top");
        std::vector<Candidate> pool;
        if (candidates == 1) pool.push_back(chosen);
        else {
            pool = {profile("official"), profile("area")};
            if (candidates >= 3) pool.push_back(profile("fast"));
            if (candidates >= 4) pool.push_back(profile("wide"));
        }
        std::vector<Result> results;
        int best = -1;
        std::string failure;
        pmux::Resources final_resources;
        std::unique_ptr<Snapshots> snapshots;
        if (!dry_run && pool.size() > 1) {
            snapshots.reset(new Snapshots(design)); snapshots->save(snapshots->pre);
        }
        dict<std::string, std::string> best_scratchpad;
        try {
            for (auto &c : pool) {
                Result r; r.name = c.name; r.cmd = joined(command(c, dff));
                if (!quiet) log("pmux_opt: candidate %s: %s\n", r.name, r.cmd);
                if (!dry_run) {
                    if (pool.size() > 1) snapshots->load(snapshots->pre);
                    auto t = std::chrono::steady_clock::now();
                    try {
                        auto scope = logger().error_throw_scope();
                        Pass::call(design, command(c, dff));
                        Pass::call(design, "clean; opt -fast; clean");
                        r.resources = pmux::count_resources(design, resource_types);
                        r.reason = pmux::reject_reason(before, r.resources);
                        r.status = r.reason.empty() ? "VALID" : "REJECTED";
                    } catch (const log_cmd_error_exception &) {
                        r.status = "ERROR";
                        r.reason = "recoverable Yosys command error; see log";
                    }
                    r.wall_seconds = std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();
                    if (r.status == "VALID" && (best < 0 || r.resources.logic() < results[best].resources.logic())) {
                        best = int(results.size());
                        if (pool.size() > 1) snapshots->save(snapshots->best);
                        if (pool.size() > 1) best_scratchpad = design->scratchpad;
                    }
                    if (!quiet) log("pmux_opt: %s %s, LUT=%lld INV=%lld sequential_bits=%lld time=%.6fs %s\n",
                        r.name, r.status, (long long)r.resources.lut, (long long)r.resources.inverter,
                        (long long)r.resources.sequential, r.wall_seconds, r.reason);
                }
                results.push_back(r);
            }
            if (!dry_run) {
                if (best < 0) {
                    failure = "no candidate satisfied the resource constraints";
                    if (pool.size() > 1) snapshots->load(snapshots->pre);
                } else {
                    if (pool.size() > 1) {
                        snapshots->load(snapshots->best);
                        design->scratchpad = best_scratchpad;
                    }
                    final_resources = pool.size() > 1 ? pmux::count_resources(design, resource_types) : results[best].resources;
                    if (pool.size() > 1 && pmux::resources_json(final_resources) != pmux::resources_json(results[best].resources))
                        log_cmd_error("pmux_opt: selected snapshot does not match the recorded result.\n");
                }
            }
        } catch (...) {
            if (!dry_run && pool.size() > 1) snapshots->load(snapshots->pre);
            throw;
        }
        const bool baseline_valid = pool.size() > 1 && results[0].status == "VALID";
        const bool fallback = best >= 0 && pool.size() > 1 && results[best].name == "official";
        if (!json_file.empty()) {
            std::ofstream out(json_file);
            if (!out) log_cmd_error("pmux_opt: cannot write %s.\n", json_file);
            out << std::setprecision(12)
                << "{\n\"schema_version\":2,\"yosys_version\":\"" << pmux::json_escape(yosys_version_str)
                << "\",\"stage\":\"abc9_then_clean_opt_fast_clean\",\"dry_run\":" << (dry_run ? "true":"false")
                << ",\"profile\":\"" << selected << "\",\"candidates_requested\":" << candidates
                << ",\"features\":{\"pmux\":" << features.pmux_count << ",\"mux\":" << features.mux_count
                << ",\"shared_bits\":" << features.shared_bits_total << ",\"max_width\":" << features.max_w
                << ",\"max_choices\":" << features.max_k << "},\"before\":" << pmux::resources_json(before)
                << ",\"candidates\":[";
            for (size_t i=0; i<results.size(); ++i) {
                const auto &r = results[i];
                if (i) out << ',';
                out << "{\"name\":\"" << r.name << "\",\"command\":\"" << pmux::json_escape(r.cmd)
                    << "\",\"status\":\"" << r.status << "\",\"reason\":\"" << pmux::json_escape(r.reason)
                    << "\",\"wall_seconds\":" << r.wall_seconds << ",\"resources\":";
                out << (r.status == "VALID" || r.status == "REJECTED" ? pmux::resources_json(r.resources) : "null") << '}';
            }
            out << "],\"winner\":" << (best < 0 ? "null" : '"'+results[best].name+'"')
                << ",\"after\":" << (best < 0 ? "null" : pmux::resources_json(final_resources))
                << ",\"fallback\":" << (fallback ? "true":"false")
                << ",\"baseline_compared\":" << (baseline_valid ? "true":"false")
                << ",\"no_regression_at_this_stage\":" << (baseline_valid && best >= 0 ? "true":"null")
                << ",\"formal_status\":\"NOT_CHECKED\",\"failure\":\"" << pmux::json_escape(failure)
                << "\",\"pass_wall_seconds\":" << std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count()
                << ",\"timing_note\":\"wall clock only; external runner measures process-tree CPU\"}\n";
            out.close();
            if (!out) log_cmd_error("pmux_opt: failed to finish %s.\n", json_file);
        }
        if (!failure.empty()) log_cmd_error("pmux_opt: %s.\n", failure);
    }
} PmuxOptPass;
PRIVATE_NAMESPACE_END
