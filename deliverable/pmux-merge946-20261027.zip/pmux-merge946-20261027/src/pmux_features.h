#ifndef PMUX_FEATURES_H
#define PMUX_FEATURES_H
#include "pmux_conditions.h"
#include <vector>

YOSYS_NAMESPACE_BEGIN
namespace pmux {
struct BitPattern { std::vector<int> key; bool reuse=false; };
inline BitPattern analyze_bit(const std::vector<SigBit> &sources) {
    BitPattern p; std::map<SigBit,int> groups;
    for(auto bit:sources) {
        auto it=groups.find(bit);
        if(it==groups.end()) { int id=int(groups.size()); groups[bit]=id; p.key.push_back(id); }
        else { p.key.push_back(it->second); p.reuse=true; }
    }
    return p;
}
struct CellFeatures {
    RTLIL::Cell *cell; int width=0,branches=0,reused_bits=0,shared_bits=0,constant_bits=0,related_bits=0;
    std::vector<BitPattern> patterns; std::string skip_reason;
};
struct FeatureSummary {
    int pmux_count=0,mux_count=0,cells_with_reuse=0,shared_bits_total=0,bits_with_reuse_total=0,max_w=0,max_k=0;
    int related_bits=0,constant_bits=0;
    void add(const CellFeatures &c) {
        if(c.cell->type==ID($pmux)) pmux_count++; else mux_count++;
        if(c.reused_bits) cells_with_reuse++;
        shared_bits_total+=c.shared_bits; bits_with_reuse_total+=c.reused_bits;
        max_w=std::max(max_w,c.width); max_k=std::max(max_k,c.branches);
        related_bits+=c.related_bits; constant_bits+=c.constant_bits;
    }
};
inline CellFeatures extract_features(RTLIL::Cell *cell, ConditionContext &ctx, bool diagnostic=false) {
    CellFeatures c; c.cell=cell;
    auto a=ctx.sigmap(cell->getPort(ID::A)),b=ctx.sigmap(cell->getPort(ID::B)),s=ctx.sigmap(cell->getPort(ID::S));
    c.width=GetSize(a); c.branches=cell->type==ID($pmux)?GetSize(s):1;
    if(c.width<=0 || c.branches<=0 || GetSize(b)!=c.width*c.branches) { c.skip_reason="malformed_shape"; return c; }
    if(int64_t(c.width)*c.branches>4096) { c.skip_reason="cell_budget"; return c; }
    std::map<std::vector<int>,int> uses;
    for(int j=0;j<c.width;j++) {
        std::vector<SigBit> sources;
        for(int i=0;i<c.branches;i++) { auto bit=b[i*c.width+j]; sources.push_back(bit); if(!bit.wire) c.constant_bits++; }
        auto p=analyze_bit(sources); if(p.reuse) { c.reused_bits++; uses[p.key]++; } c.patterns.push_back(p);
    }
    for(auto &p:c.patterns) if(p.reuse && uses[p.key]>1) c.shared_bits++;
    if(protected_object(cell)) c.skip_reason="protected_cell";
    else if(!c.reused_bits) c.skip_reason="no_repeated_data";
    else if(!c.shared_bits) c.skip_reason="no_shared_full_pattern";
    if(diagnostic) for(int i=0;i<GetSize(s);i++) {
        Facts facts;
        if(ctx.derive_facts(s[i],true,facts)) for(int j=0;j<c.width;j++) {
            SigBit rep; if(ctx.simplify_branch_bit(b[i*c.width+j],facts,rep)) c.related_bits++;
        }
    }
    return c;
}
inline FeatureSummary analyze_features(RTLIL::Design *design) {
    FeatureSummary f;
    for(auto module:design->selected_modules()) {
        if(module->get_blackbox_attribute()) continue;
        ConditionContext ctx(design,module);
        for(auto cell:module->selected_cells()) if(cell->type.in(ID($pmux),ID($mux))) f.add(extract_features(cell,ctx));
    }
    return f;
}
}
YOSYS_NAMESPACE_END
#endif
