// Zero-default PMUX is exactly the OR of masked branch words, for arbitrary S.
#include "pmux_conditions.h"
#include <vector>
#include <algorithm>
#include <map>
USING_YOSYS_NAMESPACE
PRIVATE_NAMESPACE_BEGIN
struct PmuxZeroPass:Pass {
    PmuxZeroPass():Pass("pmux_zero","remove redundant final gating from zero-default PMUX"){}
    void help() override {
        log("    pmux_zero [-auto]\n");
        log("Binary domain: Y = OR_i(B_i & S_i) when default A is all zero.\n");
        log("No one-hot assumption; equal-data factoring and balanced shared OR trees. No mapping or subprocess.\n");
        log("WIDTH<=32, 2<=S_WIDTH<=16, WIDTH*S_WIDTH<=256, <=32 rewrites/module.\n");
        log("Reject protected/ambiguous bits, unknown constants, processes/memories.\n");
        log("-auto requires pmux_opt.zero; limited to modules with <=128 state bits.\n");
        log("Removes redundant gates structurally; final LUT/time must be measured.\n");
    }
    void execute(std::vector<std::string> args,Design *design) override {
        bool automatic=args.size()>1 && args[1]=="-auto";
        extra_args(args,automatic?2:1,design);
        if(automatic && !design->scratchpad_get_bool("pmux_opt.zero",false))return;
        int examined=0,rewritten=0;std::map<std::string,int> skips;
        auto shape=[](Cell *cell) {
            if(cell->type!=ID($pmux))return false;
            int w=GetSize(cell->getPort(ID::A)),k=GetSize(cell->getPort(ID::S));
            return w>=1 && w<=32 && k>=2 && k<=16 && w*k<=256 &&
                GetSize(cell->getPort(ID::B))==w*k && GetSize(cell->getPort(ID::Y))==w;
        };
        for(auto module:design->selected_modules()) {
            if(module->get_blackbox_attribute() || pmux::protected_object(module) ||
                !module->processes.empty() || !module->memories.empty())continue;
            bool possible=false;
            for(auto cell:module->selected_cells())if(shape(cell)) {possible=true;break;}
            if(!possible)continue;
            // The validated automatic domain is small state modules. Larger
            // mapped designs can lose simple state correspondence after ABC;
            // retain their original structure until that proof gap is closed.
            if(automatic) {
                int64_t state_bits=0;
                for(auto cell:module->cells()) {
                    if(StaticCellTypes::categories.is_ff(cell->type) && cell->hasPort(ID::Q))
                        state_bits+=GetSize(cell->getPort(ID::Q));
                    else if(cell->type==RTLIL::IdString("\\dffeas"))state_bits++;
                }
                if(state_bits>128) {skips["automatic_state_budget"]++;continue;}
            }
            pmux::ConditionContext ctx(design,module);int changed=0;
            for(auto cell:module->selected_cells()) {
                if(!shape(cell))continue;
                if(changed>=32) {skips["module_budget"]++;break;}
                examined++;
                if(pmux::protected_object(cell)) {skips["protected_cell"]++;continue;}
                auto a=ctx.sigmap(cell->getPort(ID::A)),b=ctx.sigmap(cell->getPort(ID::B));
                auto s=ctx.sigmap(cell->getPort(ID::S)),y=ctx.sigmap(cell->getPort(ID::Y));
                bool zero=true,safe=true;
                for(auto bit:a)if(bit!=SigBit(State::S0))zero=false;
                if(!zero) {skips["nonzero_default"]++;continue;}
                for(auto signal:{a,b,s,y})for(auto bit:signal) {
                    if(bit.wire) {
                        if(ctx.protected_bits.count(bit) || ctx.drivers[bit]!=1)safe=false;
                    } else if(bit.data!=State::S0 && bit.data!=State::S1)safe=false;
                }
                for(auto bit:y)if(!bit.wire)safe=false;
                if(!safe) {skips["undefined_protected_or_ambiguous"]++;continue;}
                int w=GetSize(a),k=GetSize(s);SigSpec result;
                std::map<std::vector<SigBit>,SigBit> reductions;
                auto reduce=[&](std::vector<SigBit> terms) {
                    std::sort(terms.begin(),terms.end());
                    terms.erase(std::unique(terms.begin(),terms.end()),terms.end());
                    if(std::find(terms.begin(),terms.end(),SigBit(State::S1))!=terms.end())return SigBit(State::S1);
                    terms.erase(std::remove(terms.begin(),terms.end(),SigBit(State::S0)),terms.end());
                    if(terms.empty())return SigBit(State::S0);
                    if(terms.size()==1)return terms.front();
                    auto found=reductions.find(terms);if(found!=reductions.end())return found->second;
                    auto key=terms;
                    while(terms.size()>1) {
                        std::vector<SigBit> next;
                        for(int i=0;i<int(terms.size());i+=2) {
                            if(i+1==int(terms.size())) {next.push_back(terms[i]);continue;}
                            SigBit sum(module->addWire(NEW_ID));
                            auto added=module->addOr(NEW_ID,terms[i],terms[i+1],sum);
                            added->attributes=cell->attributes;next.push_back(sum);
                        }
                        terms=std::move(next);
                    }
                    return reductions[key]=terms.front();
                };
                for(int j=0;j<w;j++) {
                    // Preserve first occurrence order; factor equal data only.
                    std::vector<std::pair<SigBit,std::vector<SigBit>>> groups;
                    std::map<SigBit,int> indices;
                    for(int i=0;i<k;i++) {
                        SigBit data=b[i*w+j];if(data==SigBit(State::S0))continue;
                        if(!indices.count(data)) {indices[data]=int(groups.size());groups.push_back({data,{}});}
                        groups[indices[data]].second.push_back(s[i]);
                    }
                    std::vector<SigBit> terms;
                    for(auto &group:groups) {
                        SigBit enable=reduce(group.second),term;
                        if(group.first==SigBit(State::S1))term=enable;
                        else {
                            term=SigBit(module->addWire(NEW_ID));
                            auto added=module->addAnd(NEW_ID,group.first,enable,term);
                            added->attributes=cell->attributes;
                        }
                        terms.push_back(term);
                    }
                    result.append(reduce(terms));
                }
                module->connect(cell->getPort(ID::Y),result);
                log("pmux_zero: %s.%s width=%d choices=%d removed final mux/reduction, arbitrary select patterns\n",module->name,cell->name,w,k);
                module->remove(cell);changed++;rewritten++;
            }
        }
        for(auto &entry:skips)log("pmux_zero: skip %s=%d\n",entry.first,entry.second);
        design->scratchpad_set_int("pmux_zero.examined",examined);
        design->scratchpad_set_int("pmux_zero.rewritten",rewritten);
        log("pmux_zero: examined=%d rewritten=%d\n",examined,rewritten);
    }
} PmuxZeroPass;
PRIVATE_NAMESPACE_END
