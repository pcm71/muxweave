// Ordered interval trees preserve first-true priority, including multi-hot S.
#include "pmux_conditions.h"
#include "pmux_lut_cost.h"
#include <functional>
#include <tuple>

USING_YOSYS_NAMESPACE
PRIVATE_NAMESPACE_BEGIN
struct PriorityGraph {
    pmux_lut::Graph graph;
    std::map<SigBit,int> ids;
    std::map<int,SigBit> signals;
    std::vector<int> roots;
    int value(SigBit bit) {
        if(!bit.wire)return bit.data==State::S1?1:0;
        auto it=ids.find(bit);if(it!=ids.end())return it->second;
        int id=graph.input();ids[bit]=id;signals[id]=bit;return id;
    }
    int either(int a,int b) {
        if(a==1 || b==1)return 1;
        if(a==0)return b;if(b==0 || a==b)return a;
        if(a>b)std::swap(a,b);
        return graph.lut({a,b},14);
    }
};
struct PriorityPass:Pass {
    PriorityPass():Pass("pmux_priority","rebalance bounded mux chains while preserving priority"){}
    void help() override {
        log("    pmux_priority [-auto]\n");
        log("Ordered interval trees, 3..8 muxes, width <=32, <=256 branch bits.\n");
        log("Primary-input leaves only; exclusive module outputs, private internal chain.\n");
        log("Preserves first-true priority; no one-hot assumption or select reordering.\n");
        log("Accept estimated LUT reduction without deeper logic, or equal LUT with less depth.\n");
        log("Fanout bounded; estimates do not guarantee final ABC area or timing.\n");
        log("-auto requires pmux_opt.priority (default false).\n");
    }
    void execute(std::vector<std::string> args,Design *design) override {
        bool automatic=args.size()>1 && args[1]=="-auto";
        extra_args(args,automatic?2:1,design);
        if(automatic && !design->scratchpad_get_bool("pmux_opt.priority",false))return;
        int examined=0,rewritten=0;
        std::map<std::string,int> skips;
        for(auto module:design->selected_modules()) {
            if(module->get_blackbox_attribute() || pmux::protected_object(module) || !module->processes.empty() || !module->memories.empty())continue;
            // A rewrite requires every root output bit to be a module output.
            // Prove that a root can exist before building the full driver/use
            // graph. SigMap is required here so output aliases are not missed.
            {
                SigMap aliases(module);std::set<SigBit> output_bits;
                for(auto wire:module->wires())if(wire->port_output)
                    for(auto bit:aliases(SigSpec(wire)))output_bits.insert(bit);
                bool possible=false;
                for(auto cell:module->selected_cells())if(cell->type==ID($mux)) {
                    auto y=aliases(cell->getPort(ID::Y));
                    bool root=GetSize(y)>=1 && GetSize(y)<=32;
                    for(auto bit:y)if(!bit.wire || !output_bits.count(bit))root=false;
                    if(root) {possible=true;break;}
                }
                if(!possible) {skips["no_output_mux"]++;continue;}
            }
            pmux::ConditionContext ctx(design,module);CellTypes types(design);
            std::set<SigBit> inputs,outputs;
            std::map<SigBit,std::set<std::pair<Cell*,IdString>>> users;
            for(auto wire:module->wires())for(auto bit:ctx.sigmap(SigSpec(wire))) {
                if(wire->port_input)inputs.insert(bit);
                if(wire->port_output)outputs.insert(bit);
            }
            for(auto cell:module->cells())for(auto &port:cell->connections())
                if(!types.cell_known(cell->type) || types.cell_input(cell->type,port.first))
                    for(auto bit:ctx.sigmap(port.second))users[bit].insert({cell,port.first});
            auto leaf=[&](SigSpec sig) {
                for(auto bit:sig)if(ctx.protected_bits.count(bit) ||
                    (bit.wire? !inputs.count(bit) || ctx.drivers[bit]!=1 : bit.data!=State::S0 && bit.data!=State::S1))return false;
                return true;
            };
            std::set<Cell*> removed;
            int module_candidates=0;
            for(auto root:module->selected_cells()) {
                if(removed.count(root) || root->type!=ID($mux))continue;
                bool safe=true;
                auto y=ctx.sigmap(root->getPort(ID::Y));int w=GetSize(y);
                for(auto bit:y)if(!bit.wire || !outputs.count(bit) || !users[bit].empty() || ctx.drivers[bit]!=1 || ctx.protected_bits.count(bit))safe=false;
                if(!safe || w<1 || w>32)continue;
                if(++module_candidates>16) {skips["module_budget"]++;break;}
                examined++;
                std::vector<Cell*> chain;std::vector<SigSpec> data;std::vector<SigBit> select;
                Cell *current=root;SigSpec fallback;
                while(current) {
                    if(chain.size()>=8 || std::find(chain.begin(),chain.end(),current)!=chain.end() ||
                       !design->selected(module,current) || pmux::protected_object(current)) {safe=false;break;}
                    auto a=ctx.sigmap(current->getPort(ID::A)),b=ctx.sigmap(current->getPort(ID::B)),s=ctx.sigmap(current->getPort(ID::S));
                    if(GetSize(a)!=w || GetSize(b)!=w || GetSize(s)!=1 || !leaf(b) || !leaf(s)) {safe=false;break;}
                    chain.push_back(current);data.push_back(b);select.push_back(s[0]);
                    if(leaf(a)) {fallback=a;break;}
                    auto prev=ctx.driver(a[0]);
                    if(!prev || prev->type!=ID($mux) || ctx.sigmap(prev->getPort(ID::Y))!=a) {safe=false;break;}
                    for(auto bit:a)if(!bit.wire || outputs.count(bit) || ctx.protected_bits.count(bit) || ctx.drivers[bit]!=1 ||
                        users[bit].size()!=1 || !users[bit].count({current,ID::A}))safe=false;
                    if(!safe)break;
                    current=prev;
                }
                if(!safe || GetSize(fallback)!=w) {skips["unsafe_or_unsupported_chain"]++;continue;}
                int n=int(chain.size());
                if(n<3 || n*w>256) {skips["chain_budget"]++;continue;}
                // Short chains can lose a LUT after the fixed ABC mapping.
                // Automatic production rewriting is restricted to deeper chains.
                if(automatic && n<6 && n!=4) {skips["automatic_short_chain"]++;continue;}
                // Last leaf is an always-valid fallback. Every internal node
                // chooses its HIGH interval if any selector there is true.
                // Both intervals retain original order; priority is never lost.
                auto build=[&](int top_split,bool original) {
                    PriorityGraph plan;
                    std::vector<std::vector<int>> values;std::vector<int> enables;
                    for(int i=0;i<n;i++) {
                        std::vector<int> word;for(auto bit:data[i])word.push_back(plan.value(bit));
                        values.push_back(word);enables.push_back(plan.value(select[i]));
                    }
                    std::vector<int> word;for(auto bit:fallback)word.push_back(plan.value(bit));
                    values.push_back(word);enables.push_back(1);
                    using Segment=std::pair<int,std::vector<int>>;
                    std::function<Segment(int,int,bool)> tree=[&](int lo,int hi,bool top)->Segment {
                        if(hi-lo==1)return {enables[lo],values[lo]};
                        int mid=original?lo+1:top?top_split:(lo+hi)/2;
                        auto high=tree(lo,mid,false),low=tree(mid,hi,false);
                        std::vector<int> result;
                        for(int j=0;j<w;j++)result.push_back(plan.graph.mux(low.second[j],high.second[j],high.first));
                        return {plan.either(high.first,low.first),result};
                    };
                    plan.roots=tree(0,n+1,true).second;return plan;
                };
                auto before_plan=build(1,true);auto before=pmux_lut::estimate(before_plan.graph,before_plan.roots);
                PriorityGraph best;pmux_lut::Cost after;bool found=false,decoded=false;
                // A direct four-stage zero-default chain maps to four LUTs/lane
                // under the fixed ABC script. The cut estimator merges adjacent
                // muxes optimistically, so keep this calibrated direct cover
                // separate from the ordinary interval-tree estimate.
                bool independent=n==4 && w>=4 && w<=5;
                std::set<SigBit> distinct;
                for(auto bit:fallback)if(bit!=SigBit(State::S0))independent=false;
                for(auto bit:select)if(!bit.wire || !distinct.insert(bit).second)independent=false;
                for(auto word:data)for(auto bit:word)
                    if(!bit.wire || !distinct.insert(bit).second)independent=false;
                if(independent) {
                    PriorityGraph candidate;std::vector<int> selectors,enables;
                    for(auto bit:select)selectors.push_back(candidate.value(bit));
                    for(int i=0;i<n;i++) {
                        std::vector<int> in={selectors[i]};
                        for(int j=0;j<i;j++)in.push_back(selectors[j]);
                        enables.push_back(i==0?selectors[0]:candidate.graph.lut(in,2));
                    }
                    for(int j=0;j<w;j++) {
                        // Expose the two pairs as LUT4 cuts rather than a
                        // four-input OR of separate gates. The upper pair
                        // absorbs its first two selectors in one LUT.
                        uint64_t first_truth=0;
                        for(int k=0;k<16;k++)if((k&4)?(k&1):((k&8)&&(k&2)))first_truth|=uint64_t(1)<<k;
                        int high=candidate.graph.lut({candidate.value(data[0][j]),candidate.value(data[1][j]),selectors[0],selectors[1]},first_truth);
                        int low=candidate.graph.lut({candidate.value(data[2][j]),enables[2],candidate.value(data[3][j]),enables[3]},0xf888);
                        candidate.roots.push_back(candidate.either(high,low));
                    }
                    auto cost=pmux_lut::estimate(candidate.graph,candidate.roots);
                    pmux_lut::Cost direct;direct.luts=n*w;direct.depth=n;direct.max_fanout=w;
                    if(pmux_lut::profitable(direct,cost)) {
                        before=direct;after=cost;best=std::move(candidate);found=true;decoded=true;
                    }
                }
                // Preserve automatic short-chain protection for every other
                // structure, including narrow, aliased and nonzero defaults.
                if(automatic && n<6 && !found) {skips["automatic_short_chain"]++;continue;}
                for(int split=1;split<=n && !decoded;split++) {
                    auto candidate=build(split,false);auto cost=pmux_lut::estimate(candidate.graph,candidate.roots);
                    bool gain=cost.luts<before.luts || (cost.luts==before.luts && cost.depth<before.depth);
                    if(design->scratchpad_get_bool("pmux_priority.trace",false))
                        log("pmux_priority: candidate %s.%s split=%d LUT4=%d->%d depth=%d->%d fanout=%d->%d accepted=%d\n",
                            module->name,root->name,split,before.luts,cost.luts,before.depth,cost.depth,before.max_fanout,cost.max_fanout,
                            int(gain && cost.depth<=before.depth && cost.max_fanout<=std::max(8,before.max_fanout)));
                    if(!gain || cost.depth>before.depth || cost.max_fanout>std::max(8,before.max_fanout))continue;
                    if(!found || std::tie(cost.luts,cost.depth,cost.max_fanout)<std::tie(after.luts,after.depth,after.max_fanout)) {
                        best=std::move(candidate);after=cost;found=true;
                    }
                }
                if(!found) {skips["cost"]++;continue;}
                auto nets=best.signals;nets[0]=SigBit(State::S0);nets[1]=SigBit(State::S1);
                std::function<SigBit(int)> materialize=[&](int id)->SigBit {
                    auto it=nets.find(id);if(it!=nets.end())return it->second;
                    auto &node=best.graph.nodes[id];SigSpec in;
                    for(int child:node.inputs)in.append(materialize(child));
                    SigBit out(module->addWire(NEW_ID));Cell *added;
                    if(node.truth==14)added=module->addOr(NEW_ID,in[0],in[1],out);
                    else if(node.truth==0xca && GetSize(in)==3)added=module->addMux(NEW_ID,in[0],in[1],in[2],out);
                    else {
                        std::vector<State> truth;
                        for(int j=0;j<(1<<GetSize(in));j++)truth.push_back((node.truth>>j)&1?State::S1:State::S0);
                        added=module->addLut(NEW_ID,in,out,RTLIL::Const(truth));
                    }
                    added->attributes=root->attributes;nets[id]=out;return out;
                };
                SigSpec result;for(int id:best.roots)result.append(materialize(id));
                module->connect(root->getPort(ID::Y),result);
                log("pmux_priority: %s.%s chain=%d width=%d LUT4=%d->%d depth=%d->%d fanout=%d->%d\n",module->name,root->name,n,w,before.luts,after.luts,before.depth,after.depth,before.max_fanout,after.max_fanout);
                if(decoded)log("pmux_priority: shared disjoint enables, direct-cover calibration, no one-hot assumption\n");
                for(auto cell:chain) {removed.insert(cell);module->remove(cell);}
                rewritten++;
            }
        }
        for(auto &entry:skips)log("pmux_priority: skip %s=%d\n",entry.first,entry.second);
        design->scratchpad_set_int("pmux_priority.examined",examined);
        design->scratchpad_set_int("pmux_priority.rewritten",rewritten);
        log("pmux_priority: examined=%d rewritten=%d\n",examined,rewritten);
    }
} PriorityPass;
PRIVATE_NAMESPACE_END
