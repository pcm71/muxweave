// Factor repeated data bits and share select reductions across output bits.
// Implements exactly simplemap_pmux's Boolean expansion, including multi-hot S:
// Y[j] = (|S) ? OR_g(data[g] & OR_{i in g} S[i]) : A[j].
// No assumption that S is one-hot and no removal of default-valued branches.
#include "kernel/yosys.h"
#include "kernel/sigtools.h"
#include "pmux_conditions.h"
#include "pmux_lut_cost.h"
#include "pmux_cross.h"
#include <map>
#include <vector>
#include <algorithm>

USING_YOSYS_NAMESPACE
PRIVATE_NAMESPACE_BEGIN

// Compare native Boolean expansion with the proposed grouping using the same
// bounded LUT4 cover estimator as ROM optimization. X/Z costs are not guessed.
static bool lut_costs(const SigSpec &a,const SigSpec &b,const SigSpec &s,int w,int k,
                     pmux_lut::Cost &before,pmux_lut::Cost &after)
{
    for(auto signal:{a,b,s})for(auto bit:signal)
        if(!bit.wire && bit.data!=State::S0 && bit.data!=State::S1)return false;
    auto estimate=[&](bool grouped) {
        pmux_lut::Graph graph;std::map<SigBit,int> ids;
        auto value=[&](SigBit bit) {
            if(!bit.wire)return bit.data==State::S1?1:0;
            auto it=ids.find(bit);if(it!=ids.end())return it->second;
            return ids[bit]=graph.input();
        };
        auto reduce=[&](const std::vector<SigBit> &bits) {
            int r=0;for(auto bit:bits) {int v=value(bit);r=r==0?v:graph.lut({r,v},14);}return r;
        };
        int any=reduce(s.to_sigbit_vector());std::vector<int> roots;
        for(int j=0;j<w;j++) {
            int selected=0;
            auto term=[&](int data,int enable) {
                int t=data==0?0:data==1?enable:graph.lut({data,enable},8);
                if(t)selected=selected==0?t:graph.lut({selected,t},14);
            };
            if(grouped) {
                std::map<SigBit,std::vector<SigBit>> groups;
                for(int i=0;i<k;i++)groups[b[i*w+j]].push_back(s[i]);
                for(auto &entry:groups) {
                    auto &v=entry.second;std::sort(v.begin(),v.end());v.erase(std::unique(v.begin(),v.end()),v.end());
                    term(value(entry.first),reduce(v));
                }
            } else for(int i=0;i<k;i++)term(value(b[i*w+j]),value(s[i]));
            roots.push_back(graph.mux(value(a[j]),selected,any));
        }
        return pmux_lut::estimate(graph,roots);
    };
    before=estimate(false);after=estimate(true);return true;
}

struct PmuxSharePass : Pass {
    PmuxSharePass() : Pass("pmux_share", "factor repeated PMUX data bits and share select reductions") {}
    void help() override {
        log("    pmux_share [-auto | -cross]\n\n");
        log("-cross: bounded cross-PMUX proper selector subset sharing only.\n");
        log("synth_intel cross sharing requires pmux_opt.cross (default false).\n");
        log("Factor repeated data bits using the native simplemap Boolean formula.\n");
        log("Keep default A and all select bits, including multi-hot select behavior.\n");
        log("Skip kept cells, tiny/no-benefit cells and cells with WIDTH*S_WIDTH > 4096.\n");
        log("Bounded LUT4 cost gate includes depth/fanout; final ABC gain is not guaranteed.\n");
        log("-auto: run only when scratchpad pmux_opt.share is true (default false).\n");
    }
    void execute(std::vector<std::string> args, RTLIL::Design *design) override {
        bool automatic = args.size() > 1 && args[1] == "-auto";
        bool cross = args.size() > 1 && args[1] == "-cross";
        extra_args(args, automatic || cross ? 2 : 1, design);
        if(cross) pmux::cross_share(design);
        if(cross) return;
        if (automatic && !design->scratchpad_get_bool("pmux_opt.share", false)) return;
        int rewritten = 0, saved = 0, selectors = 0, lut_saved = 0;
        std::map<std::string,int> skipped;
        for (auto module : design->selected_modules()) {
            if (module->get_blackbox_attribute() || pmux::protected_object(module)) continue;
            SigMap sigmap(module);
            // Snapshot cell pointers before inserting new cells.
            auto cells = module->selected_cells();
            for (auto cell : cells) {
                if (cell->type != ID($pmux)) continue;
                if (pmux::protected_object(cell)) { skipped["protected_cell"]++; continue; }
                auto a = sigmap(cell->getPort(ID::A));
                auto b = sigmap(cell->getPort(ID::B));
                auto s = sigmap(cell->getPort(ID::S));
                auto y = cell->getPort(ID::Y);
                int w = GetSize(a), k = GetSize(s);
                if (w < 2 || k < 2) { skipped["tiny_cell"]++; continue; }
                if (int64_t(w)*k > 4096) { skipped["cell_budget"]++; continue; }
                if (GetSize(b) != w*k || GetSize(y) != w)
                    log_cmd_error("pmux_share: malformed PMUX %s.\n", cell->name);
                using Groups = std::map<SigBit, std::vector<SigBit>>;
                std::vector<Groups> bits(w);
                std::map<std::vector<SigBit>, int> uses;
                int eliminated_terms = 0;
                for (int j=0; j<w; ++j) {
                    for (int i=0; i<k; ++i) bits[j][b[i*w+j]].push_back(s[i]);
                    eliminated_terms += k-int(bits[j].size());
                    for (auto &group : bits[j]) {
                        auto &key = group.second;
                        std::sort(key.begin(), key.end());
                        key.erase(std::unique(key.begin(), key.end()), key.end());
                        if (key.size() > 1) uses[key]++;
                    }
                }
                int select_cost=0, shared_groups=0;
                for (auto &entry : uses) {
                    select_cost += int(entry.first.size())-1;
                    if (entry.second > 1) shared_groups++;
                }
                if (!eliminated_terms) { skipped["no_repeated_data"]++; continue; }
                if (!shared_groups) { skipped["no_shared_select_group"]++; continue; }
                pmux_lut::Cost before,after;
                if(!lut_costs(a,b,s,w,k,before,after)) {skipped["undefined_cost"]++;continue;}
                log("pmux_share: estimated LUT4 %d -> %d, depth %d -> %d, fanout %d -> %d\n",
                    before.luts,after.luts,before.depth,after.depth,before.max_fanout,after.max_fanout);
                if(!pmux_lut::profitable(before,after)) {skipped["lut_cost"]++;continue;}
                std::map<std::vector<SigBit>, SigBit> cache;
                auto reduce = [&](std::vector<SigBit> key) -> SigBit {
                    std::sort(key.begin(), key.end());
                    key.erase(std::unique(key.begin(), key.end()), key.end());
                    if (key.size() == 1) return key.front();
                    auto it = cache.find(key);
                    if (it != cache.end()) return it->second;
                    SigBit result(module->addWire(NEW_ID));
                    auto added = module->addReduceOr(NEW_ID, SigSpec(key), result);
                    added->attributes = cell->attributes;
                    cache[key] = result;
                    return result;
                };
                SigBit any = reduce(s.to_sigbit_vector());
                SigSpec selected;
                for (int j=0; j<w; ++j) {
                    std::vector<SigBit> terms;
                    for (auto &group : bits[j]) {
                        SigBit term(module->addWire(NEW_ID));
                        auto added = module->addAnd(NEW_ID, group.first, reduce(group.second), term);
                        added->attributes = cell->attributes;
                        terms.push_back(term);
                    }
                    selected.append(reduce(terms));
                }
                auto mux = module->addMux(NEW_ID, a, selected, any, y);
                mux->attributes = cell->attributes;
                log("pmux_share: %s.%s W=%d K=%d, repeated terms=%d, shared select groups=%d\n",
                    module->name, cell->name, w, k, eliminated_terms, shared_groups);
                module->remove(cell);
                rewritten++; saved += 2*eliminated_terms-select_cost; selectors += shared_groups;
                lut_saved += before.luts-after.luts;
            }
        }
        design->scratchpad_set_int("pmux_share.cells", rewritten);
        design->scratchpad_set_int("pmux_share.estimated_gate_saving", saved);
        design->scratchpad_set_int("pmux_share.shared_select_groups", selectors);
        design->scratchpad_set_int("pmux_share.estimated_lut_saving", lut_saved);
        for (auto &entry : skipped) {
            design->scratchpad_set_int("pmux_share.skip."+entry.first,entry.second);
            log("pmux_share: skip %s=%d\n",entry.first,entry.second);
        }
        log("pmux_share: rewritten=%d, estimated gate saving=%d, shared groups=%d\n", rewritten, saved, selectors);
    }
} PmuxSharePass;
PRIVATE_NAMESPACE_END
