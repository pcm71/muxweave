#include "pmux_conditions.h"
#include "pmux_resources.h"
#include "pmux_lut_cost.h"
#include <functional>
#include <fstream>

USING_YOSYS_NAMESPACE
PRIVATE_NAMESPACE_BEGIN
using namespace pmux_lut;

struct Extract {
    RTLIL::Module *module;
    pmux::ConditionContext context;
    Graph graph;
    std::map<SigBit,int> values, inputs;
    std::map<int,SigBit> signals;
    std::map<SigBit,std::set<RTLIL::Cell*>> cones;
    std::set<SigBit> active;
    std::set<RTLIL::Cell*> allowed;
    int budget=16384;
    Extract(RTLIL::Design *d,RTLIL::Module *m):module(m),context(d,m) {
        for(auto c:m->selected_cells()) allowed.insert(c);
    }
    int data(SigBit bit,int depth=0) {
        bit=context.sigmap(bit);
        if(!bit.wire) return bit.data==State::S0?0:bit.data==State::S1?1:-1;
        auto found=values.find(bit); if(found!=values.end()) return found->second;
        if(--budget<0 || depth>32 || graph.nodes.size()>=4094 || active.count(bit)) return -1;
        auto c=context.driver(bit);
        if(!c || !allowed.count(c) || c->type!=ID($mux)) return values[bit]=-1;
        auto a=context.sigmap(c->getPort(ID::A)),b=context.sigmap(c->getPort(ID::B));
        auto s=context.sigmap(c->getPort(ID::S)),y=context.sigmap(c->getPort(ID::Y));
        if(GetSize(a)!=GetSize(y) || GetSize(b)!=GetSize(y) || GetSize(s)!=1 || GetSize(y)>64) return values[bit]=-1;
        int offset=-1; for(int j=0;j<GetSize(y);j++) if(y[j]==bit) offset=j;
        if(offset<0 || !s[0].wire || context.drivers[s[0]]!=1 || context.protected_bits.count(s[0])) return values[bit]=-1;
        active.insert(bit);
        int av=data(a[offset],depth+1),bv=data(b[offset],depth+1);
        active.erase(bit);
        if(av<0 || bv<0) return values[bit]=-1;
        if(graph.nodes.size()+2>4096) return values[bit]=-1;
        if(!inputs.count(s[0])) { int id=graph.input(); inputs[s[0]]=id; signals[id]=s[0]; }
        int result=graph.mux(av,bv,inputs[s[0]]);
        cones[bit].insert(c);
        for(auto x:{a[offset],b[offset]}) for(auto parent:cones[x]) cones[bit].insert(parent);
        return values[bit]=result;
    }
};

// Remove irrelevant variables before interning each cofactor. LUTs and cofactors
// are shared across all outputs in a group, including duplicate output functions.
static int decompose(Graph &g,std::vector<int> vars,uint64_t truth,const std::vector<int> &order,int expansion=0) {
    for(int p=int(vars.size())-1;p>=0;p--) {
        bool relevant=false; uint64_t reduced=0;
        for(int i=0;i<(1<<int(vars.size()));i++) if(!(i&(1<<p))) {
            if(((truth>>i)&1)!=((truth>>(i|(1<<p)))&1)) relevant=true;
            int j=(i&((1<<p)-1))|((i>>(p+1))<<p);
            reduced|=((truth>>i)&1)<<j;
        }
        if(!relevant) { vars.erase(vars.begin()+p); truth=reduced; }
    }
    if(vars.empty()) return int(truth&1);
    if(vars.size()==1 && truth==2) return vars[0];
    if(vars.size()<=4) return g.lut(vars,truth);
    int p=0; for(int v:order) { auto it=std::find(vars.begin(),vars.end(),v); if(it!=vars.end()) {p=int(it-vars.begin());break;} }
    uint64_t low=0,high=0;
    for(int i=0;i<(1<<int(vars.size()));i++) {
        int j=(i&((1<<p)-1))|((i>>(p+1))<<p);
        if(i&(1<<p)) high|=((truth>>i)&1)<<j; else low|=((truth>>i)&1)<<j;
    }
    int select=vars[p]; vars.erase(vars.begin()+p);
    if(expansion==0) {
        int a=decompose(g,vars,low,order,expansion),b=decompose(g,vars,high,order,expansion);
        return g.mux(a,b,select);
    }
    // Positive/negative Davio share difference cofactors across all columns.
    // f = low ^ (s & difference), or high ^ (~s & difference).
    int base=decompose(g,vars,expansion==1?low:high,order,expansion);
    int difference=decompose(g,vars,low^high,order,expansion);
    if(difference==0)return base;
    return g.lut({base,difference,select},expansion==1?0x6a:0xa6);
}

struct PmuxRomPass:Pass {
    PmuxRomPass():Pass("pmux_rom","bounded multi-output ROM cofactor optimization with LUT4 cost gating"){}
    void help() override {
        log("    pmux_rom [-auto] [-dry-run] [-json file]\n");
        log("Run after memory_map. Only binary constant-data $mux cones, <=6 inputs.\n");
        log("At most 64 outputs/group, 4096 DAG nodes and 16384 extraction visits/module.\n");
        log("At most 21 deterministic Shannon/Davio candidates; bounded 32-cut LUT4 estimate.\n");
        log("Require estimated LUT reduction, no depth increase, bounded fanout.\n");
        log("-auto requires scratchpad pmux_opt.rom (default false).\n");
        log("Automatic mode requires primary-input addresses and rejects new constant/identity outputs.\n");
        log("Estimates are not final ABC results or a formal equivalence certificate.\n");
    }
    void execute(std::vector<std::string> args,RTLIL::Design *design) override {
        bool automatic=false,dry=false; std::string json; size_t i=1;
        for(;i<args.size();i++) {
            if(args[i]=="-auto") {automatic=true;continue;}
            if(args[i]=="-dry-run") {dry=true;continue;}
            if(args[i]=="-json" && i+1<args.size()) {json=args[++i];continue;}
            break;
        }
        extra_args(args,i,design);
        if(automatic && !design->scratchpad_get_bool("pmux_opt.rom",false)) return;
        std::ofstream out; if(!json.empty()) {out.open(json);if(!out)log_cmd_error("Cannot write %s.\n",json);}
        std::vector<std::string> records; int changed=0; std::map<std::string,int> skips;
        for(auto m:design->selected_modules()) {
            if(m->get_blackbox_attribute() || pmux::protected_object(m) || !m->processes.empty()) continue;
            Extract e(design,m);
            std::map<RTLIL::Cell*,std::vector<int>> eligible;
            for(auto c:m->selected_cells()) if(c->type==ID($mux)) {
                std::vector<int> roots; bool ok=true;
                for(auto y:e.context.sigmap(c->getPort(ID::Y))) {int id=e.data(y);if(id<0)ok=false;roots.push_back(id);}
                if(ok) eligible[c]=roots; else skips["unsupported_or_budget"]++;
            }
            if(eligible.empty()) {skips["no_constant_mux_cone"]++;continue;}
            std::set<SigBit> primary_inputs;
            for(auto w:m->wires())if(w->port_input)
                for(auto bit:e.context.sigmap(SigSpec(w)))primary_inputs.insert(bit);
            std::vector<std::set<int>> supports(e.graph.nodes.size());
            for(int id=2;id<int(e.graph.nodes.size());id++) {
                if(e.graph.nodes[id].input) supports[id].insert(id);
                else for(int x:e.graph.nodes[id].inputs) {
                    supports[id].insert(supports[x].begin(),supports[x].end());
                    while(supports[id].size()>7)supports[id].erase(std::prev(supports[id].end()));
                }
            }
            // If no extracted word can meet the automatic address contract,
            // no later boundary grouping can turn it into an eligible group.
            // Keep diagnostic JSON on the full path for its detailed records.
            if(automatic && json.empty()) {
                bool possible=false;
                for(auto &entry:eligible) {
                    std::set<int> vars;
                    for(int id:entry.second)vars.insert(supports[id].begin(),supports[id].end());
                    bool input_address=!vars.empty() && vars.size()<=6;
                    for(int v:vars)if(!primary_inputs.count(e.signals[v]))input_address=false;
                    if(input_address) {possible=true;break;}
                }
                if(!possible) {skips["no_primary_input_cone"]++;continue;}
            }
            std::map<SigBit,std::set<RTLIL::Cell*>> users; std::set<SigBit> boundary;
            CellTypes types(design);
            for(auto w:m->wires()) if(w->port_output || pmux::protected_object(w))
                for(auto bit:e.context.sigmap(SigSpec(w))) boundary.insert(bit);
            for(auto c:m->cells()) for(auto &port:c->connections())
                if(!types.cell_known(c->type) || !types.cell_output(c->type,port.first))
                    for(auto bit:e.context.sigmap(port.second)) {
                        users[bit].insert(c);
                        if(!eligible.count(c) || (c->type==ID($mux) && port.first==ID::S)) boundary.insert(bit);
                    }
            std::map<std::vector<int>,std::vector<RTLIL::Cell*>> groups;
            for(auto &entry:eligible) {
                bool root=false; for(auto y:e.context.sigmap(entry.first->getPort(ID::Y))) if(boundary.count(y))root=true;
                if(!root)continue;
                std::set<int> vars; for(int id:entry.second) vars.insert(supports[id].begin(),supports[id].end());
                if(vars.empty() || vars.size()>6) {skips["support"]++;continue;}
                groups[std::vector<int>(vars.begin(),vars.end())].push_back(entry.first);
            }
            std::set<RTLIL::Cell*> removed;
            for(auto &group:groups) {
                // Keep the automatic prototype away from feedback/state-derived
                // addresses. Local Boolean proof alone does not certify later FF
                // initial-state refinement. Standalone remains a research entry.
                bool input_address=true;for(int v:group.first)
                    if(!primary_inputs.count(e.signals[v]))input_address=false;
                if(automatic && !input_address) {skips["state_or_derived_address"]++;continue;}
                std::vector<int> roots; SigSpec outputs; std::set<RTLIL::Cell*> cone;
                for(auto c:group.second) {
                    for(auto y:e.context.sigmap(c->getPort(ID::Y))) {outputs.append(y);for(auto x:e.cones[y])cone.insert(x);}
                    roots.insert(roots.end(),eligible[c].begin(),eligible[c].end());
                }
                if(roots.size()>64) {skips["output_budget"]++;continue;}
                bool safe=true; std::set<SigBit> rootbits; for(auto y:outputs)rootbits.insert(y);
                for(auto c:cone) {
                    if(removed.count(c)) {safe=false;break;}
                    for(auto y:e.context.sigmap(c->getPort(ID::Y))) {
                        if(e.inputs.count(y)) safe=false;
                        if(!rootbits.count(y)) {
                            if(boundary.count(y))safe=false;
                            for(auto user:users[y])if(!cone.count(user))safe=false;
                        }
                        if(e.context.protected_bits.count(y))safe=false;
                    }
                }
                if(!safe) {skips["shared_boundary_or_protected"]++;continue;}
                // Restrict cost DAG to this cone; unrelated logic must not bias refs.
                Graph original; std::map<int,int> remap={{0,0},{1,1}};
                for(int v:group.first)remap[v]=original.input();
                std::function<int(int)> copy=[&](int id) {
                    if(remap.count(id))return remap[id];
                    std::vector<int> in;for(int x:e.graph.nodes[id].inputs)in.push_back(copy(x));
                    return remap[id]=original.lut(in,e.graph.nodes[id].truth);
                };
                std::vector<int> oldroots;for(int r:roots)oldroots.push_back(copy(r));
                Cost before=estimate(original,oldroots),bestcost;
                std::vector<uint64_t> tables(roots.size(),0);
                for(int pattern=0;pattern<(1<<int(group.first.size()));pattern++) {
                    std::map<int,bool> eval={{0,false},{1,true}};
                    for(int j=0;j<int(group.first.size());j++)eval[group.first[j]]=(pattern>>j)&1;
                    std::function<bool(int)> value=[&](int id) {
                        auto it=eval.find(id);if(it!=eval.end())return it->second;
                        int index=0,j=0;for(int x:e.graph.nodes[id].inputs)index|=int(value(x))<<j++;
                        return eval[id]=bool((e.graph.nodes[id].truth>>index)&1);
                    };
                    for(int j=0;j<int(roots.size());j++) tables[j]|=uint64_t(value(roots[j]))<<pattern;
                }
                Graph bestgraph; std::vector<int> bestroots; bool found=false,best_feasible=false;
                int orders=int(group.first.size())+1,best_expansion=0,best_order=0;
                for(int expansion=0;expansion<(group.first.size()>4?3:1);expansion++)
                for(int order=0;order<orders;order++) {
                    Graph candidate; std::vector<int> vars;for(size_t j=0;j<group.first.size();j++)vars.push_back(candidate.input());
                    auto sequence=vars;
                    if(order==int(vars.size()))std::reverse(sequence.begin(),sequence.end());
                    else std::rotate(sequence.begin(),sequence.begin()+order,sequence.end());
                    std::vector<int> proposed;for(auto table:tables)proposed.push_back(decompose(candidate,vars,table,sequence,expansion));
                    auto cost=estimate(candidate,proposed);
                    bool feasible=profitable(before,cost);
                    if(!found || (feasible && !best_feasible) || (feasible==best_feasible &&
                       std::tie(cost.luts,cost.depth,cost.max_fanout)<std::tie(bestcost.luts,bestcost.depth,bestcost.max_fanout))) {
                        found=true;bestcost=cost;bestgraph=std::move(candidate);bestroots=std::move(proposed);
                        best_feasible=feasible;best_expansion=expansion;best_order=order;
                    }
                }
                found=found && best_feasible;
                if(automatic)for(int r:bestroots)if(r<2 || bestgraph.nodes[r].input) {
                    if(found)skips["constant_or_identity_boundary"]++;
                    found=false;
                }
                std::ostringstream record;record<<"{\"module\":\""<<pmux::json_escape(m->name.str())<<"\",\"inputs\":"<<group.first.size()<<",\"outputs\":"<<roots.size()<<",\"before_luts\":"<<before.luts<<",\"before_depth\":"<<before.depth<<",\"accepted\":"<<(found?"true":"false");
                record<<",\"after_luts\":"<<bestcost.luts<<",\"after_depth\":"<<bestcost.depth<<",\"after_fanout\":"<<bestcost.max_fanout;
                record<<",\"expansion\":"<<best_expansion<<",\"order\":"<<best_order<<"}";records.push_back(record.str());
                if(!found) {skips["cost"]++;continue;}
                log("pmux_rom: %s estimated LUT4 %d -> %d, depth %d -> %d, outputs=%d\n",
                    m->name,before.luts,bestcost.luts,before.depth,bestcost.depth,int(roots.size()));
                if(dry)continue;
                std::vector<SigBit> nets(bestgraph.nodes.size());nets[0]=State::S0;nets[1]=State::S1;
                for(size_t j=0;j<group.first.size();j++)nets[2+j]=e.signals[group.first[j]];
                std::set<int> used;std::function<void(int)> mark=[&](int id){if(!used.insert(id).second)return;for(int x:bestgraph.nodes[id].inputs)mark(x);};for(int r:bestroots)mark(r);
                for(int id=2+int(group.first.size());id<int(bestgraph.nodes.size());id++)if(used.count(id)) {
                    SigSpec in;for(int x:bestgraph.nodes[id].inputs)in.append(nets[x]);
                    nets[id]=SigBit(m->addWire(NEW_ID)); std::vector<State> bits;
                    for(int j=0;j<(1<<GetSize(in));j++)bits.push_back((bestgraph.nodes[id].truth>>j)&1?State::S1:State::S0);
                    m->addLut(NEW_ID,in,nets[id],RTLIL::Const(bits));
                }
                for(int j=0;j<GetSize(outputs);j++)m->connect(outputs[j],nets[bestroots[j]]);
                for(auto c:cone)removed.insert(c);
                changed++;
            }
            for(auto c:removed)m->remove(c);
        }
        design->scratchpad_set_int("pmux_rom.groups",changed);
        log("pmux_rom: changed groups=%d, dry-run=%d\n",changed,int(dry));
        for(auto &s:skips)log("pmux_rom: skip %s=%d\n",s.first,s.second);
        if(out.is_open()) {
            out<<"{\"schema_version\":1,\"dry_run\":"<<(dry?"true":"false")<<",\"changed_groups\":"<<changed<<",\"groups\":[";
            for(size_t j=0;j<records.size();j++){if(j)out<<',';out<<records[j];}out<<"],\"skips\":{";
            bool first=true;for(auto&s:skips){if(!first)out<<',';first=false;out<<'"'<<s.first<<"\":"<<s.second;}out<<"}}\n";
            out.close(); if(!out)log_cmd_error("Failed to finish %s.\n",json);
        }
    }
} PmuxRomPass;
PRIVATE_NAMESPACE_END
