#ifndef PMUX_LUT_COST_H
#define PMUX_LUT_COST_H
#include <algorithm>
#include <cstdint>
#include <functional>
#include <map>
#include <set>
#include <stdexcept>
#include <tuple>
#include <vector>

// Technology-independent Boolean DAG, bounded 4-input cuts, shared cover.
// An estimate of LUT count/depth, not a timing or final ABC mapping guarantee.
namespace pmux_lut {
struct Node { std::vector<int> inputs; uint64_t truth=0; bool input=false; };
struct Graph {
    std::vector<Node> nodes = {{{},0,false}, {{},1,false}};
    std::map<std::pair<std::vector<int>,uint64_t>,int> unique;
    int input() { nodes.push_back({{},0,true}); return int(nodes.size())-1; }
    int lut(std::vector<int> inputs, uint64_t truth) {
        auto key=std::make_pair(inputs,truth); auto it=unique.find(key);
        if(it!=unique.end()) return it->second;
        int id=int(nodes.size()); nodes.push_back({inputs,truth,false}); unique[key]=id; return id;
    }
    int mux(int a,int b,int s) {
        if(a==b) return a;
        if(s==0 || s==1) return s==0?a:b;
        return lut({a,b,s},0xca);
    }
};
struct Cost { int luts=0, depth=0, max_fanout=0; };
inline Cost estimate(const Graph &g, const std::vector<int> &roots, int cut_limit=32) {
    if(cut_limit<1)throw std::invalid_argument("LUT cut limit must be positive");
    using Cut=std::vector<int>;
    const int n=int(g.nodes.size());
    std::vector<std::vector<Cut>> cuts(n);
    std::vector<Cut> best(n);
    std::vector<double> flow(n,0);
    std::vector<int> depth(n,0), refs(n,0);
    for(int id=0;id<n;id++) {
        if(g.nodes[id].inputs.size()>4)throw std::invalid_argument("LUT cost node has more than four inputs");
        for(int x:g.nodes[id].inputs) {
            if(x<0 || x>=id)throw std::invalid_argument("LUT graph must be topologically ordered");
            refs[x]++;
        }
    }
    for(int r:roots) refs.at(r)++;
    cuts[0]={{}}; cuts[1]={{}};
    for(int id=2;id<n;id++) {
        auto &node=g.nodes[id];
        if(node.input) { cuts[id]={{id}}; continue; }
        std::vector<Cut> combinations={{}};
        auto rank=[&](const Cut &c) {
            double area=1; int d=0;
            for(int v:c) { area+=flow[v]/std::max(1,refs[v]); d=std::max(d,depth[v]); }
            return std::make_tuple(area,d,c.size(),c);
        };
        for(int x:node.inputs) {
            std::set<Cut> next;
            for(auto &a:combinations) for(auto &b:cuts[x]) {
                Cut joined=a; joined.insert(joined.end(),b.begin(),b.end());
                std::sort(joined.begin(),joined.end());
                joined.erase(std::unique(joined.begin(),joined.end()),joined.end());
                if(joined.size()<=4) next.insert(joined);
            }
            combinations.assign(next.begin(),next.end());
            std::sort(combinations.begin(),combinations.end(),[&](const Cut&a,const Cut&b){return rank(a)<rank(b);});
            if(int(combinations.size())>cut_limit) combinations.resize(cut_limit);
        }
        // Partial beam pruning can discard the only extendable cut. Always
        // restore the direct-fanin cover; it fits even at cut_limit=1.
        Cut fallback;for(int x:node.inputs)if(x>=2)fallback.push_back(x);
        std::sort(fallback.begin(),fallback.end());fallback.erase(std::unique(fallback.begin(),fallback.end()),fallback.end());
        if(std::find(combinations.begin(),combinations.end(),fallback)==combinations.end())combinations.push_back(fallback);
        std::sort(combinations.begin(),combinations.end(),[&](const Cut&a,const Cut&b){return rank(a)<rank(b);});
        if(int(combinations.size())>cut_limit)combinations.resize(cut_limit);
        best[id]=combinations.front(); flow[id]=1;
        for(int v:best[id]) { flow[id]+=flow[v]/std::max(1,refs[v]); depth[id]=std::max(depth[id],depth[v]); }
        depth[id]++;
        cuts[id]=combinations; cuts[id].push_back({id});
    }
    Cost result; std::set<int> cover; std::map<int,int> mapped_refs;
    std::function<void(int)> visit=[&](int id) {
        mapped_refs[id]++;
        if(id<2 || g.nodes[id].input || !cover.insert(id).second) return;
        for(int v:best[id]) visit(v);
    };
    for(int r:roots) { visit(r); result.depth=std::max(result.depth,depth[r]); }
    result.luts=int(cover.size());
    for(auto &entry:mapped_refs) if(entry.first>=2) result.max_fanout=std::max(result.max_fanout,entry.second);
    return result;
}
inline bool profitable(const Cost &before,const Cost &after) {
    return after.luts<before.luts && after.depth<=before.depth &&
        after.max_fanout<=std::max(8,before.max_fanout);
}
}
#endif
