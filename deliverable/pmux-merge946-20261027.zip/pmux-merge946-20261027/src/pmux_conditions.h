#ifndef PMUX_CONDITIONS_H
#define PMUX_CONDITIONS_H
#include "kernel/yosys.h"
#include "kernel/sigtools.h"
#include "kernel/celltypes.h"
#include <map>
#include <set>

YOSYS_NAMESPACE_BEGIN
namespace pmux {
inline bool protected_object(const RTLIL::AttrObject *obj) {
    return obj->get_bool_attribute(ID::keep) || obj->get_bool_attribute(RTLIL::IdString("\\dont_touch"));
}
using Facts = std::map<SigBit, State>;
// One context per module. All facts use canonical signals. Unknown port
// directions and multiply driven aliases are rejected, never guessed.
struct ConditionContext {
    SigMap sigmap;
    std::map<SigBit, int> drivers;
    std::map<SigBit, RTLIL::Cell*> source;
    std::set<SigBit> protected_bits;
    int remaining, max_depth;
    std::string reason;
    ConditionContext(RTLIL::Design *design, RTLIL::Module *module, int nodes=4096, int depth=8)
        : sigmap(module), remaining(nodes), max_depth(depth) {
        CellTypes types(design);
        for (auto wire : module->wires()) {
            for (auto bit : sigmap(SigSpec(wire))) {
                if (wire->port_input && bit.wire) drivers[bit]++;
                if (protected_object(wire)) protected_bits.insert(bit);
            }
        }
        for (auto cell : module->cells())
            for (auto &port : cell->connections())
                if (!types.cell_known(cell->type) || types.cell_output(cell->type, port.first))
                    for (auto bit : sigmap(port.second)) if (bit.wire) {
                        drivers[bit]++;
                        source[bit] = cell;
                    }
    }
    RTLIL::Cell *driver(SigBit bit) {
        if (!bit.wire || protected_bits.count(bit) || drivers[bit] != 1) return nullptr;
        auto it = source.find(bit);
        if (it == source.end() || protected_object(it->second)) return nullptr;
        return it->second;
    }
    bool add_fact(Facts &facts, SigBit bit, State value) {
        if (!bit.wire) {
            if (bit.data != value) { reason="contradictory_facts"; return false; }
            return true;
        }
        if (protected_bits.count(bit) || drivers[bit] != 1) { reason="protected_or_ambiguous_data"; return false; }
        auto it=facts.find(bit);
        if (it != facts.end() && it->second != value) { reason="contradictory_facts"; return false; }
        facts[bit]=value; return true;
    }
    bool derive_facts(SigBit predicate, bool active, Facts &facts, int depth=0) {
        if (depth > max_depth || remaining-- <= 0) { reason="budget"; return false; }
        if (!predicate.wire) {
            if (predicate.data == (active ? State::S1 : State::S0)) return true;
            reason="constant_or_unreachable_predicate"; return false;
        }
        auto cell=driver(predicate);
        if (!cell) { reason="unsupported_or_ambiguous_predicate"; return false; }
        if (!cell->hasPort(ID::Y)) { reason="unsupported_predicate"; return false; }
        auto y=sigmap(cell->getPort(ID::Y));
        if (GetSize(y)!=1 || y[0]!=predicate) { reason="non_scalar_predicate"; return false; }
        if (cell->type.in(ID($not), ID($_NOT_), ID($logic_not))) {
            auto a=sigmap(cell->getPort(ID::A));
            if (GetSize(a)==1) return derive_facts(a[0],!active,facts,depth+1);
        }
        if (active && cell->type.in(ID($and), ID($logic_and), ID($_AND_))) {
            auto a=sigmap(cell->getPort(ID::A)), b=sigmap(cell->getPort(ID::B));
            if (GetSize(a)==1 && GetSize(b)==1)
                return derive_facts(a[0],true,facts,depth+1) && derive_facts(b[0],true,facts,depth+1);
        }
        if (!active || cell->type != ID($eq)) { reason="unsupported_predicate"; return false; }
        auto a=sigmap(cell->getPort(ID::A)), b=sigmap(cell->getPort(ID::B));
        // Verilog comparison sign-extends only when BOTH operands are signed.
        bool sign=cell->getParam(ID::A_SIGNED).as_bool() && cell->getParam(ID::B_SIGNED).as_bool();
        int width=std::max(GetSize(a),GetSize(b));
        if (width < 1 || width > remaining) { reason="budget"; return false; }
        remaining-=width;
        a.extend_u0(width,sign); b.extend_u0(width,sign);
        if (!a.is_fully_const() && b.is_fully_const()) std::swap(a,b);
        if (!a.is_fully_const() || !a.as_const().is_fully_def()) { reason="non_binary_comparison"; return false; }
        for (int i=0;i<width;i++) if (!add_fact(facts,b[i],a[i].data)) return false;
        return true;
    }
    // W3-T2: recursive branch-local propagation with bounded backtracking.
    // Returns a replacement bit: a 0/1 constant or an existing signal bit
    // upstream of the simplified bit. Never creates cells, never inverts a
    // live signal. Unknown operands are opaque symbols; only absorption and
    // identity rules apply, mirroring opt_expr's per-bit reductions.
    std::map<std::string, std::map<SigBit, SigBit>> simplify_cache;
    bool propagation=true; // W3-T2 scratchpad-gated ablation switch
    std::string facts_signature(const Facts &facts) {
        std::string s;
        for (auto &kv : facts) {
            s+=log_signal(kv.first); s+='='; s+=kv.second==State::S1?'1':'0'; s+=';';
        }
        return s;
    }
    // 0 = opaque, 1 = const 0, 2 = const 1, 3 = signal bit (r)
    int resolve_operand(SigBit b, const Facts &facts, const std::string &sig, SigBit &r, int depth) {
        b=sigmap(b);
        if (!b.wire) {
            if (b.data==State::S0) { r=SigBit(State::S0); return 1; }
            if (b.data==State::S1) { r=SigBit(State::S1); return 2; }
            return 0; // x/z: opaque in every rule below
        }
        auto it=facts.find(b);
        if (it!=facts.end()) { r=SigBit(it->second); return it->second==State::S0?1:2; }
        if (simplify_bit(b,facts,sig,r,depth)) return r.wire?3:(r.data==State::S0?1:2);
        return 0;
    }
    bool simplify_bit(SigBit bit, const Facts &facts, const std::string &sig, SigBit &out, int depth) {
        bit=sigmap(bit);
        if (!bit.wire) { // raw constant input: only 0/1 are usable replacements
            if (bit.data==State::S0 || bit.data==State::S1) { out=bit; return true; }
            return false;
        }
        if (protected_bits.count(bit)) return false;
        auto it=facts.find(bit);
        if (it!=facts.end()) { out=SigBit(it->second); return true; }
        auto &cc=simplify_cache[sig];
        auto ci=cc.find(bit);
        if (ci!=cc.end()) { out=ci->second; return true; }
        if (depth > max_depth || remaining-- <= 0) { reason="budget"; return false; }
        auto cell=driver(bit);
        if (!cell) return false; // primary input or dangling: no simplification
        if (!propagation) { // W3-T2 ablation switch: legacy direct/inverted-only
            if (!cell->type.in(ID($not),ID($_NOT_))) return false;
            auto a=sigmap(cell->getPort(ID::A)), y=sigmap(cell->getPort(ID::Y));
            if (GetSize(a)!=GetSize(y)) return false;
            for (int i=0;i<GetSize(y);i++) if (y[i]==bit) {
                auto fact=facts.find(a[i]);
                if (fact!=facts.end()) { out=SigBit(fact->second==State::S1?State::S0:State::S1); return true; }
            }
            return false;
        }
        if (!cell->hasPort(ID::Y)) return false; // e.g. $dff/$adff drivers: no Y port, getPort would throw dict::at
        auto yport=sigmap(cell->getPort(ID::Y));
        int j=-1;
        for (int i=0;i<GetSize(yport);i++) if (yport[i]==bit) { j=i; break; }
        if (j<0) return false;
        bool ok=false; SigBit result;
        auto ty=cell->type;
        auto port=[&](IdString p){ return sigmap(cell->getPort(p)); };
        auto finish=[&](SigBit r){ result=r; ok=true; };
        if (ty.in(ID($not),ID($_NOT_),ID($logic_not))) {
            auto a=port(ID::A);
            if (j<GetSize(a)) {
                SigBit r; int s=resolve_operand(a[j],facts,sig,r,depth);
                if (s==1) finish(SigBit(State::S1));
                else if (s==2) finish(SigBit(State::S0));
                // a live signal bit would need an inverter: no new cells.
            }
        } else if (ty.in(ID($and),ID($_AND_),ID($logic_and)) ||
                   ty.in(ID($or),ID($_OR_),ID($logic_or)) ||
                   ty.in(ID($xor),ID($_XOR_))) {
            auto a=port(ID::A), b=port(ID::B);
            bool logic=ty.in(ID($logic_and),ID($logic_or));
            if (j<GetSize(a) && j<GetSize(b) && (!logic || (GetSize(a)==1 && GetSize(b)==1 && GetSize(yport)==1))) {
                SigBit r1,r2; int s1=resolve_operand(a[j],facts,sig,r1,depth), s2=resolve_operand(b[j],facts,sig,r2,depth);
                bool is_and=ty.in(ID($and),ID($_AND_),ID($logic_and));
                bool is_xor=ty.in(ID($xor),ID($_XOR_));
                int ident=is_and?2:1, absorb=is_and?1:(is_xor?-1:2); // identity/absorbing status; XOR has no absorber
                if (absorb>0 && (s1==absorb||s2==absorb)) finish(SigBit(absorb==1?State::S0:State::S1));
                else if (s1==ident) finish(s2==0?sigmap(b[j]):r2); // 1&x=x / 0|x=x / 0^x=x
                else if (s2==ident) finish(s1==0?sigmap(a[j]):r1);
                else if (s1>=1 && s2>=1) { // both constant (facts or const drivers)
                    bool va=s1==2, vb=s2==2;
                    bool v=is_and?(va&&vb):(is_xor?(va!=vb):(va||vb));
                    finish(SigBit(v?State::S1:State::S0));
                }
                else if (s1==3 && s2==3 && r1==r2)
                    finish(is_xor?SigBit(State::S0):r1); // a*a=a / a|a=a / a^a=0 (opt_expr parity)
            }
        } else if (ty==ID($concat)) {
            auto a=port(ID::A), b=port(ID::B);
            int wb=GetSize(b);
            SigBit seg=j<wb?b[j]:a[j-wb];
            seg=sigmap(seg);
            SigBit r;
            finish(simplify_bit(seg,facts,sig,r,depth)?r:seg); // concat bit is a pure alias
        } else if (ty.in(ID($mux),ID($_MUX_))) {
            auto s0=port(ID::S), d0=port(ID::B), d1=port(ID::A); // $mux: S?A:B
            if (GetSize(s0)==1 && j<GetSize(d0) && j<GetSize(d1)) {
                SigBit rs; int ss=resolve_operand(s0[0],facts,sig,rs,depth);
                auto sel=[&](SigBit d)->SigBit{ SigBit r; return simplify_bit(d,facts,sig,r,depth)?r:sigmap(d); };
                if (ss==2) finish(sel(d1[j]));
                else if (ss==1) finish(sel(d0[j]));
                else if (ss==0 && s0[0].wire) {
                    // S unknown: simplify both arms under S=1 / S=0 facts; only
                    // a converged identical replacement is sound.
                    Facts f1=facts;
                    if (add_fact(f1,s0[0],State::S1)) {
                        Facts f0=facts;
                        if (add_fact(f0,s0[0],State::S0)) {
                            std::string sig1=facts_signature(f1), sig0=facts_signature(f0);
                            SigBit r1,r0;
                            bool o1=simplify_bit(sigmap(d1[j]),f1,sig1,r1,depth+1);
                            bool o0=simplify_bit(sigmap(d0[j]),f0,sig0,r0,depth+1);
                            if (o1&&o0&&r1==r0) finish(r1);
                        }
                    }
                    reason.clear();
                }
            }
        }
        if (ok) { cc[bit]=result; out=result; }
        return ok;
    }
    bool simplify_branch_bit(SigBit bit, const Facts &facts, SigBit &replacement) {
        return simplify_bit(bit,facts,facts_signature(facts),replacement,0);
    }
};
}
YOSYS_NAMESPACE_END
#endif
