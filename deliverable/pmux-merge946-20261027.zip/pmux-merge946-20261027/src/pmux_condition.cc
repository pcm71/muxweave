// Branch-local equality facts. Preserves the native Boolean PMUX expansion
// for arbitrary multi-hot selectors. No global replacements, SAT or new cells.
#include "pmux_conditions.h"
#include "pmux_resources.h"
#include <fstream>
#include <vector>

USING_YOSYS_NAMESPACE
PRIVATE_NAMESPACE_BEGIN
// W3-T2: an edit replaces one branch data bit with a constant (S0/S1) or
// an existing upstream signal bit (recursively propagated replacement).
struct Edit { std::string module,cell,port,predicate,old_bit; int offset; SigBit rep; };
struct PmuxConditionPass : Pass {
    PmuxConditionPass() : Pass("pmux_condition", "simplify mux branch data using bounded equality facts") {}
    void help() override {
        log("    pmux_condition [-auto] [-max-nodes N] [-max-depth N] [-json file]\n\n");
        log("Supports binary $eq constants, scalar AND predicates and branch-local\n");
        log("recursive data propagation (AND/OR/XOR/concat/mux, depth-budgeted):\n");
        log("candidate bits may be replaced by 0/1 constants or existing upstream\n");
        log("signal bits; no new cells are created and no live signal is inverted.\n");
        log("Equality-false yields no facts. Skips X/Z, keep/dont_touch and ambiguous drivers.\n");
        log("Every planned bit edit passes the initstate guard (R0/R1/R2): edits whose\n");
        log("affected Y-bit cone can reach a memory or unknown cell input are dropped;\n");
        log("cones reaching FF D inputs go through a sandboxed const-D vs explicit-init\n");
        log("check (R2), and cones touching FF control inputs are always dropped. Per-reason\n");
        log("counts land in scratchpad pmux_experiment.initstate_guard.* and in the JSON\n");
        log("trace skip_counts. Purely combinational cones ending at output ports (R1) pass.\n");
        log("Automatic integration skips stateful/unknown modules: native FF cleanup can\n");
        log("refine unspecified RTL initialization and change mapped power-up behavior.\n");
        log("Budget is shared across a module; no mapping or subprocess is launched.\n");
    }
    // R2 (W1T4 §2): a batch of edits whose Y bits reach FF D inputs may proceed
    // only when it cannot void any reached FF's explicit power-up semantics.
    // Mechanical check in a cloned sandbox that replays the exact fold site
    // (W1T4 bisect: the D-constantization happens in map_ffram, AFTER the
    // +/techmap.v lowering — at the $dffe level no opt pass folds it): apply
    // the batch, lower to gate primitives, run one opt_expr, then inspect each
    // reached FF's Q: still FF-driven -> safe; replaced by a constant -> the
    // fold happened: reject when the FF has no defined init, require the
    // constant to equal the init otherwise. Reaching an FF control input
    // (CLK/EN/SET/CLR/...) is always rejected: that fold is not an
    // initialization question, and we stay conservative.
    std::string r2_check(RTLIL::Module *module, pmux::ConditionContext &context, CellTypes &ctypes,
                         std::map<SigBit,std::vector<std::pair<RTLIL::Cell*,RTLIL::IdString>>> &sinks,
                         RTLIL::Cell *cell, std::vector<std::pair<Edit,int>> &planned,
                         std::vector<int> &cand, SigSpec &ybits) {
        pool<SigBit> seen;
        std::vector<SigBit> frontier;
        for (int idx : cand) {
            auto b=ybits[planned[idx].second];
            if (b.wire && seen.insert(b).second) frontier.push_back(b);
        }
        pool<RTLIL::Cell*> data_ffs, control_ffs;
        int left=4096; bool budget=false;
        while (!frontier.empty()) {
            if (left--<=0) { budget=true; break; }
            SigBit bit=frontier.back(); frontier.pop_back();
            for (auto &sk : sinks[bit]) {
                RTLIL::Cell *t=sk.first;
                if (pmux::is_memory_cell(t->type) || !ctypes.cell_known(t->type)) return "r0_memory_or_unknown";
                if (pmux::is_sequential_cell(t->type)) {
                    if (sk.second==ID::D) data_ffs.insert(t); else control_ffs.insert(t);
                    continue;
                }
                for (auto &conn : t->connections())
                    if (ctypes.cell_output(t->type,conn.first))
                        for (auto ob : context.sigmap(conn.second))
                            if (ob.wire && seen.insert(ob).second) frontier.push_back(ob);
            }
        }
        if (budget) return "r2_budget";
        if (!control_ffs.empty()) return "r2_control_cone";
        if (data_ffs.empty()) return "";
        RTLIL::Design *scratch=new RTLIL::Design;
        RTLIL::Module *sm=scratch->addModule(module->name);
        module->cloneInto(sm);
        auto sc=sm->cell(cell->name);
        std::map<char,SigSpec> ports;
        for (int idx : cand) {
            Edit &e=planned[idx].first;
            RTLIL::IdString pid = e.port[0]=='A' ? ID::A : ID::B;
            if (!ports.count(e.port[0])) ports[e.port[0]]=sc->getPort(pid);
            ports[e.port[0]][e.offset]=e.rep;
        }
        for (auto &kv : ports) sc->setPort(kv.first=='A'?ID::A:ID::B, kv.second);
        Pass::call(scratch,"opt -fast -mux_undef -undriven -fine -full");
        Pass::call(scratch,"techmap -map +/techmap.v");
        Pass::call(scratch,"opt -full");
        SigMap smap(sm);
        std::map<SigBit,RTLIL::Cell*> sdrv;
        for (auto c : sm->cells())
            for (auto &conn : c->connections())
                if (c->output(conn.first))
                    for (auto b : smap(conn.second)) if (b.wire) sdrv[b]=c;
        std::string fail;
        for (auto ff : data_ffs) {
            // Track the Q signal by name: the sandbox keeps port wires even
            // after the FF is dissolved, so this works folded or not.
            auto q=ff->getPort(ID::Q);
            if (GetSize(q)<1 || !q[0].wire) { fail="r2_sandbox_lost_ff"; break; }
            Const init;
            bool has_init=pmux::ff_defined_init(ff,q[0].wire,init);
            for (int i=0;i<GetSize(q);i++) {
                if (!q[i].wire) { fail="r2_sandbox_lost_ff"; break; }
                auto w=sm->wire(q[i].wire->name);
                if (!w) { fail="r2_sandbox_lost_ff"; break; }
                SigBit cur=smap(SigBit(w,q[i].offset));
                bool folded=false; State val=State::Sx;
                pool<SigBit> alias_seen;
                for (int hop=0; hop<16; hop++) {
                    if (!cur.wire) { folded=true; val=cur.data; break; }
                    if (!alias_seen.insert(cur).second) { fail="r2_sandbox_unknown"; break; } // alias loop
                    bool aliased=false;
                    for (auto &cn : sm->connections()) {
                        auto lhs=smap(cn.first), rhs=smap(cn.second);
                        for (int j=0;j<GetSize(lhs) && j<GetSize(rhs);j++)
                            if (lhs[j]==cur && rhs[j]!=cur) { // skip identity-alias noise from opt
                                if (!rhs[j].wire) { folded=true; val=rhs[j].data; }
                                else cur=rhs[j];
                                aliased=true; break;
                            }
                        if (aliased) break;
                    }
                    if (folded) break;
                    if (aliased) continue; // follow the alias (opt leaves identity/permutation connects behind)
                    auto it=sdrv.find(cur);
                    if (it==sdrv.end()) { fail="r2_sandbox_unknown"; break; } // no driver at all: unmodelled
                    if (pmux::is_sequential_cell(it->second->type)) break; // still FF-driven
                    if (pmux::is_memory_cell(it->second->type) || !ctypes.cell_known(it->second->type)) { fail="r0_memory_or_unknown"; break; }
                    // A combinational driver on a former FF output means the
                    // sandbox saw a shape we do not model; stay conservative.
                    fail="r2_sandbox_unknown"; break;
                }
                if (!fail.empty()) break;
                if (!folded) continue;
                if (!has_init) { fail="r2_uninit_const_d"; break; }
                if (i>=GetSize(init) || !(val==init[i])) { fail="r2_init_mismatch"; break; }
            }
            if (!fail.empty()) break;
        }
        delete scratch;
        return fail;
    }
    void execute(std::vector<std::string> args, RTLIL::Design *design) override {
        bool automatic=false; int nodes=4096,depth=8; std::string json;
        size_t i=1;
        for (;i<args.size();i++) {
            if (args[i]=="-auto") { automatic=true; continue; }
            if (args[i]=="-json" && i+1<args.size()) { json=args[++i]; continue; }
            if ((args[i]=="-max-nodes" || args[i]=="-max-depth") && i+1<args.size()) {
                bool n=args[i]=="-max-nodes"; auto token=args[++i];
                if (token.empty() || token.find_first_not_of("0123456789")!=std::string::npos || token.size()>6)
                    log_cmd_error("pmux_condition: invalid budget.\n");
                int value=std::stoi(token);
                if (value<1 || value>(n?100000:64)) log_cmd_error("pmux_condition: budget out of range.\n");
                if(n) nodes=value; else depth=value; continue;
            }
            break;
        }
        extra_args(args,i,design);
        if (automatic && !design->scratchpad_get_bool("pmux_opt.condition",false)) return;
        // Open trace before editing so an invalid output path leaves the design intact.
        std::ofstream trace;
        if (!json.empty()) { trace.open(json); if (!trace) log_cmd_error("Cannot write %s.\n",json); }
        int examined=0,changed_cells=0,changed_bits=0;
        int guard_skipped=0,guard_passed=0;
        std::map<std::string,int> skips,guard_reasons;
        std::vector<Edit> edits;
        for (auto module : design->selected_modules()) {
            if (module->get_blackbox_attribute() || pmux::protected_object(module)) continue;
            if (!module->processes.empty()) { skips["unlowered_process"]++; continue; }
            if (automatic) {
                // A locally exact data rewrite can enable constant-register removal.
                // Unspecified RTL init permits that refinement, while the required
                // mapped reference has explicit device power-up semantics. Do not
                // silently promote this mismatch into the synthesis integration.
                // F1 fix (W4-T1): legacy CellTypes::is_combinatorial is never true
                // for std cells in Yosys 0.69; classify with the explicit
                // StaticCellTypes categories (FF/latch/memory) + mapped dffeas.
                CellTypes types(design); bool stateful=!module->memories.empty();
                for (auto candidate : module->cells()) {
                    if (!types.cell_known(candidate->type) ||
                        pmux::is_sequential_cell(candidate->type) ||
                        pmux::is_memory_cell(candidate->type)) { stateful=true; break; }
                }
                if (stateful) { skips["stateful_or_unknown_module"]++; continue; }
            }
            bool has_target=false;
            for (auto cell : module->selected_cells()) if (cell->type.in(ID($pmux),ID($mux))) { has_target=true; break; }
            if (!has_target) continue;
            pmux::ConditionContext context(design,module,nodes,depth);
            // W3-T2: recursive propagation sub-switch (ablation; default on
            // when the pass itself is enabled).
            context.propagation=design->scratchpad_get_bool("pmux_condition.propagation",true);
            // R0/R1 initstate guard (W1T4 §2, W4-T1): a planned bit edit is applied
            // only if the fanout cone of the affected Y bit cannot reach any
            // sequential, memory or unknown cell input. Computed once per module
            // by walking backwards from those cell inputs; cones ending at output
            // ports (R1) or primary inputs stop the walk and stay safe.
            CellTypes ctypes(design);
            std::map<SigBit,std::string> unsafe;
            {
                std::vector<SigBit> frontier;
                auto seed=[&](RTLIL::Cell *c,const char *why){
                    bool known=ctypes.cell_known(c->type);
                    for (auto &conn : c->connections())
                        if (!known || ctypes.cell_input(c->type,conn.first))
                            for (auto bit : context.sigmap(conn.second))
                                if (bit.wire && !unsafe.count(bit)) {
                                    unsafe[bit]=why;
                                    frontier.push_back(bit);
                                }
                };
                for (auto c : module->cells()) {
                    if (!ctypes.cell_known(c->type)) seed(c,"unknown_cell");
                    else if (pmux::is_sequential_cell(c->type)) seed(c,"ff_cone");
                    else if (pmux::is_memory_cell(c->type)) seed(c,"memory_cone");
                }
                while (!frontier.empty()) {
                    SigBit bit=frontier.back(); frontier.pop_back();
                    auto *driver=context.driver(bit);
                    if (!driver) continue; // primary input, multidriver or dangling: stop
                    if (!ctypes.cell_known(driver->type) ||
                        pmux::is_sequential_cell(driver->type) ||
                        pmux::is_memory_cell(driver->type)) continue;
                    for (auto &conn : driver->connections())
                        if (ctypes.cell_input(driver->type,conn.first))
                            for (auto b : context.sigmap(conn.second))
                                if (b.wire && !unsafe.count(b)) {
                                    unsafe[b]=unsafe[bit];
                                    frontier.push_back(b);
                                }
                }
            }
            // Sink map for the R2 forward walk: canonical bit -> consuming (cell, input port).
            std::map<SigBit,std::vector<std::pair<RTLIL::Cell*,RTLIL::IdString>>> sinks;
            for (auto c : module->cells()) {
                bool known=ctypes.cell_known(c->type);
                for (auto &conn : c->connections())
                    if (!known || ctypes.cell_input(c->type,conn.first))
                        for (auto bit : context.sigmap(conn.second))
                            if (bit.wire) sinks[bit].push_back({c,conn.first});
            }
            for (auto cell : module->selected_cells()) {
                if (!cell->type.in(ID($pmux),ID($mux))) continue;
                examined++;
                if (pmux::protected_object(cell)) { skips["protected_cell"]++; continue; }
                auto a=cell->getPort(ID::A), b=cell->getPort(ID::B), s=context.sigmap(cell->getPort(ID::S));
                int w=GetSize(a), k=GetSize(s);
                if (w<=0 || k<=0 || (cell->type==ID($mux) && k!=1) || GetSize(b)!=w*k || GetSize(cell->getPort(ID::Y))!=w) {
                    skips["malformed_shape"]++; continue;
                }
                if (int64_t(w)*k>4096) { skips["cell_budget"]++; continue; }
                bool protected_output=false;
                for (auto bit : context.sigmap(cell->getPort(ID::Y)))
                    if (!bit.wire || context.protected_bits.count(bit) || context.drivers[bit]!=1) { protected_output=true; break; }
                if (protected_output) { skips["protected_or_ambiguous_output"]++; continue; }
                // Entire cell edit plan is prepared against the original driver graph.
                auto next_a=a, next_b=b;
                int changed=0;
                // Defer bit writes: each candidate is checked against the guard
                // before it is committed, and only committed edits reach the trace.
                std::vector<std::pair<Edit,int>> planned; // Edit + affected Y bit index
                auto branch=[&](SigSpec &data, int offset, SigBit pred, bool active, const char *port) {
                    pmux::Facts facts; context.reason.clear();
                    if (!context.derive_facts(pred,active,facts)) { skips[context.reason]++; return; }
                    for (int j=0;j<w;j++) {
                        SigBit rep;
                        if (!context.simplify_branch_bit(data[offset+j],facts,rep)) continue;
                        if (rep==context.sigmap(data[offset+j])) continue; // no-op alias
                        planned.push_back({{module->name.str(),cell->name.str(),port,
                            log_signal(pred)+(active?"=1":"=0"),log_signal(data[offset+j]),offset+j,rep},j});
                    }
                };
                for (int n=0;n<k;n++) branch(next_b,n*w,s[n],true,"B");
                if (cell->type==ID($mux)) branch(next_a,0,s[0],false,"A");
                auto ybits=context.sigmap(cell->getPort(ID::Y));
                // Three-way split: R1 pass (cone ends at outputs), R0 reject
                // (memory/unknown), R2 candidates (reach FF D inputs).
                std::vector<int> pass_r1,cand_r2;
                for (int idx=0; idx<GetSize(planned); idx++) {
                    auto it=unsafe.find(ybits[planned[idx].second]);
                    if (it==unsafe.end()) pass_r1.push_back(idx);
                    else if (it->second=="ff_cone") cand_r2.push_back(idx);
                    else { guard_reasons[it->second]++; guard_skipped++; }
                }
                if (!cand_r2.empty()) {
                    std::string why=r2_check(module,context,ctypes,sinks,cell,planned,cand_r2,ybits);
                    if (why.empty()) { for (int idx : cand_r2) pass_r1.push_back(idx); guard_reasons["r2_passed"]+=GetSize(cand_r2); }
                    else { guard_reasons[why]+=GetSize(cand_r2); guard_skipped+=GetSize(cand_r2); }
                }
                for (int idx : pass_r1) {
                    Edit &e=planned[idx].first;
                    SigSpec &target = e.port[0]=='A' ? next_a : next_b;
                    target[e.offset]=e.rep;
                    if (!json.empty()) edits.push_back(e);
                    changed++; guard_passed++;
                }
                if (!changed) { skips["no_related_data"]++; continue; }
                cell->setPort(ID::A,next_a); cell->setPort(ID::B,next_b);
                changed_cells++; changed_bits+=changed;
            }
        }
        design->scratchpad_set_int("pmux_condition.guard_skipped",guard_skipped);
        design->scratchpad_set_int("pmux_condition.guard_passed",guard_passed);
        for (auto &kv : guard_reasons)
            design->scratchpad_set_int("pmux_experiment.initstate_guard."+kv.first,kv.second);
        design->scratchpad_set_int("pmux_condition.examined",examined);
        design->scratchpad_set_int("pmux_condition.changed_cells",changed_cells);
        design->scratchpad_set_int("pmux_condition.changed_bits",changed_bits);
        log("pmux_condition: examined=%d changed_cells=%d changed_bits=%d\n",examined,changed_cells,changed_bits);
        if (!json.empty()) {
            trace << "{\"schema_version\":1,\"examined\":"<<examined<<",\"changed_cells\":"<<changed_cells
                <<",\"changed_bits\":"<<changed_bits<<",\"new_nodes\":0,\"removed_nodes\":0,\"skip_counts\":{";
            bool first=true;
            for(auto &kv:skips) { if(!first) trace<<','; first=false; trace<<'"'<<pmux::json_escape(kv.first)<<"\":"<<kv.second; }
            for(auto &kv:guard_reasons) { if(!first) trace<<','; first=false;
                trace<<'"'<<pmux::json_escape("initstate_"+kv.first)<<"\":"<<kv.second; }
            trace << "},\"edits\":[";
            first=true;
            for(auto &e:edits) {
                if(!first) trace<<','; first=false;
                trace << "{\"module\":\""<<pmux::json_escape(e.module)<<"\",\"cell\":\""<<pmux::json_escape(e.cell)
                    <<"\",\"port\":\""<<e.port<<"\",\"offset\":"<<e.offset<<",\"predicate\":\""<<pmux::json_escape(e.predicate)
                    <<"\",\"old\":\""<<pmux::json_escape(e.old_bit)<<"\",\"value\":";
                if (!e.rep.wire) trace<<(e.rep.data==State::S1?1:0);
                else trace<<"null,\"alias\":\""<<pmux::json_escape(log_signal(e.rep))<<"\"";
                trace<<'}';
            }
            trace << "]}\n"; trace.close(); if(!trace) log_cmd_error("Failed to finish %s.\n",json);
        }
        // No eager PMUX expansion: retain FSM/ROM recognition and native cleanup.
    }
} PmuxConditionPass;
PRIVATE_NAMESPACE_END
