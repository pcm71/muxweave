// Read-only staged diagnostics using the same extractor as pmux_opt.
#include "pmux_features.h"
#include "pmux_resources.h"
#include <fstream>
#include <sstream>
USING_YOSYS_NAMESPACE
PRIVATE_NAMESPACE_BEGIN
struct PmuxAnalyzePass : Pass {
    PmuxAnalyzePass() : Pass("pmux_analyze", "read-only staged mux structure and conditional-data diagnostics") {}
    void help() override {
        log("    pmux_analyze [-json file] [-stage label] [-table] [-max-report N]\n");
        log("Reports mux widths, branch patterns, constants, related-data bits and skip reasons.\n");
        log("Opportunity counts are not mapped LUT savings or formal proofs.\n");
    }
    void execute(std::vector<std::string> args, RTLIL::Design *design) override {
        std::string json,stage="manual"; bool table=false; int max_report=10;
        size_t i=1;
        for(;i<args.size();i++) {
            if(args[i]=="-json" && i+1<args.size()) { json=args[++i]; continue; }
            if(args[i]=="-stage" && i+1<args.size()) { stage=args[++i]; continue; }
            if(args[i]=="-table") { table=true; continue; }
            if(args[i]=="-max-report" && i+1<args.size()) {
                auto token=args[++i];
                if(token.empty() || token.size()>6 || token.find_first_not_of("0123456789")!=std::string::npos)
                    log_cmd_error("Invalid -max-report.\n");
                max_report=std::stoi(token); continue;
            }
            break;
        }
        extra_args(args,i,design);
        pmux::FeatureSummary f;
        std::ostringstream out;
        out<<"{\"schema_version\":3,\"creator\":\"pmux_analyze\",\"stage\":\""<<pmux::json_escape(stage)
            <<"\",\"yosys_version\":\""<<pmux::json_escape(yosys_version_str)<<"\",\"modules\":[";
        bool first_module=true;
        for(auto module:design->selected_modules()) {
            if(module->get_blackbox_attribute()) continue;
            pmux::ConditionContext context(design,module);
            if(!first_module) out<<',';
            first_module=false;
            std::map<std::string,int> histogram;
            for(auto cell:module->selected_cells()) histogram[cell->type.str()]++;
            out<<"{\"name\":\""<<pmux::json_escape(module->name.str())<<"\",\"cell_types\":{";
            bool first=true;
            for(auto &kv:histogram) { if(!first) out<<','; first=false; out<<'"'<<pmux::json_escape(kv.first)<<"\":"<<kv.second; }
            out<<"},\"cells\":["; first=true; int shown=0;
            for(auto cell:module->selected_cells()) {
                if(!cell->type.in(ID($mux),ID($pmux))) continue;
                auto c=pmux::extract_features(cell,context,true); f.add(c);
                if(!first) out<<',';
                first=false;
                out<<"{\"cell\":\""<<pmux::json_escape(cell->name.str())<<"\",\"type\":\""<<cell->type.str()
                    <<"\",\"width\":"<<c.width<<",\"branches\":"<<c.branches
                    <<",\"bits_with_reuse\":"<<c.reused_bits<<",\"shared_bits\":"<<c.shared_bits
                    <<",\"constant_bits\":"<<c.constant_bits<<",\"condition_related_bits\":"<<c.related_bits
                    <<",\"share_skip_reason\":\""<<c.skip_reason<<"\",\"select\":[";
                auto s=context.sigmap(cell->getPort(ID::S));
                for(int n=0;n<GetSize(s);n++) {
                    if(n) out<<',';
                    auto driver=context.driver(s[n]);
                    out<<"{\"bit\":\""<<pmux::json_escape(log_signal(s[n]))<<"\",\"driver_type\":\""
                        <<(driver?driver->type.str():"input_constant_or_ambiguous")<<"\"}";
                }
                out<<"],\"slice_patterns\":[";
                for(size_t n=0;n<c.patterns.size();n++) {
                    if(n) out<<',';
                    out<<"{\"start\":"<<n<<",\"width\":1,\"reuse\":"<<(c.patterns[n].reuse?"true":"false")<<",\"pattern\":[";
                    auto &key=c.patterns[n].key;
                    for(size_t k=0;k<key.size();k++) { if(k) out<<','; out<<key[k]; }
                    out<<"]}";
                }
                out<<"]}";
                if(table && (!max_report || shown++<max_report)) log("%s.%s W=%d K=%d reuse=%d related=%d skip=%s\n",
                    module->name,cell->name,c.width,c.branches,c.reused_bits,c.related_bits,c.skip_reason);
            }
            out<<"]}";
        }
        out<<"],\"summary\":{\"pmux_cells\":"<<f.pmux_count<<",\"mux_cells\":"<<f.mux_count
            <<",\"cells_with_reuse\":"<<f.cells_with_reuse<<",\"bits_with_reuse_total\":"<<f.bits_with_reuse_total
            <<",\"shared_pattern_bits\":"<<f.shared_bits_total<<",\"max_width\":"<<f.max_w<<",\"max_choices\":"<<f.max_k
            <<",\"constant_bits\":"<<f.constant_bits<<",\"condition_related_bits\":"<<f.related_bits<<"}}\n";
        if(!json.empty()) {
            std::ofstream file(json); if(!file) log_cmd_error("Cannot write %s.\n",json);
            file<<out.str(); file.close(); if(!file) log_cmd_error("Cannot finish %s.\n",json);
        }
        log("pmux_analyze: stage=%s pmux=%d mux=%d related_bits=%d shared_pattern_bits=%d\n",
            stage,f.pmux_count,f.mux_count,f.related_bits,f.shared_bits_total);
    }
} PmuxAnalyzePass;
PRIVATE_NAMESPACE_END
