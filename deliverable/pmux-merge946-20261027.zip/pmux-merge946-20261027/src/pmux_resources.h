#ifndef PMUX_RESOURCES_H
#define PMUX_RESOURCES_H

#include "kernel/yosys.h"
#include "kernel/celltypes.h"
#include <map>
#include <set>
#include <sstream>

YOSYS_NAMESPACE_BEGIN
namespace pmux {

// F1 (W4-T1): Yosys 0.69's legacy CellTypes never sets is_combinatorial for any
// cell (kernel/celltypes.h), so it cannot be used to detect sequential logic.
// Classify with the explicit StaticCellTypes categories instead. Mapped-device
// FFs (Cyclone dffeas) are not std cells; match them by name as pmux_resources
// already does. $future_ff/$anyinit hold state (or unknown initial state) too.
inline bool is_sequential_cell(RTLIL::IdString type) {
    return StaticCellTypes::categories.is_ff(type) ||
           StaticCellTypes::categories.is_anyinit(type) ||
           type == ID($future_ff) ||
           RTLIL::unescape_id(type) == "dffeas";
}
inline bool is_memory_cell(RTLIL::IdString type) {
    return StaticCellTypes::categories.is_mem_noff(type);
}
// R2 (W4-T1): explicit-power-up detection. RTL initial blocks surface as the
// \init attribute on the Q wire at this flow stage (the \INIT parameter only
// appears later); mapped dffeas carries \power_up ("low"/"high"). Anything
// containing x — or no attribute at all — means the device start state is
// unspecified here, and folding stays legal.
inline bool ff_defined_init(RTLIL::Cell *cell, RTLIL::Wire *qwire, Const &init) {
    if (qwire && qwire->attributes.count(ID::init)) {
        init = qwire->attributes.at(ID::init);
        return init.is_fully_def();
    }
    if (RTLIL::unescape_id(cell->type) == "dffeas") {
        if (!cell->hasParam(RTLIL::IdString("\\power_up"))) return false;
        std::string p = cell->getParam(RTLIL::IdString("\\power_up")).decode_string();
        if (p == "low")  { init = Const(0, 1); return true; }
        if (p == "high") { init = Const(1, 1); return true; }
        return false;
    }
    if (!cell->hasParam(ID::INIT)) return false;
    init = cell->getParam(ID::INIT);
    return init.is_fully_def();
}


// Count physical leaf instances reachable from the top, not library definitions.
// Multi-bit generic FFs are counted by storage bits; mapped dffeas is one bit.
struct Resources {
    int64_t lut = 0, inverter = 0, sequential = 0, io = 0, unmapped_logic = 0;
    int64_t input_bits = 0, output_bits = 0, inout_bits = 0;
    std::map<std::string, int64_t> other;
    int64_t logic() const { return lut + inverter; }
};

inline void add_leaf_resources(Resources &r, const Resources &child)
{
    r.lut += child.lut;
    r.inverter += child.inverter;
    r.sequential += child.sequential;
    r.io += child.io;
    r.unmapped_logic += child.unmapped_logic;
    for (auto &entry : child.other) r.other[entry.first] += entry.second;
}

inline const Resources &count_module(RTLIL::Design *design, RTLIL::Module *module,
                         std::map<RTLIL::IdString, Resources> &cache,
                         std::set<RTLIL::IdString> &active, const CellTypes &types)
{
    auto cached = cache.find(module->name);
    if (cached != cache.end()) return cached->second;
    if (!active.insert(module->name).second)
        log_cmd_error("pmux_opt: recursive hierarchy at %s.\n", module->name);
    Resources r;
    for (auto cell : module->cells()) {
        const auto type = cell->type;
        const std::string name = RTLIL::unescape_id(type);
        if (type == ID($lut) || name == "cycloneiv_lcell_comb" || name == "cycloneive_lcell_comb")
            r.lut++;
        else if (type == ID($_NOT_) || type == ID($not))
            r.inverter += cell->hasPort(ID::Y) ? cell->getPort(ID::Y).size() : 1;
        else if (StaticCellTypes::categories.is_ff(type) || name == "dffeas")
            r.sequential += cell->hasPort(ID::Q) ? cell->getPort(ID::Q).size() : 1;
        else if (name == "$__inpad" || name == "$__outpad" || name == "$__iopad" ||
                 name == "cycloneiv_io" || name == "cycloneive_io" ||
                 name == "cycloneiv_io_ibuf" || name == "cycloneiv_io_obuf" ||
                 name == "cycloneive_io_ibuf" || name == "cycloneive_io_obuf")
            r.io++;
        else if (types.cell_evaluable(type))
            r.unmapped_logic++;
        else {
            auto child = design->module(type);
            if (child && !child->get_blackbox_attribute() && !child->get_bool_attribute(ID::whitebox))
                add_leaf_resources(r, count_module(design, child, cache, active, types));
            else
                r.other[name]++;
        }
    }
    active.erase(module->name);
    return cache.emplace(module->name, std::move(r)).first->second;
}

inline Resources count_resources(RTLIL::Design *design, const CellTypes &types)
{
    auto top = design->top_module();
    if (!top) log_cmd_error("pmux_opt: run hierarchy -top <name> first.\n");
    Resources r;
    for (auto wire : top->wires()) {
        if (wire->port_input && wire->port_output) r.inout_bits += wire->width;
        else if (wire->port_input) r.input_bits += wire->width;
        else if (wire->port_output) r.output_bits += wire->width;
    }
    std::set<RTLIL::IdString> active;
    // Invocation-local: every module is traversed once, but its subtotal is
    // added for every physical instance. Never reuse across design mutations.
    std::map<RTLIL::IdString, Resources> cache;
    add_leaf_resources(r, count_module(design, top, cache, active, types));
    return r;
}

// Other callers keep invocation-local type setup and resource traversal.
inline Resources count_resources(RTLIL::Design *design)
{
    CellTypes types;
    types.setup();
    return count_resources(design, types);
}

inline std::string reject_reason(const Resources &before, const Resources &after)
{
    if (after.unmapped_logic) return "unmapped combinational cells remain";
    if (after.sequential > before.sequential) return "sequential bits increased";
    if (after.io > before.io) return "IO cells increased";
    if (after.input_bits != before.input_bits || after.output_bits != before.output_bits ||
        after.inout_bits != before.inout_bits) return "top-level port widths changed";
    for (auto &kv : after.other) {
        auto it = before.other.find(kv.first);
        if (it == before.other.end() || kv.second > it->second)
            return "other resource increased: " + kv.first;
    }
    return "";
}

inline std::string json_escape(const std::string &s)
{
    std::ostringstream out;
    const char *hex = "0123456789abcdef";
    for (unsigned char c : s) {
        if (c == '\\' || c == '"') out << '\\' << char(c);
        else if (c < 32) out << "\\u00" << hex[c >> 4] << hex[c & 15];
        else out << char(c);
    }
    return out.str();
}

inline std::string resources_json(const Resources &r)
{
    std::ostringstream o;
    o << "{\"lut\":" << r.lut << ",\"inverter\":" << r.inverter
      << ",\"logic\":" << r.logic() << ",\"sequential_bits\":" << r.sequential
      << ",\"io\":" << r.io << ",\"unmapped_logic\":" << r.unmapped_logic
      << ",\"input_bits\":" << r.input_bits << ",\"output_bits\":" << r.output_bits
      << ",\"inout_bits\":" << r.inout_bits << ",\"other\":{";
    bool first = true;
    for (auto &kv : r.other) {
        if (!first) o << ',';
        first = false;
        o << '"' << json_escape(kv.first) << "\":" << kv.second;
    }
    o << "}}";
    return o.str();
}
} // namespace pmux
YOSYS_NAMESPACE_END
#endif
