#ifndef PMUX_CROSS_H
#define PMUX_CROSS_H
#include "pmux_conditions.h"
#include "pmux_lut_cost.h"
#include <algorithm>
#include <iterator>

YOSYS_NAMESPACE_BEGIN
namespace pmux {
// First bounded cross-cell rule: group identical whole data words, then share
// a proper common subset of their selectors. PMUX multi-hot OR semantics hold.
// Only primary-input data/selects and unused module-output destinations qualify.
// No state input or internal feedback can be affected by this initial rule.
struct CrossCell {
    RTLIL::Cell *cell;
    SigSpec a,b,s;
    std::map<std::vector<SigBit>,std::vector<SigBit>> groups;
};
inline bool cross_contains(const std::vector<SigBit>& a,const std::vector<SigBit>& b) {
    return std::includes(a.begin(),a.end(),b.begin(),b.end());
}
inline int cross_share(RTLIL::Design *design) {
    int rewritten=0, subsets=0, estimated=0;
    for (auto module:design->selected_modules()) {
        if (module->get_blackbox_attribute() || protected_object(module) ||
            !module->processes.empty() || !module->memories.empty()) continue;
        ConditionContext ctx(design,module);
        CellTypes types(design);
        std::set<SigBit> inputs,outputs,used;
        for(auto wire:module->wires()) for(auto bit:ctx.sigmap(SigSpec(wire))) {
            if(wire->port_input) inputs.insert(bit);
            if(wire->port_output) outputs.insert(bit);
        }
        for(auto cell:module->cells()) for(auto &port:cell->connections())
            if(!types.cell_known(cell->type) || types.cell_input(cell->type,port.first))
                for(auto bit:ctx.sigmap(port.second)) used.insert(bit);
        std::vector<CrossCell> cells;
        int size=0;
        for(auto cell:module->selected_cells()) {
            if(cell->type!=ID($pmux) || protected_object(cell)) continue;
            CrossCell c{cell,ctx.sigmap(cell->getPort(ID::A)),ctx.sigmap(cell->getPort(ID::B)),ctx.sigmap(cell->getPort(ID::S)),{}};
            int w=GetSize(c.a),k=GetSize(c.s);
            if(w<1 || w>16 || k<3 || k>16 || GetSize(c.b)!=w*k || GetSize(cell->getPort(ID::Y))!=w) continue;
            bool safe=true;
            for(auto sig:{c.a,c.b,c.s}) for(auto bit:sig)
                if(ctx.protected_bits.count(bit) || (bit.wire ? !inputs.count(bit) || ctx.drivers[bit]!=1 : bit.data!=State::S0 && bit.data!=State::S1)) safe=false;
            for(auto bit:ctx.sigmap(cell->getPort(ID::Y)))
                if(!bit.wire || !outputs.count(bit) || used.count(bit) || ctx.drivers[bit]!=1 || ctx.protected_bits.count(bit)) safe=false;
            if(!safe) continue;
            for(int i=0;i<k;i++) c.groups[c.b.extract(i*w,w).to_sigbit_vector()].push_back(c.s[i]);
            bool repeated=false;
            for(auto &g:c.groups) {
                auto &v=g.second;std::sort(v.begin(),v.end());v.erase(std::unique(v.begin(),v.end()),v.end());
                repeated|=v.size()>2;
            }
            if(!repeated) continue;
            size+=w*k;cells.push_back(c);
            if(size>256 || cells.size()>16) break;
        }
        if(size>256 || cells.size()>16) { log("pmux_cross: module budget, skip %s\n",module->name);continue; }
        std::set<std::vector<SigBit>> candidates;
        for(size_t i=0;i<cells.size();i++) for(size_t j=i+1;j<cells.size();j++)
            for(auto &a:cells[i].groups) for(auto &b:cells[j].groups) {
                std::vector<SigBit> common;
                std::set_intersection(a.second.begin(),a.second.end(),b.second.begin(),b.second.end(),std::back_inserter(common));
                if(common.size()>=2 && common.size()<=4 && common.size()<std::min(a.second.size(),b.second.size()) &&
                   std::all_of(common.begin(),common.end(),[](SigBit bit){return bit.wire!=nullptr;})) candidates.insert(common);
            }
        if(candidates.size()>32) { log("pmux_cross: subset budget, skip %s\n",module->name);continue; }
        std::vector<SigBit> best;
        std::vector<int> chosen;
        pmux_lut::Cost best_before,best_grouped,best_after;
        for(auto &subset:candidates) {
            std::vector<int> component;int uses=0;
            for(size_t i=0;i<cells.size();i++) {
                bool hit=false;
                for(auto &g:cells[i].groups) if(cross_contains(g.second,subset)) {hit=true;uses++;}
                if(hit)component.push_back(i);
            }
            if(component.size()<2 || uses>8) continue;
            auto cost=[&](int mode) {
                pmux_lut::Graph graph;std::map<SigBit,int> ids;
                auto value=[&](SigBit bit) {
                    if(!bit.wire)return bit.data==State::S1?1:0;
                    auto it=ids.find(bit);if(it!=ids.end())return it->second;
                    return ids[bit]=graph.input();
                };
                auto or_node=[&](int a,int b){return a==0?b:b==0?a:a==b?a:graph.lut({a,b},14);};
                auto raw=[&](const std::vector<SigBit>& bits){int r=0;for(auto bit:bits)r=or_node(r,value(bit));return r;};
                int shared=mode==2?raw(subset):0;
                auto reduce=[&](const std::vector<SigBit>& bits) {
                    if(mode!=2 || !cross_contains(bits,subset))return raw(bits);
                    int r=shared;for(auto bit:bits)if(!std::binary_search(subset.begin(),subset.end(),bit))r=or_node(r,value(bit));return r;
                };
                std::vector<int> roots;
                for(int index:component) {
                    auto &c=cells[index];int w=GetSize(c.a),k=GetSize(c.s),any=0;
                    std::vector<int> selected(w,0);
                    auto term=[&](int data,int enable){return data==0?0:data==1?enable:graph.lut({data,enable},8);};
                    if(mode==0) {
                        any=raw(c.s.to_sigbit_vector());
                        for(int i=0;i<k;i++)for(int j=0;j<w;j++)selected[j]=or_node(selected[j],term(value(c.b[i*w+j]),value(c.s[i])));
                    } else for(auto &g:c.groups) {
                        int enable=reduce(g.second);any=or_node(any,enable);
                        for(int j=0;j<w;j++)selected[j]=or_node(selected[j],term(value(g.first[j]),enable));
                    }
                    for(int j=0;j<w;j++)roots.push_back(graph.mux(value(c.a[j]),selected[j],any));
                }
                return pmux_lut::estimate(graph,roots);
            };
            auto before=cost(0),grouped=cost(1),after=cost(2);
            // Demand an incremental gain over whole-word grouping as well as
            // native expansion, including joint depth and mapped fanout bounds.
            if(!pmux_lut::profitable(before,after) || !pmux_lut::profitable(grouped,after))continue;
            if(best.empty() || grouped.luts-after.luts>best_grouped.luts-best_after.luts) {
                best=subset;chosen=component;best_before=before;best_grouped=grouped;best_after=after;
            }
        }
        if(best.empty())continue;
        // Plan and cost are complete before mutating. One shared subset/module.
        SigBit shared(module->addWire(NEW_ID));module->addReduceOr(NEW_ID,SigSpec(best),shared);
        std::map<std::vector<SigBit>,SigBit> cache;
        for(int index:chosen) {
            auto &c=cells[index];SigSpec data,select;
            for(auto &g:c.groups) {
                auto key=g.second;
                auto found=cache.find(key);SigBit enable;
                if(found!=cache.end())enable=found->second;
                else {
                    std::vector<SigBit> args;
                    if(cross_contains(key,best)) {
                        args.push_back(shared);
                        for(auto bit:key)if(!std::binary_search(best.begin(),best.end(),bit))args.push_back(bit);
                    } else args=key;
                    if(args.size()==1)enable=args[0];
                    else {enable=SigBit(module->addWire(NEW_ID));module->addReduceOr(NEW_ID,SigSpec(args),enable);}
                    cache[key]=enable;
                }
                data.append(SigSpec(g.first));select.append(enable);
            }
            c.cell->setPort(ID::B,data);c.cell->setPort(ID::S,select);c.cell->setParam(ID::S_WIDTH,GetSize(select));rewritten++;
        }
        subsets++;estimated+=best_grouped.luts-best_after.luts;
        log("pmux_cross: %s cells=%d shared_inputs=%d LUT4 native/grouped/cross=%d/%d/%d depth=%d/%d fanout=%d/%d\n",module->name,int(chosen.size()),int(best.size()),best_before.luts,best_grouped.luts,best_after.luts,best_grouped.depth,best_after.depth,best_grouped.max_fanout,best_after.max_fanout);
    }
    design->scratchpad_set_int("pmux_cross.cells",rewritten);
    design->scratchpad_set_int("pmux_cross.subsets",subsets);
    design->scratchpad_set_int("pmux_cross.estimated_lut_saving",estimated);
    log("pmux_cross: rewritten=%d shared_subsets=%d estimated_incremental_luts=%d\n",rewritten,subsets,estimated);
    return rewritten;
}
}
YOSYS_NAMESPACE_END
#endif
