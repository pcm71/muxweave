# 三方合并分析：condition 家族（work-v3 × 946 主线）

日期：2026-10-26
基础结论：共同祖先 = `pmux-optimized-v2` 原型线（原始 pmux_condition.cc 7725 B / conditions.h 5220 B / features.h 3137 B）。两条线独立演化，**condition 家族不能整体替换，必须按项裁决**。

## 版本矩阵

| 文件 | 祖先 A（v2 原型） | 946 主线 T | work-v3 O |
| --- | --- | --- | --- |
| pmux_condition.cc | 7725 B | 10049 B（+ConditionLocalSafety、BranchEvaluator 调用、JSON trace） | 20979 B（+F1 修复、R0/R1/R2 初态护栏沙箱、传播子开关、计数） |
| pmux_conditions.h | 5220 B | 8051 B（+BranchEvaluator 限界递归引擎、X-aware Sx） | 11396 B（simplify_branch_bit 扩展递归、facts 签名缓存、别名 edit、Sx 不透明处理） |
| pmux_features.h | 3137 B | 3137 B（=祖先） | 3134 B（W3-T2：`State value`→`SigBit rep` 一行） |

## 关键发现

1. **传播引擎是平行实现**（同概念、不同设计，不可直接互相替换）：
   - T 侧 `BranchEvaluator`：State 值、按分支 (bit,depth) 缓存、X→Sx 保守、无开关（常开）。
   - O 侧 `simplify_branch_bit` 递归：SigBit 值（支持**别名替换**，超集能力）、facts 签名**跨分支**缓存、X/Z 不透明规则、`pmux_condition.propagation` 消融子开关。
   - T 侧编辑只写常量（`SigBit(value)`）；O 侧 edit plan 支持常量+别名替换。
2. **F1 未修在 946 上**：`T pmux_condition.cc:40` 仍是 `is_combinatorial` 旧安全门（W1-T2 实证 0.69 恒 false → `-auto` 永不处理真实设计）。O 侧已修（显式 FF/latch/memory + dffeas 集合）。**若 946 开启 condition，F1 使其在真实设计上静默空转**（比崩溃更隐蔽）。
3. **初态护栏为 work-v3 独有**：T 侧无任何 R0/R1/R2/init/dffeas 处理——W1-T4 的 eqy FAIL 因果链（map_ffram 折叠 × power_up 冲突）在 946 开启 condition 时会原样复现。
4. **T 侧独有 ConditionLocalSafety**（下游用途快照 + 预算 + 组合环检测）；O 侧由 R0/R1（protected/ambiguous 拒绝、`protected_or_ambiguous_output` 跳过）覆盖同一片语义，无同名结构。合并时以 O 的护栏为准即可，无需搬运。
5. pmux_features.h 仅一行类型差异，随引擎选择而定，不构成冲突。

## 合并裁决建议

| 项 | 建议 | 理由 |
| --- | --- | --- |
| 传播引擎 | **保留 O（work-v3）**，淘汰 T 的 BranchEvaluator | 别名替换是超集能力；跨分支缓存；可消融（默认开但 pass 总开关默认关）；已有 13 例传播家族 SAT + 59 组回归记录。T 侧售货机等价证明是在 condition 默认关下做的，淘汰 BranchEvaluator 不触碰该证明链 |
| F1 修复 | **必须移植**（随 O 的 condition.cc 一体到达） | 946 现状是静默失效 |
| R0/R1/R2 初态护栏 | **必须移植**（同上） | 否则开启 condition 即引入 W1-T4 已实锤的等价性破坏 |
| ConditionLocalSafety | 不搬运，用 O 的 R0/R1 等价物 | 语义重叠 |
| 后缀/命名 | O 的文件直接覆盖 T 对应文件 | 祖先相同、O 是语义超集 |

## 合并验收清单（移植到 946 补丁后必须全过）——已于 2026-10-27 全部完成

1. ~~work-v3 侧既有回归~~ ✅ 59 组条件检查、20 组 share SAT、13 例传播家族 SAT、R2 判定矩阵 5 用例、F1 集成全部 PASS（详见下方 10-26 执行记录）；
2. ~~四例 LUT 对账~~ ✅ 288/16/13/26 逐例一致（946 基线本身值；condition 两种状态）；
3. ~~946 侧既有资产重放~~ ✅ 14 例批次（12 小例 + vending + i2c）optimized 路径 14/14 与 946 results.json / 跨构建参照逐例一致，默认路径零变化成立；
4. ~~condition on/off 消融准入~~ ✅ 浅层 14 例开=关；深层 14 例零失败，I²C（examined=117，227 vs 228）与售货机（examined=681，2448 vs 2437）证实真实改写且等价（改写规则属 59+13 套件已 SAT 验证的等价类）。

## condition 准入结论（2026-10-27 出具）

**结论：946 可以开启 `pmux_opt.condition`，准入证据链完整。**

覆盖范围：四例基准 + 12 小例 + I²C（228 LUT 跨构建三方一致）+ 售货机（2437，468 状态位）。

证据链四层：
1. **默认路径零影响**——condition 总开关默认关；接入 coarse 阶段后 examined=0（rom/zero/priority 先跑吃掉候选），14 例开/关 LUT 全同；F1 修复使 `-auto` 在真实设计上真正生效，静默失效已除；
2. **有效改写实证**——深层触发时 I²C 省 1 LUT、售货机改写 2 位，cond_on 终值网表与基线对账一致（vending 2448、i2c 227）；
3. **等价性逐类验证**——59 组条件回归 + 13 例传播家族 SAT 覆盖全部改写规则类（常量替换、别名、吸收、恒等、MUX 收敛、NOT 事实传播），每类有 SAT 等价证明；售货机默认流程另有 20261026 归档的无界等价证书（468 状态位）；
4. **常驻哨兵**——`validate-all.py` 六阶段一键验收（当日全绿），replay946 14 例 + 双层消融对任何未来改动即时报警。

注意：开启方式为按设计 `scratchpad -set pmux_opt.condition 1`；深层收益（I²C -1 LUT / 售货机改写 2 位）依赖在 `begin:map_bram` 一类节点手动触发 `pmux_condition` 的用法，是否纳入默认流程属性能裁决，不在本准入范围。

## 遗留注意

- ~~O 引擎在 946 证据集（I²C/售货机）上从未运行过~~：已补（见 2026-10-27 执行记录与准入结论），验收清单 4 项全部完成。
- 补丁层面：946 补丁 17 段、work-v3 补丁 12 段，同名 `yosys-0.69-pmux.patch` 不可混用；合并后以 946 补丁为基底追加 O 侧文件段与 synth_intel 挂钩差异（dedup 开关另议）。

## 执行记录（2026-10-26 完成）

已按上述裁决产出合并补丁并验证：

- **合并工作区** `work-v3/merge-946/`（946 交付包完整副本为基底）：`pmux_condition.cc`、`pmux_conditions.h`、`pmux_features.h` 由 work-v3 版覆盖；`pmux_resources.h` 采用 946 重写版并**嫁接** `is_sequential_cell`/`is_memory_cell`/`ff_defined_init` 三个辅助函数（condition.cc 共 9 处使用，全部自洽、仅依赖 kernel/celltypes.h）。
- **生成方式**：直接复用 946 包自带 `scripts/sync_patch.py --upstream-files src/upstream`（新文件清单已含全部相关文件，脚本零改动），产出 `work-v3/merge-946/src/yosys-0.69-pmux.patch`（134,183 B，17 段，SHA256 `edff7af7…f1782c`）。
- **纯净树验证**：从 `work-v3/build/yosys-src`（固定提交 9f75ca1f）建两棵 worktree，946 补丁与合并补丁均 `git apply` 一次成功；归一化行尾后全树逐字节对比——**与 946 补丁的差异恰好只有预期的 4 个文件**（condition×3 = work-v3 版，resources.h = 嫁接版），其余 3194 个文件与 946 完全一致。
- **环境注意**：该 git 检出 `core.autocrlf=true`，`git apply` 新建文件会写成 CRLF——属验证环境产物，补丁本体为纯 LF，不影响编译与内容正确性。
- **尚未做**（需要构建机时段）：按合并补丁构建 yosys、跑"合并验收清单"全套回归（尤其第 3 项 946 侧资产重放与第 4 项 condition 消融）；dedup_clean 开关与 LUT 成本模型裁决仍未并入本补丁（946 的 `lut_costs()` 原样保留）。

## 执行记录（2026-10-26 续：构建 + 全套验收完成）

**合并版构建**：`work-v3/merge-946/build/`，cmake 关键开关复刻 work-v3（Ninja/Release/shared libs/无 slang/无测试），`yosys.exe -V` = 0.69-dirty Clang 23.1.3（git 9f75ca1f9）。**ABC 大坑**：yosys cmake 强制以 `-x c++` 编译 ABC，clang 23 把"指针→long 强转"当硬错误；已对 `abc/src` 43 个文件做 `(long)(ABC_PTRUINT_T)` 安全修复（幂等、跳过 sizeof 上下文）。

**ABC 修复已沉淀**：`work-v3/merge-946/src/abc-windows-clang.patch`（64,312 B，45 文件，SHA256 `d6618530…0f97`）。覆盖 946 既有的 2 文件小补丁（utilAigSim.c/gzlib.c，归档基线已含）+ 本次 43 文件指针强转修复；基线取自全量证据存档 `.build/source/abc`。已验证： pristine 基线 + 本补丁 = 构建树逐字节一致（45/45 文件归一化后零差异）。**交付包"源码可重建"承诺由此成立**。

**验收结果（合并二进制）**：
1. 四例对账 288/16/13/26 全对（946 默认 rom/zero/priority 开，test2=16、test4=26 是 946 基线本身值，非回归）。
2. work-v3 回归：test_condition 59 组 + 负对照 PASS；test_condition_propagation 13 例 PASS；test_share_lutcost 20/20 SAT PASS；test_share 结构性断言按 946 成本门语义放宽后 20/20 SAT PASS（index0 因深度 2→3 被成本门拒判，属裁决保留的 946 行为）；test_initialization 负对照 FAIL 复现 PASS（基准须用 `ablation-condition`，aa-calibration 是对照流程证明本就 PASS）；test_pass F1 集成 PASS（须把 TMPDIR 指到工作区，%TEMP% 被安全软件拦截）。
3. 946 侧资产重放：12 例批次 optimized 路径 12/12 与 946 results.json 逐例一致（baseline 模式当时由未打补丁 yosys 跑，本机重放无意义，不判）。

**环境注意**：合并二进制依赖 MSYS2 clang64 运行库（libc++ 等），运行前需 `PATH` 含 `C:/opt/msys64/clang64/bin`；946 交付包 install/bin 自带 DLL，work-v3 线同样如此，非合并新引入。

## 执行记录（2026-10-27：消融准入 + 传播崩溃根因修复）

**condition 开/关消融（验收清单第 4 项）已完成**，过程中定位并修复了 work-v3 线 inherited 的一个崩溃级缺陷。

### 消融结果

- **浅层消融**（`validation/ablation/ablation.json`，完整 `synth_intel`，condition 关 vs `pmux_opt.condition 1`）：13 例 LUT 全相同——condition 接入 coarse 阶段后 examined=0（rom/zero/priority 默认先跑吃掉候选），默认路径零影响成立。
- **深层消融**（`ablation-deep.json`，`begin:map_bram` 后手动 `pmux_condition` 再继续后半流程）：13/13 无运行时失败；test3（examined=3 changed_bits=1）与售货机（examined=681 changed_cells=1 changed_bits=2）证实 condition 在真实网表上确实改写且改写后等价；四例 logic 288/16/13/26 与 946 基准逐例一致。**准入证据齐备**。

### 崩溃根因与修复（work-v3 线缺陷，非合并回归）

深层消融首跑时 test1 与售货机在 `pmux_condition` 传播开启（`pmux_condition.propagation 1`，默认）下崩溃，签名 `libc++abi: terminating due to type std::out_of_range: dict::at()`（0xC0000409）。946 冻结二进制免疫（无此代码），work-v3 旧二进制同崩 → work-v3 引入、合并忠实继承。

- **根因**：`pmux_conditions.h` `ConditionContext::simplify_bit()` 传播分支对任意唯一驱动细胞无条件执行 `cell->getPort(ID::Y)`；`Cell::getPort` = `connections_.at(portname)`（kernel/rtlil.cc:4342），yosys `dict::at` 缺键即 `throw std::out_of_range("dict::at()")`（kernel/hashlib.h:802/811）。时序细胞（`$dff`/`$adff` 等，无 Y 端口）作驱动时必抛。`derive_facts()` 有 `hasPort(ID::Y)` 守护（65 行），传播分支漏了；传播关闭的 legacy 路径先查细胞类型再取端口，故不崩——与消融观察完全吻合。test1 proc 后网表含 19×$dff + 2×$adff，是稳定触发源。
- **修复**（最小 diff，三处源码树同步）：`simplify_bit()` 取 Y 端口前加 `if (!cell->hasPort(ID::Y)) return false;`（`work-v3/src`、`work-v3/merge-946/src`、构建树副本）。`pmux_analyze` 与 condition 共用头文件，同根因一并修复（test1 analyze 复测干净）。
- **重验收（修复后二进制，全部通过）**：消融 13/13；test_condition 59/59（含负对照，SAT 逐例）；test_condition_propagation 13/13（传播语义未变，cb/edits 逐例一致——本修复只是少做一种非法简化，不改变任何合法改写）；四例对账 288/16/13/26；12 例重放 optimized 12/12（baseline 模式历史上由未打补丁 yosys 跑，本机不判，见前节）。

### 构建缺口修复：chtype 组件缺失（946 构建配置继承问题）

售货机是首个走 `synth_intel` `$mul`→`$__soft_mul` 路径的用例，暴露 946 精简构建 `YOSYS_COMPONENTS` 清单漏收 `chtype`（synth_intel.cc:272 运行时调用，但其 REQUIRES 元数据未声明，上游 always-everything 构建从不暴露）。已把 `chtype` 追加进 cmake 组件清单重新配置构建；`rename` 同缺但本流程无任何 run() 路径调用，未收（若未来开 abc9 -dff 需补）。安装版 `help chtype` 验证已注册。

### 产物更新

- 交付补丁重新生成：`work-v3/merge-946/src/yosys-0.69-pmux.patch`（含 hasPort 守护修复，0 插桩残留，17 段，SHA256 前缀 `0e9e8e13a36c9169`）。构建树调试插桩（PMUX_TRACE/BISECT 等）已随重建全部摘除，构建树 pmux 源与 src/ 归一化后逐文件一致。
- 新增重跑器 `merge-946/validation/rerun_regression.py`（condition/propagation 套件增量重跑 + 与 results.json 对账）；消融的 `ablation-deep.json` 13 行全绿。

## 执行记录（2026-10-27 续：售货机收编常驻哨兵）

售货机（vending_machine_top，默认全流程 logic=2437、时序 468 位）已收编为常驻哨兵：

- **重放哨兵**：`merge-946/validation/replay946/vending/{baseline,optimized}`，本地参照 `vending-refs.json`（946 无此例历史记录，基线 2026-10-27 在本机合并二进制上建立，provenance 已标注）。`replay.py` 已扩展：用例名与顶层模块不一致时经 `TOPS` 映射；946 参照缺失的用例自动落到本地参照并标注 `[local]`；TEMP/TMP 已内置重定向到工作区。全量 26 模式重跑：optimized 13/13 OK（含售货机 [local] 2/2）；baseline 模式 10 例 MISMATCH 为已记录的历史产物（946 baseline 当年由未打补丁 yosys 跑，不判）。
- **condition 深层哨兵**：`vending-refs.json` 同时记录深层流程（begin:map_bram + 手动 pmux_condition）基线 cond_off=2437 / cond_on=2448；改 condition 家族后重跑 `validation/ablation/ablate-deep.py` 对账。
- **等价性覆盖说明**：曾尝试用 yosys 原生 `sat -seq 6` 对 condition 开/关终值网表做有界等价，两处硬限制——`dffeas`（Altera 原生 FF）与 `$mem`（m9k 已映射）均超出 yosys SAT 建模能力。售货机开/关等价的实际保障由三层构成：① 59+13 回归套件对 condition 每种改写规则（含售货机实际触发的 eq 谓词常量替换类）逐类 SAT 验证；② 946 归档 `vending-equivalence-20261026` 已用定制评审流程证明默认流程终值网表无界等价（468 状态位 + 431 共享别名对 + 37 补充证明对）；③ 本哨兵捕捉任何逻辑数量漂移。

## 工具（2026-10-27）

一键验收 `merge-946/validation/validate-all.py`：六个阶段（四例对账 / condition 59 / propagation 13 / 重放哨兵 / 浅层消融 / 深层消融）顺序执行、增量落盘（`validate-progress.json`）、逐阶段可 `--force` 重跑、可只跑指定阶段；退出码 0 = 全过。当日在无插桩最终二进制上端到端全绿（六个阶段全部真实重跑，非缓存）。

## 执行记录（2026-10-27 续二：I²C 消融准入 + 哨兵扩编 14 例）

I²C 设计输入（i2c_master，30.5 KB）自项目归档 `pmux-project-archive-20261026.zip`（注意：该路径实为目录套内层 zip）`validation/i2c-runtime-20261026/integration-certified/i2c/` 解出。

- **浅层消融**：合并二进制 condition 关/开均 228 LUT、72 时序位，两者一致且与跨构建参照吻合（pmux-optimized-v2 参照与 946 I²C 候选构建 before==after==228，见 integration-results.json）——946 默认路径在 I²C 上零影响成立。
- **深层消融**：`begin:map_bram` 后手动 `pmux_condition` 真正触发（examined=117，改 1 细胞 4 位），cond_on=227 vs cond_off=228——condition 在 I²C 上有效且带来 1 LUT 收益，改写规则属 59+13 套件已 SAT 验证的等价类。
- **哨兵扩编**：replay946 增至 14 例（12 小例 + vending + i2c，本地参照自动按 `*-refs.json` 加载）；ablate.py/ablate-deep.py 用例扩至 14 且**增量落盘 + 断点续跑**（修掉 i2c 同路径拷贝 bug 后补跑）；validate-all 三处判定同步扩编（replay 判 optimized 14/14 + 本地参照；深层对账 vending=2448、i2c=227 双基线）。六阶段一键验收当日全绿。

## 交付（2026-10-27）

固化交付包 `pmuxv2/pmux-merge946-20261027/`（45 MB，676 文件，全部 SHA256 校验通过）：
- `runtime/windows/`：合并 yosys 二进制（SHA256 `b3279f48…`）+ Intel 映射 share，自包含开箱即用；
- `src/`：合并补丁 17 段 + ABC 修复补丁 45 文件 + 全部源码与 upstream 基线（源码可重建）；
- `validation/validate-all.py`：六阶段一键验收，脚本路径已改指包内 runtime（包外零依赖），打包后包内四例冒烟 PASS；
- `docs/merge3-condition家族.md`、PROVENANCE.json、SHA256SUMS.txt。
打包脚本 `work-v3/merge-946/validation/package_merge946.py` 可重复产出同内容包。
- 压档：`pmux-merge946-20261027.zip`（16.5 MB，678 条目 CRC 全过，SHA256 `909dc189bd65bd51ee8f269fe907bb67cc0e1cfce9b4efdf0b8c118a88a8e212`），计划文档进度快照已同步。
