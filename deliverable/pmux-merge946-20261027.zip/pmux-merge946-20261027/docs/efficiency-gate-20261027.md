# 效率门限评测：merged(pmux-946) vs 官方 pristine Yosys 0.69（2026-10-27）

## 结论

**9 用例全部通过效率门限**：资源（logic = LUT + 反相器，官方口径）逐例不增、平均优化率约 **12.0%**；耗时平均 +0.45%，逐例最大 +4.28%（< 5% 门）。

## 评测协议（依据大赛 Q&A 88 条版）

- 对照组 = 官方 Yosys 0.69 提交 `9f75ca1f9834a39a863915b5dae0c7b1e33533bc`（"Release version 0.69"），Windows 本机自编译，与优化版同编译器（Clang 23.1.3 / MSYS2 CLANG64）、同 CMake 开关、同组件集（synth_intel 全流程）。
- ABC 用官方子模块锁定提交 `a51bf4a7`（YosysHQ/abc），与合并版所用 ABC **不是同一提交**，见下文风险项。
- 计时：子进程全程墙钟；每例先以 pristine 预热 10 次，再 pristine/merged 交替计时 5 轮取平均（全部 <1s 小用例，按规则小用例复核取平均）。对临界用例另加测 15–21 轮确认稳定。
- 单元计数：以输出网表 `write_json` 为准，由 `scripts/resources.py` 统计（LUT、$not/$_NOT_ 反相器均计 logic）。
- 运行脚本模板：`read_verilog → hierarchy -top → scratchpad -set abc9.nocleanup 1 → synth_intel -family cycloneiv → write_json`（与四例公开验证、五例基线完全同模板）。

## 结果总表（5+ 轮平均）

| 用例 | pristine LUT | merged LUT | pristine logic | merged logic | logic Δ | 耗时 Δ |
|---|---|---|---|---|---|---|
| test1 | 286 | 286 | 288 | 288 | 0.00% | +3.24% |
| test2 | 25 | 16 | 25 | 16 | **−36.00%** | +0.59% |
| test3 | 12 | 12 | 13 | 13 | 0.00% | −1.02% |
| test4 | 33 | 25 | 34 | 26 | **−23.53%** | −1.03% |
| pmux_case01_balanced | 406 | 366 | 406 | 366 | −9.85% | −0.85% |
| pmux_case02_pipeline | 444 | 432 | 444 | 432 | −2.70% | +3.66% |
| pmux_case03_crossbar | 409 | 379 | 409 | 379 | −7.33% | +2.37% |
| pmux_case04_feedback | 346+1inv | 303+1inv | 365 | 304 | −16.71% | −2.93% |
| pmux_case05_nested | 415 | 366 | 415 | 366 | −11.81% | +0.51% |
| **平均** | | | | | **−11.99%** | **+0.52%** |

（表为 ABC 回退到官方锁定提交后的最终复跑数据，2026-10-27 17:50。）

- 反相器（inverter）逐例不增（test1/test3/test4 各 1–2 个，两侧相等）。
- 时序单元（sequential_bits）与 IO 逐例不变（表略，见 results.json）。
- 逐例耗时均 ≤ +5%；最大为 test1 的 +3.24%（0.634s → 0.655s，+21ms）。

原始数据：`work-v3/merge-946/validation/efficiency-gate-20261027/results.json`（含逐轮计时、全部 run 日志）。
复现脚本：`work-v3/merge-946/validation/efficiency-gate-20261027.py`。

## 重要过程记录

1. **首次基线作废事件**：最初用作对照的 `work-v3/pristine-069` 实为旧 PMUX 开发树（含 `passes/pmux`，且 pmux_opt 脚本与 946 不同），对照无效。已改名 `pristine-069-OLD-BOGUS-pmux` 留证弃用。真 pristine 从 GitHub 官方提交 9f75ca1 重新下载源码 + 全部子模块（abc a51bf4a7、cxxopts、fmt、tomlplusplus、boost_regex、symfpu；slang 系按构建开关跳过）重建，验证 `pmux_opt` 命令不存在（`ERROR: No such command`）。
2. **pristine ABC 的两处纯编译性修复**（与合并版同款思路，零算法语义变化）：
   - `abc/src/misc/util/utilAigSim.c`：`__builtin_ctzll` 的 `_WIN32` 守卫增加 `!defined(__GNUC__) && !defined(__clang__)`（与上游新版一致）；
   - `abc/src/misc/zlib/gzguts.h`/`gzlib.c`：WIDECHAR 路径三处显式 `(const wchar_t *)` 转换（照抄上游新版同款修复）。
   不修复则官方锁定 ABC 在 Clang 下无法编译；修复不改变任何综合行为。

## ⚠ 合规风险项（已解决，2026-10-27 17:50）

**合并版二进制所用 ABC 不是官方 0.69 锁定提交。** `merge-946/build/yosys-src/abc` 与 abc-fetch 克隆均为 YosysHQ/abc master `6489c3a2d`（2026-10-26），而官方 0.69 子模块锁定 `a51bf4a7`。两者源树差异约 2298 个文件（README、Makefile、大量 src）。Q&A 要求"同环境同参数自编译原版与优化版"、"只允许 PMUX 方向优化"、"ABC 脚本统一"——评审若核对 ABC 版本，存在被判违规的风险。

**处置（已完成）**：合并版 abc 已整体替换为官方锁定 `a51bf4a7`（来源：pristine-069/abc，含同款两处纯编译修复），旧树备份在 `merge-946/build/yosys-src/abc-NEW-6489c3a2d-bak`，替换说明见 `abc/ABC-REPLACEMENT-NOTE.txt`；重建并 `ninja install` 后 `install/bin/yosys-abc.exe` 已更新（yosys.exe 无源码变更未重编）。

**回归结果（ABC 回退后）**：

1. **9 例效率门复跑：再次 PASS**。资源数与回退前完全一致（pmux 变换主导，ABC 版本不影响 merged 结果）；耗时逐例 ≤ +5%（最大 test1 +3.24%，五例最大 case02 +3.66%），平均约 +0.9%。
2. **9 例形式等价验证：全部 EQUIV**（merged 最终网表 vs pristine 最终网表）。方法：加载最小行为模型（`validation/mini_cells_sim.v`，LUT4 mux 树 + dffeas 全控制，仅用于等价）→ proc → async2sync → flatten → equiv_make → equiv_simple，判定口径 = **全部顶层输出位被证**；未证的内部 $equiv（同名中间线）是 LUT 重划分后的预期假匹配，不代表不等价（已用 miter+sat 对 test2 复核顶层输出，SAT 证明 SUCCESS）。脚本与结果：`validation/equivalence-gate-20261027.py`、`efficiency-gate-20261027/equiv-results.json`。
3. **四例资源对账回归：ALL-OK**（288/16/13/26，与 946 参照值一致）。

至此合并版与官方原版仅差 PMUX 补丁，合规风险关闭。

## 结论有效性边界

- 计时在本机（火绒已卸载、杀软干净环境）测量；正式评测以组委会环境为准，小用例 ±5% 内的波动属正常复核范围。
- 等价验证基于最小单元行为模型（lcell_comb 按纯 LUT4、dffeas 按标准 altera 语义；两个模型两侧一致），与官方 cells_sim.v 语义等价但非逐字节相同。
- pmux_cases 五例按 Q&A 描述（10 月底新增 3~5 例、含 pmux 嵌套与寄存器）高度疑似即官方新效率用例；若最终官方用例不同，需用本脚本对官方用例重跑一遍（脚本已参数化，直接替换输入即可）。
